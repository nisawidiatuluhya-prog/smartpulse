/* MarketPulse landing: splash -> masuk ke aplikasi, reveal on scroll, count-up, tab tampilan */
(function () {
  var root = document.documentElement;
  var splash = document.getElementById('lpSplash');
  var app = document.getElementById('lpApp');

  function fmt(n, mode) {
    var s = Math.round(n).toLocaleString('id-ID');
    return mode === 'rp' ? 'Rp ' + s : s;
  }
  function countUp(el) {
    if (el.dataset.done) return; el.dataset.done = 1;
    var to = parseFloat(el.dataset.count), mode = el.dataset.fmt, t0 = null, dur = 1400;
    function step(t) {
      if (!t0) t0 = t;
      var p = Math.min((t - t0) / dur, 1), e = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(to * e, mode);
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  function startPage() {
    root.classList.add('lp-ready');
    var io = ('IntersectionObserver' in window) ? new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add('in');
        e.target.querySelectorAll('[data-count]').forEach(countUp);
        if (e.target.hasAttribute('data-count')) countUp(e.target);
        io.unobserve(e.target);
      });
    }, { threshold: .15 }) : null;
    document.querySelectorAll('.lp-reveal').forEach(function (el) {
      if (io) io.observe(el); else { el.classList.add('in'); el.querySelectorAll('[data-count]').forEach(countUp); }
    });
  }

  function closeSplash() {
    if (!splash || splash.classList.contains('out')) return;
    try { sessionStorage.setItem('mp_splash', '1'); } catch (e) {}
    splash.classList.add('out');             // animasi "zoom masuk" ke aplikasi
    app.classList.add('lp-enter');
    setTimeout(function () { root.classList.remove('lp-splash-on'); splash.remove(); }, 750);
    startPage();
  }

  if (root.classList.contains('lp-splash-on')) {
    var t = setTimeout(closeSplash, 2600);
    document.getElementById('lpSkip').addEventListener('click', function () { clearTimeout(t); closeSplash(); });
    splash.addEventListener('click', function () { clearTimeout(t); closeSplash(); });
  } else {
    if (splash) splash.remove();
    startPage();
  }

  // navbar berbayang saat di-scroll
  var nav = document.getElementById('lpNav');
  function onScroll() { nav.classList.toggle('scrolled', window.scrollY > 12); }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  // tab tampilan
  document.querySelectorAll('.lp-tabs button').forEach(function (b) {
    b.addEventListener('click', function () {
      document.querySelectorAll('.lp-tabs button').forEach(function (x) { x.classList.toggle('on', x === b); });
      document.querySelectorAll('.lp-pane').forEach(function (p) { p.classList.toggle('on', p.id === b.dataset.tab); });
    });
  });
})();
