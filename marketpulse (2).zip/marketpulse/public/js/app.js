const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// ---- Chart.js: gaya & animasi global ----
if (window.Chart) {
  Chart.defaults.font.family = "'Plus Jakarta Sans', system-ui, sans-serif";
  Chart.defaults.font.size = 11;
  Chart.defaults.color = '#8a90ad';
  Chart.defaults.animation = reduceMotion ? false : { duration: 1500, easing: 'easeOutQuart' };
  Chart.defaults.plugins.tooltip.backgroundColor = '#1b1850';
  Chart.defaults.plugins.tooltip.cornerRadius = 10;
  Chart.defaults.plugins.tooltip.padding = 11;
  Chart.defaults.plugins.tooltip.titleFont = { weight: '700' };
  Chart.defaults.plugins.tooltip.boxPadding = 4;
}

// Gradien vertikal untuk area/bar chart
window.mpGradient = (canvas, rgb, a1 = .35, h = 320) => {
  const g = canvas.getContext('2d').createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, `rgba(${rgb},${a1})`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  return g;
};

// ---- Angka berhitung naik (count-up) ----
function countUp(el) {
  const text = el.textContent;
  const m = text.match(/\d[\d.,]*/);
  if (!m) return;
  const token = m[0];
  let decimals = 0, value;
  if (/^\d+,\d+$/.test(token)) {                 // 12,5
    decimals = token.split(',')[1].length;
    value = parseFloat(token.replace(',', '.'));
  } else if (/^\d{1,3}(\.\d{3})+$/.test(token)) { // 1.234.567
    value = parseInt(token.replace(/\./g, ''), 10);
  } else if (/^\d{1,3}(\.\d{3})+,\d+$/.test(token)) { // 1.234,5
    decimals = token.split(',')[1].length;
    value = parseFloat(token.replace(/\./g, '').replace(',', '.'));
  } else {
    value = parseFloat(token);
  }
  if (!isFinite(value) || value === 0) return;

  const fmt = n => n.toLocaleString('id-ID', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  const start = performance.now(), dur = 1400;
  const tick = now => {
    const t = Math.min(1, (now - start) / dur);
    const eased = 1 - Math.pow(1 - t, 4);
    el.textContent = text.replace(token, fmt(value * eased));
    if (t < 1) requestAnimationFrame(tick);
    else el.textContent = text;                   // pastikan angka akhir persis
  };
  requestAnimationFrame(tick);
}

document.addEventListener('DOMContentLoaded', () => {
  const sb = document.getElementById('mpSidebar');
  document.querySelectorAll('[data-sidebar-toggle]').forEach(b => b.addEventListener('click', () => sb && sb.classList.toggle('open')));

  // Konfirmasi hapus
  document.querySelectorAll('form[data-confirm]').forEach(f => f.addEventListener('submit', e => {
    if (!confirm(f.dataset.confirm)) e.preventDefault();
  }));

  // Auto-submit filter
  document.querySelectorAll('[data-autosubmit]').forEach(el => el.addEventListener('change', () => el.form.submit()));

  // Animasi bertahap untuk kartu
  document.querySelectorAll('.mp-main .mp-card').forEach((el, i) => el.style.setProperty('--i', Math.min(i, 12)));

  // Count-up angka
  if (!reduceMotion) document.querySelectorAll('.js-count').forEach(countUp);

  // Notifikasi sukses hilang sendiri
  document.querySelectorAll('.alert-success').forEach(a => setTimeout(() => {
    a.classList.add('mp-leave'); setTimeout(() => a.remove(), 500);
  }, 4500));

  // Efek riak pada tombol utama
  document.querySelectorAll('.btn-primary').forEach(b => b.addEventListener('click', e => {
    if (reduceMotion) return;
    const r = b.getBoundingClientRect(), s = document.createElement('span'), d = Math.max(r.width, r.height);
    s.style.cssText = `position:absolute;border-radius:50%;pointer-events:none;background:rgba(255,255,255,.45);width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px;transform:scale(0);opacity:1;transition:transform .6s ease-out,opacity .6s ease-out`;
    if (getComputedStyle(b).position === 'static') b.style.position = 'relative';
    b.style.overflow = 'hidden';
    b.appendChild(s);
    requestAnimationFrame(() => { s.style.transform = 'scale(2.2)'; s.style.opacity = '0'; });
    setTimeout(() => s.remove(), 650);
  }));
});

// Helper format rupiah untuk Chart.js
window.rp = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');
window.rpShort = n => n >= 1e9 ? (n / 1e9).toFixed(1) + ' M' : n >= 1e6 ? (n / 1e6).toFixed(1) + ' jt' : n >= 1e3 ? Math.round(n / 1e3) + ' rb' : n;
