<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // user_id NULL = kategori global yang dikelola Admin
        Schema::create('categories', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained()->cascadeOnDelete();
            $t->string('name');
            $t->string('description')->nullable();
            $t->timestamps();
        });

        Schema::create('products', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $t->string('name');
            $t->string('sku', 60)->nullable();
            $t->text('description')->nullable();
            $t->decimal('price', 15, 2);
            $t->unsignedInteger('stock')->default(0);
            $t->string('image')->nullable();
            $t->enum('status', ['active', 'draft', 'archived'])->default('active');
            $t->timestamps();
            $t->index(['user_id', 'status']);
        });

        Schema::create('customers', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('name');
            $t->string('email')->nullable();
            $t->string('phone', 30)->nullable();
            $t->text('address')->nullable();
            $t->timestamps();
        });

        Schema::create('sales', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('customer_id')->nullable()->constrained()->nullOnDelete();
            $t->string('invoice_no', 40)->unique();
            $t->date('sold_at');
            $t->decimal('total', 15, 2)->default(0);
            $t->string('notes')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'sold_at']);
        });

        Schema::create('sale_details', function (Blueprint $t) {
            $t->id();
            $t->foreignId('sale_id')->constrained()->cascadeOnDelete();
            $t->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
            $t->string('product_name');
            $t->unsignedInteger('quantity');
            $t->decimal('price', 15, 2);
            $t->decimal('subtotal', 15, 2);
            $t->timestamps();
        });

        Schema::create('settings', function (Blueprint $t) {
            $t->string('key')->primary();
            $t->text('value')->nullable();
        });
    }

    public function down(): void
    {
        foreach (['settings', 'sale_details', 'sales', 'customers', 'products', 'categories'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
