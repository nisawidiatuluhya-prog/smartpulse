<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(['email' => 'admin@marketpulse.test'], [
            'name' => 'Administrator', 'password' => 'admin12345', 'role' => 'admin', 'is_active' => true,
        ]);

        foreach (['Makanan & Minuman', 'Fashion', 'Elektronik', 'Kecantikan', 'Rumah Tangga'] as $name) {
            Category::firstOrCreate(['user_id' => null, 'name' => $name]);
        }

        Setting::put('app_name', Setting::get('app_name', 'MarketPulse'));
        Setting::put('tagline', Setting::get('tagline', 'Smart commerce business intelligence'));
    }
}
