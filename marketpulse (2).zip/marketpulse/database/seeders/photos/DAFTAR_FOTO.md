# Daftar foto produk demo

Taruh foto ASLI (bukan ilustrasi) di folder ini dengan nama file persis seperti kolom **Nama file** (boleh `.jpg`, `.jpeg`, `.png`, `.webp`). Disarankan persegi, minimal 600x600 px, maks 2 MB.

Setelah foto dimasukkan:

```bash
php artisan demo:photos --force
php artisan storage:link
php artisan demo:photos-check   # lihat sisa yang belum ada
```

Tidak wajib semua: produk tanpa foto tetap tampil dengan ikon. Mulai dari produk yang paling sering muncul di dashboard.

| No | Produk | Kategori | Nama file |
|---|---|---|---|
| 1 | Kopi Arabika Mandailing 250g | Kopi | `kopi-arabika-mandailing-250g.jpg` |
| 2 | Kopi Robusta Lampung 250g | Kopi | `kopi-robusta-lampung-250g.jpg` |
| 3 | Teh Hitam Celup | Teh | `teh-hitam-celup.jpg` |
| 4 | Cokelat Aceh 100g | Snack | `cokelat-aceh-100g.jpg` |
| 5 | V60 Dripper | Peralatan | `v60-dripper.jpg` |
| 6 | Timbangan Kopi Digital | Peralatan | `timbangan-kopi-digital.jpg` |
| 7 | Kemeja Batik Slim Fit | Batik | `kemeja-batik-slim-fit.jpg` |
| 8 | Rok Batik Lilit | Batik | `rok-batik-lilit.jpg` |
| 9 | Kain Ulos Mini | Kain | `kain-ulos-mini.jpg` |
| 10 | Dompet Songket | Aksesoris | `dompet-songket.jpg` |
| 11 | Peci Nasional | Aksesoris | `peci-nasional.jpg` |
| 12 | Mouse Wireless | Perangkat | `mouse-wireless.jpg` |
| 13 | Keyboard Mini Bluetooth | Perangkat | `keyboard-mini-bluetooth.jpg` |
| 14 | Tripod HP | Aksesoris | `tripod-hp.jpg` |
| 15 | Ring Light 10 inch | Perangkat | `ring-light-10-inch.jpg` |
| 16 | Flashdisk 64GB | Aksesoris | `flashdisk-64gb.jpg` |
| 17 | Headset Gaming | Audio | `headset-gaming.jpg` |
| 18 | Toner Pore Care | Skincare | `toner-pore-care.jpg` |
| 19 | Maskara Waterproof | Makeup | `maskara-waterproof.jpg` |
| 20 | Eyeliner Pen | Makeup | `eyeliner-pen.jpg` |
| 21 | Hand Cream Shea | Skincare | `hand-cream-shea.jpg` |
| 22 | Parfum Mini 30ml | Wangi | `parfum-mini-30ml.jpg` |
| 23 | Set Pisau Dapur | Dapur | `set-pisau-dapur.jpg` |
| 24 | Seprai Katun King | Kamar | `seprai-katun-king.jpg` |
| 25 | Vas Keramik | Dekorasi | `vas-keramik.jpg` |
| 26 | Rak Dinding Minimalis | Perabot | `rak-dinding-minimalis.jpg` |
| 27 | Blender 1.5L | Dapur | `blender-1-5l.jpg` |
| 28 | Kopi Gayo 250g | Kopi | `kopi-gayo-250g.jpg` |
| 29 | Kopi Toraja 250g | Kopi | `kopi-toraja-250g.jpg` |
| 30 | Kopi Sidikalang 250g | Kopi | `kopi-sidikalang-250g.jpg` |
| 31 | Teh Hijau Premium | Teh | `teh-hijau-premium.jpg` |
| 32 | Teh Melati 100g | Teh | `teh-melati-100g.jpg` |
| 33 | Keripik Singkong | Snack | `keripik-singkong.jpg` |
| 34 | Kacang Sangrai | Snack | `kacang-sangrai.jpg` |
| 35 | French Press 600ml | Peralatan | `french-press-600ml.jpg` |
| 36 | Gelas Keramik | Peralatan | `gelas-keramik.jpg` |
| 37 | Grinder Manual | Peralatan | `grinder-manual.jpg` |
| 38 | Kemeja Batik Pria | Batik | `kemeja-batik-pria.jpg` |
| 39 | Dress Batik Wanita | Batik | `dress-batik-wanita.jpg` |
| 40 | Kain Batik Tulis 2m | Kain | `kain-batik-tulis-2m.jpg` |
| 41 | Selendang Songket | Aksesoris | `selendang-songket.jpg` |
| 42 | Tas Anyaman | Aksesoris | `tas-anyaman.jpg` |
| 43 | Kemeja Batik Anak | Batik | `kemeja-batik-anak.jpg` |
| 44 | Sarung Tenun | Kain | `sarung-tenun.jpg` |
| 45 | Earbuds Bluetooth | Audio | `earbuds-bluetooth.jpg` |
| 46 | Power Bank 10000mAh | Aksesoris | `power-bank-10000mah.jpg` |
| 47 | Charger Fast 33W | Aksesoris | `charger-fast-33w.jpg` |
| 48 | Smartwatch Lite | Wearable | `smartwatch-lite.jpg` |
| 49 | Speaker Mini | Audio | `speaker-mini.jpg` |
| 50 | Kabel Type-C 1m | Aksesoris | `kabel-type-c-1m.jpg` |
| 51 | Case HP Premium | Aksesoris | `case-hp-premium.jpg` |
| 52 | Webcam HD | Perangkat | `webcam-hd.jpg` |
| 53 | Serum Vitamin C | Skincare | `serum-vitamin-c.jpg` |
| 54 | Moisturizer Gel | Skincare | `moisturizer-gel.jpg` |
| 55 | Sunscreen SPF50 | Skincare | `sunscreen-spf50.jpg` |
| 56 | Lipstik Matte | Makeup | `lipstik-matte.jpg` |
| 57 | Cushion Compact | Makeup | `cushion-compact.jpg` |
| 58 | Face Wash Herbal | Skincare | `face-wash-herbal.jpg` |
| 59 | Set Panci Anti Lengket | Dapur | `set-panci-anti-lengket.jpg` |
| 60 | Rice Cooker 1L | Dapur | `rice-cooker-1l.jpg` |
| 61 | Bantal Hotel | Kamar | `bantal-hotel.jpg` |
| 62 | Lampu Meja LED | Dekorasi | `lampu-meja-led.jpg` |
| 63 | Rak Sepatu | Perabot | `rak-sepatu.jpg` |
| 64 | Mie Gomak | Makanan | `mie-gomak.jpg` |
| 65 | Mie Sop Ayam | Makanan | `mie-sop-ayam.jpg` |
| 66 | Es Teh Manis | Minuman | `es-teh-manis.jpg` |
| 67 | Kerupuk Ikan | Snack | `kerupuk-ikan.jpg` |
| 68 | Buku Tulis A5 | ATK | `buku-tulis-a5.jpg` |
| 69 | Pulpen Gel 0.5mm | ATK | `pulpen-gel-0-5mm.jpg` |
| 70 | Pensil 2B Set | ATK | `pensil-2b-set.jpg` |
| 71 | Highlighter 5 Warna | ATK | `highlighter-5-warna.jpg` |
| 72 | Kalkulator Ilmiah | Elektronik | `kalkulator-ilmiah.jpg` |
| 73 | Tas Ransel Sekolah | Tas | `tas-ransel-sekolah.jpg` |
| 74 | Map Plastik Folder | ATK | `map-plastik-folder.jpg` |
| 75 | Bola Futsal | Bola | `bola-futsal.jpg` |
| 76 | Sepatu Lari Pria | Sepatu | `sepatu-lari-pria.jpg` |
| 77 | Matras Yoga | Fitness | `matras-yoga.jpg` |
| 78 | Dumbbell 5kg | Fitness | `dumbbell-5kg.jpg` |
| 79 | Botol Minum 1L | Aksesoris | `botol-minum-1l.jpg` |
| 80 | Raket Badminton | Raket | `raket-badminton.jpg` |
| 81 | Tali Skipping | Fitness | `tali-skipping.jpg` |
| 82 | Beras Organik 5kg | Sembako | `beras-organik-5kg.jpg` |
| 83 | Madu Hutan 500ml | Sembako | `madu-hutan-500ml.jpg` |
| 84 | Telur Ayam Kampung | Sembako | `telur-ayam-kampung.jpg` |
| 85 | Sayur Bayam Organik | Sayur & Buah | `sayur-bayam-organik.jpg` |
| 86 | Pisang Barangan | Sayur & Buah | `pisang-barangan.jpg` |
| 87 | Minyak Kelapa 500ml | Sembako | `minyak-kelapa-500ml.jpg` |
| 88 | Roti Tawar Gandum | Roti | `roti-tawar-gandum.jpg` |
| 89 | Brownies Cokelat Box | Kue | `brownies-cokelat-box.jpg` |
| 90 | Donat Mix 6 pcs | Roti | `donat-mix-6-pcs.jpg` |
| 91 | Cheesecake Slice | Kue | `cheesecake-slice.jpg` |
| 92 | Bolu Gulung Pandan | Kue | `bolu-gulung-pandan.jpg` |
| 93 | Croissant Butter | Roti | `croissant-butter.jpg` |
| 94 | Kue Lapis Legit | Kue | `kue-lapis-legit.jpg` |
| 95 | Makanan Kucing 1kg | Makanan Hewan | `makanan-kucing-1kg.jpg` |
| 96 | Makanan Anjing 2kg | Makanan Hewan | `makanan-anjing-2kg.jpg` |
| 97 | Pasir Kucing Wangi | Perawatan | `pasir-kucing-wangi.jpg` |
| 98 | Kalung Hewan Reflektif | Aksesoris Hewan | `kalung-hewan-reflektif.jpg` |
| 99 | Kandang Lipat Kecil | Aksesoris Hewan | `kandang-lipat-kecil.jpg` |
| 100 | Sampo Anti Kutu | Perawatan | `sampo-anti-kutu.jpg` |
| 101 | Kaos Polos Premium | Pakaian | `kaos-polos-premium.jpg` |
| 102 | Kemeja Flanel | Pakaian | `kemeja-flanel.jpg` |
| 103 | Celana Chino | Pakaian | `celana-chino.jpg` |
| 104 | Jaket Denim | Pakaian | `jaket-denim.jpg` |
| 105 | Sneakers Casual | Sepatu | `sneakers-casual.jpg` |
| 106 | Totebag Kanvas | Tas | `totebag-kanvas.jpg` |
| 107 | Produk Baru (draft) | - | `produk-baru-draft.jpg` |
