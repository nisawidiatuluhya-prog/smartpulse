Folder ini hanya arsip ilustrasi vektor lama dan TIDAK dipakai aplikasi lagi.
Foto produk demo sekarang diambil dari `database/seeders/photos` (lihat DAFTAR_FOTO.md di sana).
