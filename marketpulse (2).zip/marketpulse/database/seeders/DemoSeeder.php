<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use App\Support\DemoPhotos;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Opsional: beberapa Business Owner contoh + transaksi supaya dashboard Admin & Owner terisi.
 * Aman dijalankan ulang: owner yang sudah punya transaksi dilewati.
 *   php artisan db:seed --class=DemoSeeder
 */
class DemoSeeder extends Seeder
{
    /** Produk dan pelanggan tambahan per owner agar katalog terlihat ramai. */
    private const EXTRA = [
        'owner@marketpulse.test' => [
            'products' => [['Kopi Arabika Mandailing 250g', 'Kopi', 99000], ['Kopi Robusta Lampung 250g', 'Kopi', 65000], ['Teh Hitam Celup', 'Teh', 28000], ['Cokelat Aceh 100g', 'Snack', 38000], ['V60 Dripper', 'Peralatan', 120000], ['Timbangan Kopi Digital', 'Peralatan', 155000]],
            'customers' => ['Benny Hutapea', 'Clara Simanjuntak', 'Doni Purba'],
        ],
        'siti@marketpulse.test' => [
            'products' => [['Kemeja Batik Slim Fit', 'Batik', 265000], ['Rok Batik Lilit', 'Batik', 185000], ['Kain Ulos Mini', 'Kain', 150000], ['Dompet Songket', 'Aksesoris', 95000], ['Peci Nasional', 'Aksesoris', 75000]],
            'customers' => ['Elisabet Tampubolon', 'Fitri Rangkuti'],
        ],
        'andi@marketpulse.test' => [
            'products' => [['Mouse Wireless', 'Perangkat', 89000], ['Keyboard Mini Bluetooth', 'Perangkat', 169000], ['Tripod HP', 'Aksesoris', 79000], ['Ring Light 10 inch', 'Perangkat', 145000], ['Flashdisk 64GB', 'Aksesoris', 85000], ['Headset Gaming', 'Audio', 245000]],
            'customers' => ['Jefri Manurung', 'Kevin Aritonang'],
        ],
        'dewi@marketpulse.test' => [
            'products' => [['Toner Pore Care', 'Skincare', 76000], ['Maskara Waterproof', 'Makeup', 69000], ['Eyeliner Pen', 'Makeup', 49000], ['Hand Cream Shea', 'Skincare', 39000], ['Parfum Mini 30ml', 'Wangi', 109000]],
            'customers' => ['Yasmin Lubis'],
        ],
        'maya@marketpulse.test' => [
            'products' => [['Set Pisau Dapur', 'Dapur', 159000], ['Seprai Katun King', 'Kamar', 215000], ['Vas Keramik', 'Dekorasi', 89000], ['Rak Dinding Minimalis', 'Perabot', 135000], ['Blender 1.5L', 'Dapur', 329000]],
            'customers' => ['Nanda Pratiwi'],
        ],
    ];

    public function run(): void
    {
        $this->call(DatabaseSeeder::class);

        $owners = [
            [
                'name' => 'Budi Santoso', 'email' => 'owner@marketpulse.test', 'business' => 'Toko Kopi Nusantara', 'phone' => '081234567890',
                'joined' => 170, 'days' => 180, 'busy' => 4, 'active' => true,
                'products' => [
                    ['Kopi Gayo 250g', 'Kopi', 85000], ['Kopi Toraja 250g', 'Kopi', 95000], ['Kopi Sidikalang 250g', 'Kopi', 78000],
                    ['Teh Hijau Premium', 'Teh', 45000], ['Teh Melati 100g', 'Teh', 32000], ['Keripik Singkong', 'Snack', 18000],
                    ['Kacang Sangrai', 'Snack', 22000], ['French Press 600ml', 'Peralatan', 185000], ['Gelas Keramik', 'Peralatan', 55000], ['Grinder Manual', 'Peralatan', 260000],
                ],
                'customers' => ['Andi Wijaya', 'Siti Aminah', 'Rudi Hartono', 'Dewi Lestari', 'Fajar Nugroho', 'Maya Putri', 'Agus Salim', 'Rina Marlina'],
            ],
            [
                'name' => 'Siti Rahma', 'email' => 'siti@marketpulse.test', 'business' => 'Batik Rahma Medan', 'phone' => '082165432100',
                'joined' => 140, 'days' => 150, 'busy' => 3, 'active' => true,
                'products' => [
                    ['Kemeja Batik Pria', 'Batik', 245000], ['Dress Batik Wanita', 'Batik', 320000], ['Kain Batik Tulis 2m', 'Kain', 450000],
                    ['Selendang Songket', 'Aksesoris', 175000], ['Tas Anyaman', 'Aksesoris', 135000], ['Kemeja Batik Anak', 'Batik', 125000],
                    ['Sarung Tenun', 'Kain', 210000],
                ],
                'customers' => ['Lina Marbun', 'Tika Sinaga', 'Hendra Lubis', 'Nurul Hasibuan', 'Yoga Siregar', 'Ratna Dewi'],
            ],
            [
                'name' => 'Andi Pratama', 'email' => 'andi@marketpulse.test', 'business' => 'Gadget Corner', 'phone' => '081377788899',
                'joined' => 110, 'days' => 120, 'busy' => 5, 'active' => true,
                'products' => [
                    ['Earbuds Bluetooth', 'Audio', 189000], ['Power Bank 10000mAh', 'Aksesoris', 165000], ['Charger Fast 33W', 'Aksesoris', 95000],
                    ['Smartwatch Lite', 'Wearable', 449000], ['Speaker Mini', 'Audio', 215000], ['Kabel Type-C 1m', 'Aksesoris', 35000],
                    ['Case HP Premium', 'Aksesoris', 59000], ['Webcam HD', 'Perangkat', 275000],
                ],
                'customers' => ['Bayu Saputra', 'Citra Ananda', 'Dimas Aji', 'Elsa Fitri', 'Gilang Ramadhan', 'Hana Pertiwi', 'Irfan Maulana'],
            ],
            [
                'name' => 'Dewi Anggraini', 'email' => 'dewi@marketpulse.test', 'business' => 'Glow Beauty Store', 'phone' => '085212345678',
                'joined' => 75, 'days' => 90, 'busy' => 3, 'active' => true,
                'products' => [
                    ['Serum Vitamin C', 'Skincare', 129000], ['Moisturizer Gel', 'Skincare', 98000], ['Sunscreen SPF50', 'Skincare', 87000],
                    ['Lipstik Matte', 'Makeup', 65000], ['Cushion Compact', 'Makeup', 119000], ['Face Wash Herbal', 'Skincare', 45000],
                ],
                'customers' => ['Putri Amelia', 'Sarah Nabila', 'Tania Oktavia', 'Vina Maharani', 'Wulan Sari'],
            ],
            [
                'name' => 'Maya Sari', 'email' => 'maya@marketpulse.test', 'business' => 'Home & Living Store', 'phone' => '081998877665',
                'joined' => 40, 'days' => 45, 'busy' => 3, 'active' => true,
                'products' => [
                    ['Set Panci Anti Lengket', 'Dapur', 349000], ['Rice Cooker 1L', 'Dapur', 289000], ['Bantal Hotel', 'Kamar', 99000],
                    ['Lampu Meja LED', 'Dekorasi', 125000], ['Rak Sepatu', 'Perabot', 175000],
                ],
                'customers' => ['Joko Widodo S.', 'Kartika Sari', 'Lukman Hakim', 'Mira Handayani'],
            ],
            [
                'name' => 'Rizky Hakim', 'email' => 'rizky@marketpulse.test', 'business' => 'Warung Mie Hakim', 'phone' => '081211122233',
                'joined' => 20, 'days' => 25, 'busy' => 2, 'active' => false,
                'products' => [
                    ['Mie Gomak', 'Makanan', 28000], ['Mie Sop Ayam', 'Makanan', 24000], ['Es Teh Manis', 'Minuman', 7000], ['Kerupuk Ikan', 'Snack', 10000],
                ],
                'customers' => ['Nando Pane', 'Oscar Tampubolon', 'Pandu Nainggolan'],
            ],
            [
                'name' => 'Hendra Gunawan', 'email' => 'hendra@marketpulse.test', 'business' => 'Toko Buku Cendekia', 'phone' => '081355566677',
                'joined' => 55, 'days' => 60, 'busy' => 3, 'active' => true,
                'products' => [
                    ['Buku Tulis A5', 'ATK', 12000], ['Pulpen Gel 0.5mm', 'ATK', 8000], ['Pensil 2B Set', 'ATK', 15000],
                    ['Highlighter 5 Warna', 'ATK', 28000], ['Kalkulator Ilmiah', 'Elektronik', 135000], ['Tas Ransel Sekolah', 'Tas', 185000],
                    ['Map Plastik Folder', 'ATK', 6000],
                ],
                'customers' => ['Rahmat Hidayat', 'Syifa Nabila', 'Taufik Hasibuan', 'Ulfa Khairani', 'Vicky Pasaribu'],
            ],
            [
                'name' => 'Fajar Ritonga', 'email' => 'fajar@marketpulse.test', 'business' => 'Sport Station Rantau', 'phone' => '082277788811',
                'joined' => 30, 'days' => 35, 'busy' => 3, 'active' => true,
                'products' => [
                    ['Bola Futsal', 'Bola', 165000], ['Sepatu Lari Pria', 'Sepatu', 349000], ['Matras Yoga', 'Fitness', 120000],
                    ['Dumbbell 5kg', 'Fitness', 145000], ['Botol Minum 1L', 'Aksesoris', 45000], ['Raket Badminton', 'Raket', 210000],
                    ['Tali Skipping', 'Fitness', 35000],
                ],
                'customers' => ['Ilham Nasution', 'Joni Harahap', 'Khoirul Anam', 'Lutfi Rambe'],
            ],
            [
                'name' => 'Nur Aini', 'email' => 'nuraini@marketpulse.test', 'business' => 'Kebun Segar Organik', 'phone' => '085344455566',
                'joined' => 15, 'days' => 18, 'busy' => 3, 'active' => true,
                'products' => [
                    ['Beras Organik 5kg', 'Sembako', 89000], ['Madu Hutan 500ml', 'Sembako', 125000], ['Telur Ayam Kampung', 'Sembako', 38000],
                    ['Sayur Bayam Organik', 'Sayur & Buah', 9000], ['Pisang Barangan', 'Sayur & Buah', 22000], ['Minyak Kelapa 500ml', 'Sembako', 42000],
                ],
                'customers' => ['Mawar Siregar', 'Novita Sari', 'Oki Setiawan'],
            ],
            [
                'name' => 'Lestari Dewi', 'email' => 'lestari@marketpulse.test', 'business' => 'Bakery Lestari', 'phone' => '081566677788',
                'joined' => 95, 'days' => 100, 'busy' => 4, 'active' => true,
                'products' => [
                    ['Roti Tawar Gandum', 'Roti', 22000], ['Brownies Cokelat Box', 'Kue', 55000], ['Donat Mix 6 pcs', 'Roti', 36000],
                    ['Cheesecake Slice', 'Kue', 32000], ['Bolu Gulung Pandan', 'Kue', 45000], ['Croissant Butter', 'Roti', 18000], ['Kue Lapis Legit', 'Kue', 95000],
                ],
                'customers' => ['Amelia Siahaan', 'Bonar Silalahi', 'Cindy Napitupulu', 'Dedi Hutagalung', 'Evi Sitorus'],
            ],
            [
                'name' => 'Rendy Saragih', 'email' => 'rendy@marketpulse.test', 'business' => 'Sahabat Satwa Pet Shop', 'phone' => '082388899900',
                'joined' => 48, 'days' => 52, 'busy' => 3, 'active' => true,
                'products' => [
                    ['Makanan Kucing 1kg', 'Makanan Hewan', 68000], ['Makanan Anjing 2kg', 'Makanan Hewan', 115000], ['Pasir Kucing Wangi', 'Perawatan', 42000],
                    ['Kalung Hewan Reflektif', 'Aksesoris Hewan', 35000], ['Kandang Lipat Kecil', 'Aksesoris Hewan', 265000], ['Sampo Anti Kutu', 'Perawatan', 49000],
                ],
                'customers' => ['Gita Purnama', 'Harun Sihombing', 'Intan Permata', 'Jordan Situmorang'],
            ],
            [
                'name' => 'Kartini Melati', 'email' => 'kartini@marketpulse.test', 'business' => 'Mode Kita Fashion', 'phone' => '085266655544',
                'joined' => 22, 'days' => 26, 'busy' => 3, 'active' => true,
                'products' => [
                    ['Kaos Polos Premium', 'Pakaian', 65000], ['Kemeja Flanel', 'Pakaian', 145000], ['Celana Chino', 'Pakaian', 185000],
                    ['Jaket Denim', 'Pakaian', 275000], ['Sneakers Casual', 'Sepatu', 295000], ['Totebag Kanvas', 'Tas', 59000],
                ],
                'customers' => ['Karina Damanik', 'Leo Pasaribu', 'Mita Rajagukguk'],
            ],
        ];

        mt_srand(42);
        foreach ($owners as $cfg) {
            $this->seedOwner($cfg);
        }
    }

    private function seedOwner(array $cfg): void
    {
        $cfg['products'] = array_merge($cfg['products'], self::EXTRA[$cfg['email']]['products'] ?? []);
        $cfg['customers'] = array_merge($cfg['customers'], self::EXTRA[$cfg['email']]['customers'] ?? []);

        $owner = User::updateOrCreate(['email' => $cfg['email']], [
            'name' => $cfg['name'], 'password' => 'owner12345', 'role' => 'owner',
            'business_name' => $cfg['business'], 'phone' => $cfg['phone'], 'is_active' => $cfg['active'],
        ]);
        // Tanggal daftar disebar supaya grafik pendaftaran di Admin terisi
        $owner->forceFill(['created_at' => now()->subDays($cfg['joined'])])->save();

        if ($owner->sales()->exists()) {
            return;
        }

        $cats = [];
        foreach (collect($cfg['products'])->pluck(1)->unique() as $name) {
            $cats[$name] = Category::firstOrCreate(['user_id' => $owner->id, 'name' => $name])->id;
        }

        $products = collect($cfg['products'])->map(function ($p) use ($owner, $cats) {
            $product = Product::create([
                'user_id' => $owner->id, 'category_id' => $cats[$p[1]], 'name' => $p[0],
                'sku' => 'SKU-'.strtoupper(substr(md5($owner->id.$p[0]), 0, 5)), 'price' => $p[2], 'stock' => 5000, 'status' => 'active',
            ]);
            DemoPhotos::attach($product);

            return $product;
        });

        $customers = collect($cfg['customers'])->map(fn ($n) => Customer::create([
            'user_id' => $owner->id, 'name' => $n, 'email' => str_replace([' ', '.'], ['.', ''], strtolower($n)).'@example.com',
            'phone' => '08'.mt_rand(1000000000, 9999999999), 'address' => 'Medan, Sumatera Utara',
            'created_at' => now()->subDays(mt_rand(0, $cfg['days'])),
        ]));

        for ($day = $cfg['days']; $day >= 0; $day--) {
            // makin dekat ke hari ini makin ramai: tren naik yang terlihat di grafik
            $count = mt_rand(0, $cfg['busy']) + ($day < $cfg['days'] / 3 ? 1 : 0);
            for ($t = 0; $t < $count; $t++) {
                DB::transaction(function () use ($owner, $products, $customers, $day) {
                    $sale = Sale::create([
                        'user_id' => $owner->id, 'customer_id' => mt_rand(0, 9) < 8 ? $customers->random()->id : null,
                        'invoice_no' => 'INV-'.now()->subDays($day)->format('Ymd').'-'.strtoupper(bin2hex(random_bytes(3))),
                        'sold_at' => now()->subDays($day)->toDateString(), 'total' => 0,
                    ]);
                    $total = 0;
                    foreach ($products->random(min(mt_rand(1, 3), $products->count())) as $p) {
                        $qty = mt_rand(1, 4);
                        $sale->details()->create(['product_id' => $p->id, 'product_name' => $p->name, 'quantity' => $qty, 'price' => $p->price, 'subtotal' => $p->price * $qty]);
                        $p->decrement('stock', $qty);
                        $total += $p->price * $qty;
                    }
                    $sale->update(['total' => $total]);
                });
            }
        }

        // Stok akhir dibuat realistis: sebagian aman, sebagian menipis, sebagian habis
        // (supaya halaman Inventory, peringatan stok, dan Smart Insights punya data bermakna)
        foreach ($products as $p) {
            $r = mt_rand(1, 100);
            $p->update(['stock' => $r <= 8 ? 0 : ($r <= 26 ? mt_rand(1, 10) : mt_rand(15, 140))]);
        }
        $products[1]->update(['stock' => 6]);
        $products->last()->update(['stock' => 0]);
        if ($cfg['busy'] >= 4) {
            Product::create(['user_id' => $owner->id, 'category_id' => array_values($cats)[0], 'name' => 'Produk Musiman '.$owner->id.' (arsip)', 'price' => 40000, 'stock' => 12, 'status' => 'archived']);
        }
        DemoPhotos::attach(Product::create(['user_id' => $owner->id, 'category_id' => array_values($cats)[0], 'name' => 'Produk Baru (draft)', 'price' => 50000, 'stock' => 20, 'status' => 'draft']));
    }
}
