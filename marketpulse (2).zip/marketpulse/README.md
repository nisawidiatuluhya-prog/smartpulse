# MarketPulse: Smart Commerce Business Intelligence

Laravel 12 + MySQL + Bootstrap 5 + Chart.js. Semua tampilan (Blade) dan logika ada dalam satu proyek Laravel, tanpa backend terpisah.

## Kebutuhan
- PHP 8.2+ (ekstensi: pdo_mysql, mbstring, gd/fileinfo, xml, zip)
- Composer 2
- MySQL / MariaDB (XAMPP, Laragon, atau MySQL server biasa)

## Cara menjalankan
```bash
composer install
copy .env.example .env        # Linux/Mac: cp .env.example .env
php artisan key:generate
```
1. Buat database kosong bernama `marketpulse` di MySQL (phpMyAdmin atau `CREATE DATABASE marketpulse;`).
2. Cek `DB_USERNAME` dan `DB_PASSWORD` di file `.env`.

```bash
php artisan migrate --seed          # tabel + akun Admin + kategori global
php artisan db:seed --class=DemoSeeder   # OPSIONAL: akun demo + transaksi 6 bulan
php artisan storage:link            # agar gambar produk tampil
php artisan serve
```
Buka http://localhost:8000

## Akun
| Role | Email | Password |
|---|---|---|
| Admin | admin@marketpulse.test | admin12345 |
| Business Owner (jika DemoSeeder dijalankan) | owner@marketpulse.test | owner12345 |

Business Owner baru mendaftar lewat halaman **Register**. Segera ganti password Admin lewat menu Profile.

## Ganti nama website
Login sebagai Admin → **App Settings** → ubah Nama aplikasi. Nama default ada di `.env` (`APP_NAME`).

## Struktur singkat
- `app/Http/Controllers`: Dashboard, Product, Category, Sale, Customer, Analytics, Report, Admin/*
- `app/Support/Metrics.php`: semua query statistik dan grafik (data asli dari MySQL)
- `app/Http/Middleware/RoleMiddleware.php`: proteksi route berdasarkan role
- `database/migrations`: users, categories, products, customers, sales, sale_details, settings
- `resources/views`: layout, partials, dan seluruh halaman
- Isolasi data: setiap query bisnis dibatasi `user_id`; akses ke data milik owner lain menghasilkan 404.

## Foto produk demo (foto asli)
Aplikasi tidak lagi memakai ilustrasi. Taruh **foto asli** produk di `database/seeders/photos` dengan nama file sesuai slug produk
(daftar lengkap ada di `database/seeders/photos/DAFTAR_FOTO.md`). Lalu:
```
php artisan demo:photos --force     # pasang foto ke produk demo
php artisan storage:link
php artisan demo:photos-check       # tampilkan produk yang fotonya belum ada
```
Produk tanpa foto tetap tampil normal dengan ikon bawaan. Business Owner juga bisa mengunggah foto sendiri lewat form produk (JPG/PNG/WEBP, maks 2 MB).

## Akun demo tambahan (setelah `php artisan db:seed --class=DemoSeeder`)
Semua password `owner12345`: owner@, siti@, andi@, dewi@, maya@, rizky@ (nonaktif), hendra@, fajar@, nuraini@, lestari@, rendy@, kartini@ + `@marketpulse.test` (12 toko, 90+ produk).
Jika sebelumnya sudah pernah di-seed, ulangi dari awal supaya data baru masuk: `php artisan migrate:fresh --seed` lalu `php artisan db:seed --class=DemoSeeder`.

## Tampilan awal
Halaman `/` menampilkan splash (logo + nama aplikasi) sekali per sesi browser, lalu masuk ke landing. Logo ada di `public/img/logo.svg`; gaya di `public/css/landing.css`, perilaku di `public/js/landing.js`.

## Fitur tambahan (tanpa mengubah ERD)
**Admin:** dashboard lengkap (KPI + pertumbuhan, grafik 12 bulan, kategori & produk terlaris platform, peringkat owner, kesehatan platform, feed aktivitas), Platform Analytics, All Products, All Transactions (+export CSV), daftar owner dengan filter/urut/export, detail owner dengan grafik.
**Owner:** Inventory (restock cepat, perkiraan stok habis), Smart Insights (skor bisnis, insight otomatis, saran restock, produk lambat laku, pelanggan teratas), cetak invoice, kartu cepat di dashboard.
Semua dihitung dari tabel yang sudah ada (users, categories, products, customers, sales, sale_details, settings).
