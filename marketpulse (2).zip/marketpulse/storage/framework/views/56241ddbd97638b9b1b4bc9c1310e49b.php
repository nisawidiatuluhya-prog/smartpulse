<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
 body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #1c2434; }
 h1 { font-size: 16px; margin: 0 0 2px; } .muted { color: #6b7280; margin-bottom: 14px; }
 table { width: 100%; border-collapse: collapse; }
 th { background: #1b8bff; color: #fff; text-align: left; padding: 6px; font-size: 9px; }
 td { padding: 5px 6px; border-bottom: 1px solid #e5e7eb; }
 .r { text-align: right; } .sum { margin-top: 10px; font-weight: bold; }
</style></head>
<body>
 <h1><?php echo e($report['title']); ?></h1>
 <div class="muted"><?php echo e($user->business_name ?: $user->name); ?> · <?php echo e($from->format('d/m/Y')); ?> – <?php echo e($to->format('d/m/Y')); ?> · dicetak <?php echo e(now()->format('d/m/Y H:i')); ?></div>
 <table>
  <thead><tr><?php $__currentLoopData = $report['headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th class="<?php echo e(in_array($i, $report['money']) ? 'r' : ''); ?>"><?php echo e($h); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead>
  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $report['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr><?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td class="<?php echo e(in_array($i, $report['money']) ? 'r' : ''); ?>"><?php echo e(in_array($i, $report['money']) ? rp($cell) : $cell); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <tr><td colspan="<?php echo e(count($report['headers'])); ?>">Tidak ada data.</td></tr>
  <?php endif; ?>
  </tbody>
 </table>
 <?php if($report['summary']): ?><div class="sum"><?php echo e($report['summary']); ?></div><?php endif; ?>
</body></html>
<?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/reports/pdf.blade.php ENDPATH**/ ?>