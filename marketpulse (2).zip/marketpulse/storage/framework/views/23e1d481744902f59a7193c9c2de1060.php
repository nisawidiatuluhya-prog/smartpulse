<?php $__env->startSection('title', 'Business Owners'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3"><h2 class="fw-bold fs-4 mb-1">Business Owners</h2><div class="mp-sub">Kelola akun pemilik usaha yang terdaftar</div></div>
<form method="GET" class="mb-3" style="max-width:380px"><input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari nama, email, bisnis"></form>

<div class="mp-card p-0 overflow-hidden"><div class="mp-scroll">
<table class="mp-table">
    <thead><tr><th>Owner</th><th>Bisnis</th><th>Produk</th><th>Transaksi</th><th>Pendapatan</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><a href="<?php echo e(route('admin.owners.show', $o)); ?>" class="text-reset"><b><?php echo e($o->name); ?></b><br><span class="mp-sub"><?php echo e($o->email); ?></span></a></td>
            <td><?php echo e($o->business_name ?: '—'); ?></td>
            <td><?php echo e($o->products_count); ?></td>
            <td><?php echo e($o->sales_count); ?></td>
            <td class="num"><?php echo e(rp($o->sales_sum_total ?? 0)); ?></td>
            <td><?php if($o->is_active): ?><span class="mp-pill green">Aktif</span><?php else: ?><span class="mp-pill red">Nonaktif</span><?php endif; ?></td>
            <td class="text-end">
                <form method="POST" action="<?php echo e(route('admin.owners.toggle', $o)); ?>" class="d-inline"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="btn btn-sm btn-light border"><?php echo e($o->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?></button></form>
                <form method="POST" action="<?php echo e(route('admin.owners.destroy', $o)); ?>" class="d-inline" data-confirm="Hapus owner beserta SELURUH produk, pelanggan, dan transaksinya? Tidak bisa dibatalkan."><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger">Hapus</button></form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7"><div class="mp-empty"><i class="bi bi-people"></i>Belum ada Business Owner.</div></td></tr>
    <?php endif; ?>
    </tbody>
</table></div>
<?php if($owners->hasPages()): ?><div class="p-3"><?php echo e($owners->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/admin/owners.blade.php ENDPATH**/ ?>