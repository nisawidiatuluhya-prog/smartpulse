<?php $__env->startSection('title', 'Reports'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <h2 class="fw-bold fs-4 mb-1"><?php echo e($report['title']); ?></h2>
    <div class="mp-crumb">Dashboard <span>&gt;</span> Reports <span>&gt;</span> <?php echo e($report['title']); ?></div>
</div>

<div class="row g-3">
    <div class="col-lg-4 col-xl-3">
        <div class="mp-card">
            <h3 class="fw-bold fs-5 mb-4">Options</h3>
            <form method="GET">
                <div class="mb-3"><label class="form-label" for="type">Jenis laporan</label>
                    <select id="type" name="type" class="form-select"><?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($k); ?>" <?php if($type === $k): echo 'selected'; endif; ?>><?php echo e($l); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="mb-3"><label class="form-label" for="from">Between</label><input id="from" type="date" name="from" value="<?php echo e($from->toDateString()); ?>" class="form-control"></div>
                <div class="mb-4"><label class="form-label" for="to">And</label><input id="to" type="date" name="to" value="<?php echo e($to->toDateString()); ?>" class="form-control"></div>
                <div class="text-end"><button class="btn btn-primary">Generate Report</button></div>
            </form>
        </div>
    </div>

    <div class="col-lg-8 col-xl-9">
        <div class="d-flex flex-wrap justify-content-end align-items-center gap-2 mb-2 mp-export">
            <span class="mp-sub me-1">Export to</span>
            <?php $q = ['type' => $type, 'from' => $from->toDateString(), 'to' => $to->toDateString()]; ?>
            <a href="<?php echo e(route('reports.export', $q + ['format' => 'xls'])); ?>"><i class="bi bi-file-earmark-excel me-1"></i>XLS</a>
            <a href="<?php echo e(route('reports.export', $q + ['format' => 'csv'])); ?>"><i class="bi bi-filetype-csv me-1"></i>CSV</a>
            <a href="<?php echo e(route('reports.export', $q + ['format' => 'pdf'])); ?>"><i class="bi bi-file-earmark-pdf me-1"></i>PDF</a>
        </div>
        <div class="mp-card p-0 overflow-hidden">
            <div class="mp-scroll" style="max-height:560px">
            <table class="mp-table">
                <thead><tr><?php $__currentLoopData = $report['headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th class="<?php echo e(in_array($i, $report['money']) ? 'text-end' : ''); ?>"><?php echo e($h); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $report['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr><?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="<?php echo e(in_array($i, $report['money']) ? 'text-end num' : ''); ?>"><?php echo e(in_array($i, $report['money']) ? rp($cell) : ($cell === null || $cell === '' ? '—' : $cell)); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="<?php echo e(count($report['headers'])); ?>"><div class="mp-empty"><i class="bi bi-file-earmark-bar-graph"></i>Tidak ada data pada rentang tanggal ini.</div></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
        <?php if($report['summary']): ?><div class="mp-sub mt-2"><?php echo e($report['summary']); ?></div><?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/reports/index.blade.php ENDPATH**/ ?>