<?php $__env->startSection('title', 'Business Overview'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $palette = ['#6366f1', '#ec4899', '#f59e0b', '#06b6d4', '#10b981', '#8b5cf6', '#f43f5e'];
    $bar = fn ($c) => $c === null ? 100 : max(8, min(100, abs($c)));
    $statCards = [
        ['Total Revenue', rp_short($cards['revenue']['value']), $cards['revenue']['change'], 'pink', 'Last 30 days', 'bi-cash-stack'],
        ['Total Products', number_format($cards['products']['value'], 0, ',', '.'), $cards['products']['change'], 'indigo', $lowStock.' stok menipis', 'bi-box-seam'],
        ['Total Sales', number_format($cards['sales']['value'], 0, ',', '.'), $cards['sales']['change'], 'cyan', 'Last 30 days', 'bi-receipt'],
        ['Total Customers', number_format($cards['customers']['value'], 0, ',', '.'), $cards['customers']['change'], 'emerald', 'New, last 30 days', 'bi-people'],
    ];
?>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = $statCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $chg, $grad, $meta, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3">
            <div class="mp-card mp-stat g-<?php echo e($grad); ?>">
                <div class="label"><span><i class="bi <?php echo e($icon); ?> me-1"></i><?php echo e($label); ?></span><span class="value js-count"><?php echo e($value); ?></span></div>
                <div class="bar"><span style="width: <?php echo e($bar($chg)); ?>%"></span></div>
                <div class="meta"><span><?php echo e($meta); ?></span><?php echo $__env->make('partials.delta', ['change' => $chg], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = [
        ['bi-sun', 'orange', rp_short($quick['today_revenue']), $quick['today_orders'].' transaksi hari ini', route('sales.index')],
        ['bi-x-octagon', 'red', $quick['out'], 'Produk stok habis', route('inventory', ['state' => 'out'])],
        ['bi-box-seam', 'indigo', $quick['restock'], 'Perlu restock ≤14 hari', route('insights')],
        ['bi-hourglass-split', 'cyan', $quick['slow'], 'Produk lambat laku', route('insights')],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$ic, $c, $v, $l, $url]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3"><a class="mp-tile-link" href="<?php echo e($url); ?>"><div class="mp-kpi"><span class="ic <?php echo e($c); ?>"><i class="bi <?php echo e($ic); ?>"></i></span><div><b><?php echo e($v); ?></b><span><?php echo e($l); ?></span></div></div></a></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row g-3">
    <div class="col-xl-8">
        <div class="mp-card mb-3">
            <div class="mp-card-head">
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <div class="mp-seg" id="chartTabs">
                        <button type="button" class="on" data-mode="overview">Sales Overview</button>
                        <button type="button" data-mode="revenue">Monthly Revenue</button>
                    </div>
                </div>
                <form method="GET"><select name="range" class="form-select form-select-sm" style="width:130px" data-autosubmit>
                    <option value="12m" <?php if($view === '12m'): echo 'selected'; endif; ?>>Yearly</option>
                    <option value="30d" <?php if($view === '30d'): echo 'selected'; endif; ?>>Last 30 days</option>
                </select></form>
            </div>
            <div class="mp-chart"><canvas id="mainChart"></canvas></div>
        </div>

        <div class="mp-card">
            <div class="mp-card-head">
                <h2 class="mp-card-title">Recent Sales</h2>
                <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-sm btn-light">Lihat semua</a>
            </div>
            <?php if($recent->isEmpty()): ?>
                <div class="mp-empty"><i class="bi bi-receipt"></i>Belum ada transaksi. <a href="<?php echo e(route('sales.create')); ?>">Catat penjualan pertama</a>.</div>
            <?php else: ?>
                <div class="mp-scroll">
                <table class="mp-table">
                    <thead><tr><th>Invoice</th><th>Customer</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="<?php echo e(route('sales.show', $s)); ?>" class="d-flex align-items-center gap-2 text-reset fw-bold"><span class="mp-idx c<?php echo e($i % 6); ?>"><?php echo e(sprintf('%02d', $i + 1)); ?></span><?php echo e($s->invoice_no); ?></a></td>
                            <td><?php echo e($s->customer?->name ?? 'Umum'); ?></td>
                            <td><?php echo e($s->sold_at->translatedFormat('d M Y')); ?></td>
                            <td><?php echo e($s->details_count); ?></td>
                            <td class="num"><?php echo e(rp($s->total)); ?></td>
                            <td><span class="mp-pill green">Selesai</span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-xl-4">
        <div class="mp-card mb-3">
            <div class="mp-card-head"><h2 class="mp-card-title">Sales by Category</h2></div>
            <?php if($categories->isEmpty()): ?>
                <div class="mp-empty"><i class="bi bi-pie-chart"></i>Belum ada data penjualan.</div>
            <?php else: ?>
                <div class="mp-donut">
                    <canvas id="catChart"></canvas>
                    <div class="center"><div><b><?php echo e(round($categories->first()->units / $catTotal * 100)); ?>%</b><span><?php echo e($categories->first()->name); ?></span></div></div>
                </div>
                <div class="mp-legend">
                    <?php $__currentLoopData = $categories->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><i style="background: <?php echo e($palette[$i % count($palette)]); ?>"></i><?php echo e($c->name); ?><span class="v"><?php echo e(number_format($c->units, 0, ',', '.')); ?> unit</span></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="mp-card">
            <div class="mp-card-head"><h2 class="mp-card-title">Best Selling Products</h2></div>
            <?php if($topProducts->isEmpty()): ?>
                <div class="mp-empty"><i class="bi bi-box-seam"></i>Produk terlaris muncul setelah ada penjualan.</div>
            <?php else: ?>
                <ul class="mp-list">
                    <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <span class="mp-thumb c<?php echo e($i % 5); ?>"><?php if($p->image): ?><img src="<?php echo e(asset('storage/'.$p->image)); ?>" alt=""><?php else: ?><i class="bi bi-box-seam"></i><?php endif; ?></span>
                            <div><div class="nm"><?php echo e($p->name); ?></div><div class="sk"><?php echo e($p->sku ? '#'.$p->sku : '—'); ?></div></div>
                            <div class="end"><b><?php echo e(number_format($p->units, 0, ',', '.')); ?> unit</b><?php echo e(rp_short($p->revenue)); ?></div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(() => {
    const d = <?php echo json_encode($chart, 15, 512) ?>;
    const ctx = document.getElementById('mainChart');
    let chart;
    const grid = { color: '#eef1f7' };

    function draw(mode) {
        if (chart) chart.destroy();
        const grad = mpGradient(ctx, '99,102,241', .32, 300);
        const config = mode === 'overview' ? {
            type: 'line',
            data: { labels: d.labels, datasets: [
                { label: 'Revenue', data: d.revenue, borderColor: '#6366f1', backgroundColor: grad, fill: true, tension: .4, pointRadius: 0, pointHoverRadius: 5, borderWidth: 2.5, yAxisID: 'y' },
                { label: 'Units sold', data: d.units, borderColor: '#ec4899', tension: .4, pointRadius: 0, pointHoverRadius: 5, borderWidth: 2.5, yAxisID: 'y1' },
            ]},
            options: opts({ y: { grid, ticks: { callback: v => rpShort(v) }, beginAtZero: true }, y1: { position: 'right', grid: { display: false }, beginAtZero: true } }, true),
        } : {
            type: 'bar',
            data: { labels: d.labels, datasets: [{ label: 'Revenue', data: d.revenue, backgroundColor: mpGradient(ctx, '99,102,241', .95, 300), borderRadius: 8, maxBarThickness: 34 }] },
            options: opts({ y: { grid, ticks: { callback: v => rpShort(v) }, beginAtZero: true } }, false),
        };
        chart = new Chart(ctx, config);
    }

    function opts(scales, legend) {
        return {
            responsive: true, maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: { legend: { display: legend, position: 'top', align: 'start', labels: { usePointStyle: true, boxWidth: 8 } },
                tooltip: { callbacks: { label: c => c.dataset.label + ': ' + (c.dataset.label === 'Units sold' ? c.parsed.y.toLocaleString('id-ID') : rp(c.parsed.y)) } } },
            scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 12 } }, ...scales },
        };
    }

    document.querySelectorAll('#chartTabs button').forEach(b => b.addEventListener('click', () => {
        document.querySelectorAll('#chartTabs button').forEach(x => x.classList.toggle('on', x === b));
        draw(b.dataset.mode);
    }));
    draw('overview');

    <?php if($categories->isNotEmpty()): ?>
    new Chart(document.getElementById('catChart'), {
        type: 'doughnut',
        data: { labels: <?php echo json_encode($categories->pluck('name'), 15, 512) ?>, datasets: [{ data: <?php echo json_encode($categories->pluck('units')->map(fn ($v) => (int) $v), 15, 512) ?>, backgroundColor: <?php echo json_encode($palette, 15, 512) ?>, borderWidth: 3, borderColor: '#fff' }] },
        options: { cutout: '72%', maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => c.label + ': ' + c.parsed.toLocaleString('id-ID') + ' unit' } } } },
    });
    <?php endif; ?>
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/dashboard.blade.php ENDPATH**/ ?>