<?php $__env->startSection('title', 'Administration Overview'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $palette = ['#6366f1', '#ec4899', '#f59e0b', '#06b6d4', '#10b981', '#8b5cf6'];
    $maxRank = max(1, (float) ($ranking->max('revenue') ?? 0));
    $catTotal = max(1, (float) $categories->sum('revenue'));
    $bar = fn ($c) => $c === null ? 100 : max(8, min(100, abs($c)));
?>

<div class="mp-banner">
    <h2>Halo, <?php echo e(auth()->user()->name); ?> 👋</h2>
    <p><?php echo e(now()->translatedFormat('l, d F Y')); ?> · <?php echo e($stats['active']); ?> dari <?php echo e($stats['owners']); ?> Business Owner aktif · <?php echo e($stats['orders30']); ?> transaksi dalam 30 hari terakhir</p>
    <div class="acts">
        <a href="<?php echo e(route('admin.analytics')); ?>"><i class="bi bi-graph-up-arrow me-1"></i>Platform Analytics</a>
        <a href="<?php echo e(route('admin.owners', ['status' => 'inactive'])); ?>"><i class="bi bi-person-x me-1"></i>Owner nonaktif (<?php echo e($health['inactive_owners']); ?>)</a>
        <a href="<?php echo e(route('admin.products', ['stock' => 'out'])); ?>"><i class="bi bi-exclamation-triangle me-1"></i>Produk stok habis (<?php echo e($health['out_of_stock']); ?>)</a>
        <a href="<?php echo e(route('admin.categories.create')); ?>"><i class="bi bi-plus-lg me-1"></i>Kategori global</a>
        <a href="<?php echo e(route('admin.settings')); ?>"><i class="bi bi-sliders me-1"></i>Pengaturan</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = [
        ['Revenue 30 hari', rp_short($stats['rev30']), $stats['rev_change'], 'pink', 'Total: '.rp_short($stats['revenue']), 'bi-cash-stack'],
        ['Transaksi 30 hari', number_format($stats['orders30'], 0, ',', '.'), $stats['orders_change'], 'indigo', 'Total: '.number_format($stats['sales'], 0, ',', '.'), 'bi-receipt'],
        ['Owner baru 30 hari', number_format($stats['new_owners'], 0, ',', '.'), $stats['new_change'], 'cyan', $stats['owners'].' owner terdaftar', 'bi-person-plus'],
        ['Rata-rata transaksi', rp_short($stats['avg']), null, 'emerald', $stats['sellers'].' owner bertransaksi', 'bi-bag-check'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$l, $v, $chg, $g, $m, $i]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3"><div class="mp-card mp-stat g-<?php echo e($g); ?>">
            <div class="label"><span><i class="bi <?php echo e($i); ?> me-1"></i><?php echo e($l); ?></span><span class="value js-count"><?php echo e($v); ?></span></div>
            <div class="bar"><span style="width:<?php echo e($bar($chg)); ?>%"></span></div>
            <div class="meta"><span><?php echo e($m); ?></span><?php echo $__env->make('partials.delta', ['change' => $chg], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
        </div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = [
        ['bi-box-seam', 'indigo', number_format($stats['products'], 0, ',', '.'), 'Produk di platform'],
        ['bi-safe', 'emerald', rp_short($health['stock_value']), 'Nilai stok aktif'],
        ['bi-exclamation-triangle', 'orange', $health['low_stock'], 'Stok menipis'],
        ['bi-x-octagon', 'red', $health['out_of_stock'], 'Stok habis'],
        ['bi-person-dash', 'pink', $health['no_sales_owners'], 'Owner belum bertransaksi'],
        ['bi-cash-coin', 'cyan', rp_short($stats['per_seller']), 'Rata-rata revenue/owner'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$ic, $c, $v, $l]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-lg-4 col-xl-2"><div class="mp-kpi"><span class="ic <?php echo e($c); ?>"><i class="bi <?php echo e($ic); ?>"></i></span><div><b><?php echo e($v); ?></b><span><?php echo e($l); ?></span></div></div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-8">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Pendapatan &amp; transaksi platform</h2><span class="mp-sub">12 bulan terakhir</span></div>
            <div class="mp-chart"><canvas id="revChart"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Kategori terlaris</h2><span class="mp-sub">90 hari</span></div>
            <?php if($categories->isEmpty()): ?>
                <div class="mp-empty"><i class="bi bi-pie-chart"></i>Belum ada penjualan.</div>
            <?php else: ?>
                <div class="mp-donut"><canvas id="catChart"></canvas><div class="center"><div><b><?php echo e(round($categories->first()->revenue / $catTotal * 100)); ?>%</b><span><?php echo e($categories->first()->name); ?></span></div></div></div>
                <div class="mp-legend">
                    <?php $__currentLoopData = $categories->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><i style="background: <?php echo e($palette[$i % 6]); ?>"></i><?php echo e($c->name); ?><span class="v"><?php echo e(rp_short($c->revenue)); ?></span></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-5">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Peringkat owner</h2><a href="<?php echo e(route('admin.owners', ['sort' => 'revenue'])); ?>" class="btn btn-sm btn-light">Semua</a></div>
            <?php if($ranking->isEmpty()): ?>
                <div class="mp-empty"><i class="bi bi-trophy"></i>Belum ada transaksi 30 hari terakhir.</div>
            <?php else: ?>
                <ul class="mp-rank">
                    <?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <span class="no"><?php echo e($i + 1); ?></span>
                            <div class="nm"><a href="<?php echo e(route('admin.owners.show', $r->id)); ?>" class="text-reset"><?php echo e($r->business_name ?: $r->name); ?></a><small><?php echo e($r->orders); ?> transaksi · 30 hari</small>
                                <div class="mp-meter"><i style="width: <?php echo e(round($r->revenue / $maxRank * 100)); ?>%"></i></div></div>
                            <div class="val"><?php echo e(rp_short($r->revenue)); ?></div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Produk terlaris platform</h2><span class="mp-sub">90 hari</span></div>
            <?php if($topProducts->isEmpty()): ?>
                <div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada data.</div>
            <?php else: ?>
                <ul class="mp-rank">
                    <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><span class="no"><?php echo e($i + 1); ?></span><div class="nm"><?php echo e($p->name); ?><small>dijual <?php echo e($p->sellers); ?> toko</small></div><div class="val"><?php echo e(number_format($p->units, 0, ',', '.')); ?> unit<small><?php echo e(rp_short($p->revenue)); ?></small></div></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-xl-3">
        <div class="mp-card h-100">
            <h2 class="mp-card-title mb-2">Kesehatan platform</h2>
            <?php
                $hrows = [
                    ['Owner nonaktif', $health['inactive_owners'], 'warn', route('admin.owners', ['status' => 'inactive'])],
                    ['Owner tanpa transaksi', $health['no_sales_owners'], 'warn', route('admin.owners', ['sort' => 'sales'])],
                    ['Produk stok habis', $health['out_of_stock'], 'bad', route('admin.products', ['stock' => 'out'])],
                    ['Produk stok menipis', $health['low_stock'], 'warn', route('admin.products', ['stock' => 'low'])],
                    ['Produk draft', $health['draft_products'], 'warn', route('admin.products', ['status' => 'draft'])],
                    ['Produk diarsipkan', $health['archived_products'], 'warn', route('admin.products', ['status' => 'archived'])],
                    ['Tanpa kategori', $health['uncategorized'], 'warn', route('admin.products')],
                ];
            ?>
            <ul class="mp-health">
                <?php $__currentLoopData = $hrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$l, $n, $tone, $url]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e($url); ?>" class="text-reset text-decoration-none"><?php echo e($l); ?></a><span class="n <?php echo e($n > 0 ? $tone : ''); ?>"><?php echo e($n); ?></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-xl-7">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Aktivitas terbaru</h2><a href="<?php echo e(route('admin.sales')); ?>" class="btn btn-sm btn-light">Semua transaksi</a></div>
            <?php if($activity->isEmpty()): ?>
                <div class="mp-empty"><i class="bi bi-activity"></i>Belum ada aktivitas.</div>
            <?php else: ?>
                <ul class="mp-feed">
                    <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <span class="dot" style="background: <?php echo e($a['type'] === 'sale' ? 'linear-gradient(135deg,#10b981,#14b8a6)' : 'linear-gradient(135deg,#6366f1,#8b5cf6)'); ?>"><i class="bi <?php echo e($a['type'] === 'sale' ? 'bi-receipt' : 'bi-person-plus'); ?>"></i></span>
                            <div><div class="t"><a href="<?php echo e(route('admin.owners.show', $a['owner_id'])); ?>" class="text-reset text-decoration-none"><?php echo e($a['title']); ?></a></div><div class="m"><?php echo e($a['meta']); ?></div></div>
                            <span class="when"><?php echo e($a['at']->diffForHumans()); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-xl-5">
        <div class="mp-card mb-3">
            <div class="mp-card-head"><h2 class="mp-card-title">Pertumbuhan owner</h2><span class="mp-sub">pendaftar per bulan</span></div>
            <div class="mp-chart sm"><canvas id="regChart"></canvas></div>
        </div>
        <div class="mp-card">
            <h2 class="mp-card-title mb-3">Pendaftar terbaru</h2>
            <ul class="mp-list">
                <?php $__empty_1 = true; $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li><span class="mp-thumb c<?php echo e($i % 5); ?>" style="font-weight:800;font-size:.8rem"><?php echo e($o->initials); ?></span>
                        <div><div class="nm"><?php echo e($o->name); ?></div><div class="sk"><?php echo e($o->business_name ?: $o->email); ?></div></div>
                        <div class="end"><?php if($o->is_active): ?><span class="mp-pill green">Aktif</span><?php else: ?><span class="mp-pill red">Nonaktif</span><?php endif; ?><div class="mt-1"><?php echo e($o->created_at->diffForHumans(null, true, true)); ?></div></div></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="mp-sub">Belum ada pendaftar.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(() => {
    const m = <?php echo json_encode($monthly, 15, 512) ?>;
    const rev = document.getElementById('revChart');
    new Chart(rev, {
        type: 'bar',
        data: {
            labels: m.labels,
            datasets: [
                { type: 'bar', label: 'Pendapatan', data: m.revenue, backgroundColor: mpGradient(rev, '99,102,241', .9, 320), borderRadius: 8, maxBarThickness: 34, yAxisID: 'y' },
                { type: 'line', label: 'Transaksi', data: m.orders, borderColor: '#ec4899', backgroundColor: '#ec4899', tension: .4, borderWidth: 3, pointRadius: 4, pointBackgroundColor: '#fff', pointBorderColor: '#ec4899', pointBorderWidth: 2, yAxisID: 'y1' },
            ],
        },
        options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
            plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } }, tooltip: { callbacks: { label: c => c.dataset.yAxisID === 'y' ? ' ' + rp(c.parsed.y) : ' ' + c.parsed.y + ' transaksi' } } },
            scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#eef0fa' }, ticks: { callback: v => rpShort(v) } }, y1: { beginAtZero: true, position: 'right', grid: { display: false }, ticks: { precision: 0 } } } },
    });
    const reg = document.getElementById('regChart');
    new Chart(reg, {
        type: 'bar',
        data: { labels: m.labels, datasets: [{ label: 'Owner baru', data: m.owners, backgroundColor: mpGradient(reg, '236,72,153', .95, 220), borderRadius: 8, maxBarThickness: 22 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { maxRotation: 0, autoSkip: true } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#eef0fa' } } } },
    });
    const cat = document.getElementById('catChart');
    if (cat) new Chart(cat, {
        type: 'doughnut',
        data: { labels: <?php echo json_encode($categories->pluck('name'), 15, 512) ?>, datasets: [{ data: <?php echo json_encode($categories->pluck('revenue')->map(fn ($v) => (float) $v), 15, 512) ?>, backgroundColor: ['#6366f1', '#ec4899', '#f59e0b', '#06b6d4', '#10b981', '#8b5cf6'], borderWidth: 3, borderColor: '#fff', hoverOffset: 8 }] },
        options: { cutout: '72%', maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => ' ' + c.label + ': ' + rp(c.parsed) } } } },
    });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>