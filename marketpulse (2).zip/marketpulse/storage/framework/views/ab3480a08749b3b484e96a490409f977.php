<?php $__env->startSection('title', $owner->business_name ?: $owner->name); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3 mb-3">
    <?php $__currentLoopData = [['Produk', $owner->products_count], ['Pelanggan', $owner->customers_count], ['Transaksi', $owner->sales_count], ['Pendapatan', rp_short($owner->sales_sum_total ?? 0)]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$l, $v]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3"><div class="mp-card"><div class="mp-sub"><?php echo e($l); ?></div><div class="fs-3 fw-bold js-count"><?php echo e($v); ?></div></div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row g-3">
    <div class="col-lg-4"><div class="mp-card">
        <h2 class="mp-card-title mb-3"><?php echo e($owner->name); ?></h2>
        <div class="mp-sub">Email</div><div class="mb-2"><?php echo e($owner->email); ?></div>
        <div class="mp-sub">Bisnis</div><div class="mb-2"><?php echo e($owner->business_name ?: '—'); ?></div>
        <div class="mp-sub">Telepon</div><div class="mb-2"><?php echo e($owner->phone ?: '—'); ?></div>
        <div class="mp-sub">Terdaftar</div><div class="mb-3"><?php echo e($owner->created_at->translatedFormat('d M Y')); ?></div>
        <a href="<?php echo e(route('admin.owners')); ?>" class="btn btn-light border btn-sm">Kembali</a>
    </div></div>
    <div class="col-lg-8"><div class="mp-card p-0 overflow-hidden">
        <div class="p-3 pb-0"><h2 class="mp-card-title">Transaksi terbaru</h2></div>
        <table class="mp-table"><thead><tr><th>No.</th><th>Tanggal</th><th>Pelanggan</th><th class="text-end">Total</th></tr></thead><tbody>
        <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr><td><b><?php echo e($s->invoice_no); ?></b></td><td><?php echo e($s->sold_at->translatedFormat('d M Y')); ?></td><td><?php echo e($s->customer?->name ?? 'Umum'); ?></td><td class="text-end num"><?php echo e(rp($s->total)); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4"><div class="mp-empty">Belum ada transaksi.</div></td></tr>
        <?php endif; ?>
        </tbody></table>
    </div></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/admin/owner-show.blade.php ENDPATH**/ ?>