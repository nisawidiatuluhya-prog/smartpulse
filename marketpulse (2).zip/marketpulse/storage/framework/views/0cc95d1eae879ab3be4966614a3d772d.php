<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-start mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Categories</h2><div class="mp-sub">Kelompokkan produk agar analisis per kategori akurat</div></div>
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Add category</a>
</div>
<div class="mp-card p-0 overflow-hidden">
    <table class="mp-table">
        <thead><tr><th>Nama</th><th>Deskripsi</th><th>Produk</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><b><?php echo e($c->name); ?></b> <?php if (! ($c->user_id)): ?><span class="mp-pill blue ms-1">Global</span><?php endif; ?></td>
                <td class="mp-sub"><?php echo e($c->description ?: '—'); ?></td>
                <td><?php echo e($c->products_count); ?></td>
                <td class="text-end">
                    <?php if($c->user_id): ?>
                        <a href="<?php echo e(route('categories.edit', $c)); ?>" class="btn btn-sm btn-light border">Edit</a>
                        <form method="POST" action="<?php echo e(route('categories.destroy', $c)); ?>" class="d-inline" data-confirm="Hapus kategori ini?"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger">Hapus</button></form>
                    <?php else: ?>
                        <span class="mp-sub">Dikelola Admin</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4"><div class="mp-empty"><i class="bi bi-tags"></i>Belum ada kategori.</div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/categories/index.blade.php ENDPATH**/ ?>