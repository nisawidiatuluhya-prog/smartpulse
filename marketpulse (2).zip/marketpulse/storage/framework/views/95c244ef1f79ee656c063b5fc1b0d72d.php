<?php $__env->startSection('title', 'Sales'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Sales</h2><div class="mp-sub">Riwayat transaksi penjualan Anda</div></div>
    <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Catat penjualan</a>
</div>

<form method="GET" class="row g-2 mb-3">
    <div class="col-md-4"><input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari invoice atau pelanggan"></div>
    <div class="col-6 col-md-2"><input type="date" name="from" value="<?php echo e($hasFilter ? $from->toDateString() : ''); ?>" class="form-control" aria-label="Dari tanggal"></div>
    <div class="col-6 col-md-2"><input type="date" name="to" value="<?php echo e($hasFilter ? $to->toDateString() : ''); ?>" class="form-control" aria-label="Sampai tanggal"></div>
    <div class="col-md-4 d-flex gap-2"><button class="btn btn-primary">Terapkan</button><a href="<?php echo e(route('sales.index')); ?>" class="btn btn-light border">Reset</a></div>
</form>

<div class="mp-card p-0 overflow-hidden">
    <div class="mp-scroll">
    <table class="mp-table">
        <thead><tr><th>No. Transaksi</th><th>Tanggal</th><th>Pelanggan</th><th>Item</th><th>Total</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><a href="<?php echo e(route('sales.show', $s)); ?>" class="fw-bold text-reset"><?php echo e($s->invoice_no); ?></a></td>
                <td><?php echo e($s->sold_at->translatedFormat('d M Y')); ?></td>
                <td><?php echo e($s->customer?->name ?? 'Umum'); ?></td>
                <td><?php echo e($s->details_count); ?></td>
                <td class="num"><?php echo e(rp($s->total)); ?></td>
                <td class="text-end">
                    <a href="<?php echo e(route('sales.show', $s)); ?>" class="btn btn-sm btn-light border">Detail</a>
                    <form method="POST" action="<?php echo e(route('sales.destroy', $s)); ?>" class="d-inline" data-confirm="Hapus transaksi ini? Stok produk akan dikembalikan."><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger">Hapus</button></form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-receipt"></i>Belum ada transaksi. <a href="<?php echo e(route('sales.create')); ?>">Catat penjualan pertama</a>.</div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
    <?php if($sales->hasPages()): ?><div class="p-3"><?php echo e($sales->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/sales/index.blade.php ENDPATH**/ ?>