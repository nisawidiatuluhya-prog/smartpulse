<?php $c = $change ?? null; ?>
<?php if($c === null): ?>
    <span class="mp-delta flat">–</span>
<?php elseif($c >= 0): ?>
    <span class="mp-delta up"><i class="bi bi-arrow-up-right"></i><?php echo e(number_format($c, 1, ',', '.')); ?>%</span>
<?php else: ?>
    <span class="mp-delta down"><i class="bi bi-arrow-down-right"></i><?php echo e(number_format(abs($c), 1, ',', '.')); ?>%</span>
<?php endif; ?>
<?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/partials/delta.blade.php ENDPATH**/ ?>