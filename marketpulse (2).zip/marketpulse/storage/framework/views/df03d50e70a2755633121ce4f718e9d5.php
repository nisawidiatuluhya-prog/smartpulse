<?php if(session('success')): ?>
    <div class="alert alert-success border-0 rounded-3 d-flex align-items-center gap-2 py-2" role="alert"><i class="bi bi-check-circle-fill"></i><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if($errors->any() && ! request()->routeIs('login', 'register')): ?>
    <div class="alert alert-danger border-0 rounded-3 py-2" role="alert">
        <div class="fw-bold mb-1">Periksa kembali isian Anda:</div>
        <ul class="mb-0 ps-3"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/partials/flash.blade.php ENDPATH**/ ?>