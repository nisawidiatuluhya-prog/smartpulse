<?php $__env->startSection('title', 'Platform Analytics'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $periods = [7 => '7 hari', 30 => '30 hari', 90 => '90 hari', 365 => '365 hari'];
    $groups = ['day' => 'Harian', 'week' => 'Mingguan', 'month' => 'Bulanan'];
    $maxRank = max(1, (float) ($ranking->max('revenue') ?? 0));
    $maxProd = max(1, (float) ($topProducts->max('units') ?? 0));
    $catRev = max(1, (float) $categories->sum('revenue'));
    $bestIdx = array_sum($weekday['revenue']) > 0 ? array_search(max($weekday['revenue']), $weekday['revenue']) : null;
?>

<form method="GET" class="mp-filter">
    <select name="period" class="form-select form-select-sm" onchange="this.form.from.value='';this.form.to.value='';this.form.submit()">
        <option value="">Periode cepat</option>
        <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($v); ?>" <?php if((int) request('period') === $v): echo 'selected'; endif; ?>><?php echo e($l); ?> terakhir</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="date" name="from" value="<?php echo e($from->toDateString()); ?>" class="form-control form-control-sm" aria-label="Dari">
    <input type="date" name="to" value="<?php echo e($to->toDateString()); ?>" class="form-control form-control-sm" aria-label="Sampai">
    <select name="group" class="form-select form-select-sm">
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($v); ?>" <?php if($group === $v): echo 'selected'; endif; ?>><?php echo e($l); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-primary btn-sm">Terapkan</button>
    <span class="mp-sub ms-auto"><?php echo e($from->translatedFormat('d M Y')); ?> – <?php echo e($to->translatedFormat('d M Y')); ?> (<?php echo e($days); ?> hari)</span>
</form>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = [
        ['Revenue platform', rp_short($cur['revenue']), $changes['revenue'], 'indigo', 'bi-cash-stack'],
        ['Transaksi', number_format($cur['orders'], 0, ',', '.'), $changes['orders'], 'pink', 'bi-receipt'],
        ['Unit terjual', number_format($cur['units'], 0, ',', '.'), $changes['units'], 'cyan', 'bi-box-seam'],
        ['Owner bertransaksi', number_format($cur['sellers'], 0, ',', '.'), $changes['sellers'], 'emerald', 'bi-shop'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$l, $v, $chg, $g, $i]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3"><div class="mp-card mp-stat g-<?php echo e($g); ?>">
            <div class="label"><span><i class="bi <?php echo e($i); ?> me-1"></i><?php echo e($l); ?></span><span class="value js-count"><?php echo e($v); ?></span></div>
            <div class="bar"><span style="width:<?php echo e($chg === null ? 100 : max(8, min(100, abs($chg)))); ?>%"></span></div>
            <div class="meta"><span>vs periode sebelumnya</span><?php echo $__env->make('partials.delta', ['change' => $chg], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
        </div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-8"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Tren pendapatan &amp; transaksi</h2><span class="mp-sub">Rata-rata transaksi <?php echo e(rp($cur['avg'])); ?> · rata-rata per owner <?php echo e(rp_short($cur['per_seller'])); ?></span></div>
        <div class="mp-chart"><canvas id="trend"></canvas></div>
    </div></div>
    <div class="col-xl-4"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Pendapatan per hari</h2><?php if($bestIdx !== null): ?><span class="mp-pill green">Terbaik: <?php echo e($weekday['labels'][$bestIdx]); ?></span><?php endif; ?></div>
        <div class="mp-chart"><canvas id="weekday"></canvas></div>
    </div></div>
</div>

<div class="row g-3">
    <div class="col-xl-4"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Kategori terlaris</h2></div>
        <?php if($categories->isEmpty()): ?><div class="mp-empty"><i class="bi bi-tags"></i>Belum ada data.</div>
        <?php else: ?>
            <div class="mp-hbar">
                <?php $__currentLoopData = $categories->take(7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $share = round($c->revenue / $catRev * 100, 1); ?>
                    <div class="row2"><div class="fill" style="width: <?php echo e(max($share, 24)); ?>%"><span><?php echo e($c->name); ?></span><small><?php echo e($share); ?>%</small></div></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div></div>
    <div class="col-xl-4"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Produk terlaris</h2></div>
        <?php if($topProducts->isEmpty()): ?><div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada data.</div>
        <?php else: ?>
            <ul class="mp-rank">
                <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><span class="no"><?php echo e($i + 1); ?></span><div class="nm"><?php echo e($p->name); ?><small><?php echo e($p->sellers); ?> toko</small><div class="mp-meter"><i style="width: <?php echo e(round($p->units / $maxProd * 100)); ?>%"></i></div></div><div class="val"><?php echo e(number_format($p->units, 0, ',', '.')); ?><small>unit</small></div></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div></div>
    <div class="col-xl-4"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Perbandingan owner</h2></div>
        <?php if($ranking->isEmpty()): ?><div class="mp-empty"><i class="bi bi-trophy"></i>Belum ada transaksi.</div>
        <?php else: ?>
            <ul class="mp-rank">
                <?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><span class="no"><?php echo e($i + 1); ?></span><div class="nm"><a href="<?php echo e(route('admin.owners.show', $r->id)); ?>" class="text-reset"><?php echo e($r->business_name ?: $r->name); ?></a><small><?php echo e($r->orders); ?> transaksi</small><div class="mp-meter"><i style="width: <?php echo e(round($r->revenue / $maxRank * 100)); ?>%"></i></div></div><div class="val"><?php echo e(rp_short($r->revenue)); ?></div></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(() => {
    const s = <?php echo json_encode($series, 15, 512) ?>, w = <?php echo json_encode($weekday, 15, 512) ?>;
    const t = document.getElementById('trend');
    new Chart(t, {
        type: 'bar',
        data: { labels: s.labels, datasets: [
            { type: 'line', label: 'Pendapatan', data: s.revenue, borderColor: '#6366f1', backgroundColor: mpGradient(t, '99,102,241', .3, 320), fill: true, tension: .4, borderWidth: 3, pointRadius: s.labels.length > 40 ? 0 : 3, yAxisID: 'y' },
            { type: 'bar', label: 'Transaksi', data: s.orders, backgroundColor: 'rgba(236,72,153,.55)', borderRadius: 5, maxBarThickness: 14, yAxisID: 'y1' },
        ] },
        options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
            plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } }, tooltip: { callbacks: { label: c => c.dataset.yAxisID === 'y' ? ' ' + rp(c.parsed.y) : ' ' + c.parsed.y + ' transaksi' } } },
            scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 12 } }, y: { beginAtZero: true, grid: { color: '#eef0fa' }, ticks: { callback: v => rpShort(v) } }, y1: { beginAtZero: true, position: 'right', grid: { display: false }, ticks: { precision: 0 } } } },
    });
    const d = document.getElementById('weekday');
    new Chart(d, {
        type: 'bar',
        data: { labels: w.labels.map(x => x.slice(0, 3)), datasets: [{ label: 'Pendapatan', data: w.revenue, backgroundColor: ['#6366f1', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#f43f5e'], borderRadius: 8, maxBarThickness: 30 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => ' ' + rp(c.parsed.y) } } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#eef0fa' }, ticks: { callback: v => rpShort(v) } } } },
    });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/admin/analytics.blade.php ENDPATH**/ ?>