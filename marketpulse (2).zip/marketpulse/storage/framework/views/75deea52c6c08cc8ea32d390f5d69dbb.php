<?php $__env->startSection('title', 'Daftar'); ?>
<?php $__env->startSection('body'); ?>
<div class="mp-auth">
    <div class="mp-auth-side">
        <a href="<?php echo e(route('home')); ?>" class="mp-logo text-white p-0"><i class="bi bi-activity"></i><?php echo e($appName); ?></a>
        <div>
            <h2>Mulai kelola bisnis Anda dengan data, bukan perkiraan.</h2>
            <p class="mt-3">Daftar gratis, tambahkan produk, catat penjualan pertama, dan lihat grafik performa langsung terisi.</p>
        </div>
        <small class="opacity-75"><?php echo e($appTagline); ?></small>
    </div>
    <div class="mp-auth-form">
        <div class="mp-auth-box">
            <h3 class="fw-bold mb-1">Buat akun Business Owner</h3>
            <p class="mp-sub mb-4">Sudah punya akun? <a href="<?php echo e(route('login')); ?>" class="fw-bold">Masuk</a></p>

            <form method="POST" action="<?php echo e(route('register')); ?>" novalidate>
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = [['name','Nama lengkap','text'],['business_name','Nama bisnis','text'],['email','Email','email'],['phone','Nomor telepon (opsional)','text']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$f,$l,$t]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-3">
                        <label class="form-label" for="<?php echo e($f); ?>"><?php echo e($l); ?></label>
                        <input id="<?php echo e($f); ?>" type="<?php echo e($t); ?>" name="<?php echo e($f); ?>" value="<?php echo e(old($f)); ?>" class="form-control <?php $__errorArgs = [$f];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php echo e($f !== 'phone' ? 'required' : ''); ?>>
                        <?php $__errorArgs = [$f];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row g-3 mb-4">
                    <div class="col-6">
                        <label class="form-label" for="password">Password</label>
                        <input id="password" type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6">
                        <label class="form-label" for="password_confirmation">Ulangi password</label>
                        <input id="password_confirmation" type="password" name="password_confirmation" class="form-control" required>
                    </div>
                </div>
                <button class="btn btn-primary w-100 py-2">Daftar &amp; masuk ke dashboard</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/auth/register.blade.php ENDPATH**/ ?>