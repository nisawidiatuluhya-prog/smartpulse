<?php $__env->startSection('title', 'All Transactions'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Semua Transaksi</h2><div class="mp-sub">Pantau penjualan seluruh Business Owner (hanya baca)</div></div>
    <a href="<?php echo e(route('admin.sales.export', request()->query())); ?>" class="btn btn-light border btn-sm"><i class="bi bi-download me-1"></i>Export CSV</a>
</div>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = [
        ['bi-receipt', 'indigo', number_format($summary['count'], 0, ',', '.'), 'Transaksi'],
        ['bi-cash-stack', 'emerald', rp_short($summary['revenue']), 'Total pendapatan'],
        ['bi-bag-check', 'pink', rp_short($summary['avg']), 'Rata-rata transaksi'],
        ['bi-shop', 'cyan', $summary['owners'], 'Owner terlibat'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$ic, $c, $v, $l]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3"><div class="mp-kpi"><span class="ic <?php echo e($c); ?>"><i class="bi <?php echo e($ic); ?>"></i></span><div><b><?php echo e($v); ?></b><span><?php echo e($l); ?></span></div></div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<form method="GET" class="mp-filter">
    <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control form-control-sm" placeholder="Invoice / pelanggan">
    <select name="owner" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua owner</option>
        <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($o->id); ?>" <?php if((int) request('owner') === $o->id): echo 'selected'; endif; ?>><?php echo e($o->business_name ?: $o->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="form-control form-control-sm" aria-label="Dari">
    <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="form-control form-control-sm" aria-label="Sampai">
    <button class="btn btn-primary btn-sm">Terapkan</button>
    <?php if(request()->hasAny(['q', 'owner', 'from', 'to'])): ?><a href="<?php echo e(route('admin.sales')); ?>" class="btn btn-light border btn-sm">Reset</a><?php endif; ?>
</form>

<div class="mp-card p-0 overflow-hidden"><div class="mp-scroll">
<table class="mp-table">
    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Owner</th><th>Pelanggan</th><th>Item</th><th class="text-end">Total</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><b><?php echo e($s->invoice_no); ?></b></td>
            <td><?php echo e($s->sold_at->translatedFormat('d M Y')); ?></td>
            <td><a href="<?php echo e(route('admin.owners.show', $s->user_id)); ?>" class="text-reset"><?php echo e($s->user->business_name ?: $s->user->name); ?></a></td>
            <td><?php echo e($s->customer?->name ?? 'Umum'); ?></td>
            <td><?php echo e($s->details_count); ?></td>
            <td class="text-end num"><?php echo e(rp($s->total)); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-receipt"></i>Tidak ada transaksi yang cocok.</div></td></tr>
    <?php endif; ?>
    </tbody>
</table></div>
<?php if($sales->hasPages()): ?><div class="p-3"><?php echo e($sales->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/admin/sales.blade.php ENDPATH**/ ?>