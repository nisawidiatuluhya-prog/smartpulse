<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('heading', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-3">
    <div>
        <h2 class="fw-bold fs-4 mb-1">Products</h2>
        <div class="mp-sub">Kelola inventaris, harga, dan ketersediaan produk Anda</div>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('products.export')); ?>" class="btn btn-light border"><i class="bi bi-download me-1"></i>Export</a>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Add product</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = [
        ['TOTAL PRODUCTS', 'bi-box-seam', number_format($stats['products'][0], 0, ',', '.'), $stats['products'][1]],
        ['TOTAL REVENUE', 'bi-currency-dollar', rp_short($stats['revenue'][0]), $stats['revenue'][1]],
        ['TOTAL ORDERS', 'bi-cart3', number_format($stats['orders'][0], 0, ',', '.'), $stats['orders'][1]],
        ['CUSTOMERS', 'bi-people', number_format($stats['customers'][0], 0, ',', '.'), $stats['customers'][1]],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $icon, $value, $chg]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3">
            <div class="mp-card" style="padding:14px 18px">
                <div class="mp-sub fw-bold" style="font-size:.7rem;letter-spacing:.02em"><i class="bi <?php echo e($icon); ?> me-1"></i><?php echo e($label); ?></div>
                <div class="fw-bold fs-4 my-1 js-count"><?php echo e($value); ?></div>
                <div class="d-flex justify-content-between align-items-center mp-sub" style="font-size:.72rem">
                    <?php echo $__env->make('partials.delta', ['change' => $chg], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><span>Last 7 days</span>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
    <form method="GET" class="d-flex gap-2 flex-grow-1" style="max-width:520px">
        <?php if($status): ?><input type="hidden" name="status" value="<?php echo e($status); ?>"><?php endif; ?>
        <input type="hidden" name="view" value="<?php echo e($view); ?>">
        <div class="position-relative flex-grow-1">
            <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search by product name or SKU">
        </div>
        <select name="stock" class="form-select w-auto" data-autosubmit>
            <option value="">Semua stok</option>
            <option value="low" <?php if(request('stock') === 'low'): echo 'selected'; endif; ?>>Stok menipis</option>
            <option value="out" <?php if(request('stock') === 'out'): echo 'selected'; endif; ?>>Stok habis</option>
        </select>
    </form>
    <div class="d-flex align-items-center gap-2">
    <div class="mp-viewtoggle">
        <a href="<?php echo e(route('products.index', array_filter(['status' => $status, 'q' => request('q'), 'stock' => request('stock'), 'view' => 'grid']))); ?>" class="<?php echo e($view === 'grid' ? 'on' : ''); ?>" title="Tampilan kartu"><i class="bi bi-grid-fill"></i></a>
        <a href="<?php echo e(route('products.index', array_filter(['status' => $status, 'q' => request('q'), 'stock' => request('stock'), 'view' => 'list']))); ?>" class="<?php echo e($view === 'list' ? 'on' : ''); ?>" title="Tampilan tabel"><i class="bi bi-list-ul"></i></a>
    </div>
    <div class="mp-tabs">
        <?php $__currentLoopData = ['all' => 'All', 'active' => 'Active', 'draft' => 'Drafts', 'archived' => 'Archived']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('products.index', array_filter(['status' => $k === 'all' ? null : $k, 'q' => request('q'), 'stock' => request('stock'), 'view' => $view]))); ?>"
               class="<?php echo e(($status ?? 'all') === $k || ($k === 'all' && ! $status) ? 'active' : ''); ?>"><?php echo e($l); ?> <span class="mp-sub"><?php echo e($tabs[$k]); ?></span></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
</div>

<?php if($view === 'list'): ?>
<div class="mp-card p-0 overflow-hidden">
    <form id="bulkForm" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mp-scroll">
        <table class="mp-table">
            <thead><tr>
                <th style="width:44px"><input type="checkbox" class="form-check-input" id="checkAll" aria-label="Pilih semua"></th>
                <th>Product Name</th><th>ID &amp; Create Date</th><th>Price</th><th>Stock</th><th>Status</th>
            </tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?php echo e($p->id); ?>" class="form-check-input row-check"></td>
                    <td>
                        <a href="<?php echo e(route('products.edit', $p)); ?>" class="d-flex align-items-center gap-3 text-reset">
                            <span class="mp-thumb c<?php echo e($p->id % 5); ?>"><?php if($p->image_url): ?><img src="<?php echo e($p->image_url); ?>" alt=""><?php else: ?><i class="bi bi-box-seam"></i><?php endif; ?></span>
                            <span><b><?php echo e($p->name); ?></b><br><span class="mp-sub"><?php echo e($p->category?->name ?? 'Tanpa kategori'); ?></span></span>
                        </a>
                    </td>
                    <td><b>#<?php echo e($p->sku ?: 'P'.str_pad($p->id, 5, '0', STR_PAD_LEFT)); ?></b><br><span class="mp-sub"><?php echo e($p->created_at->translatedFormat('M d, Y')); ?></span></td>
                    <td><b><?php echo e(rp($p->price)); ?></b></td>
                    <td><?php echo e(number_format($p->stock, 0, ',', '.')); ?>

                        <?php if($p->stock_status === 'low'): ?><span class="mp-pill orange ms-1">Menipis</span><?php endif; ?></td>
                    <td>
                        <?php if($p->stock_status === 'out'): ?><span class="mp-pill orange">Out of stock</span>
                        <?php elseif($p->status === 'active'): ?><span class="mp-pill green">Published</span>
                        <?php elseif($p->status === 'draft'): ?><span class="mp-pill gray">Draft</span>
                        <?php else: ?><span class="mp-pill red">Inactive</span><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada produk yang cocok. <a href="<?php echo e(route('products.create')); ?>">Tambah produk</a>.</div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </form>
    <?php if($products->hasPages()): ?><div class="p-3"><?php echo e($products->links()); ?></div><?php endif; ?>
</div>

<div class="mp-bulkbar" id="bulkBar">
    <span class="sel"><span id="selCount">0</span> Selected</span>
    <button type="submit" form="bulkForm" formaction="<?php echo e(route('products.bulk-export')); ?>"><i class="bi bi-download me-1"></i>Export</button>
    <button type="button" id="editOne"><i class="bi bi-pencil me-1"></i>Edit Info</button>
    <button type="submit" form="bulkForm" formaction="<?php echo e(route('products.bulk-delete')); ?>" id="bulkDelete"><i class="bi bi-trash me-1"></i>Delete</button>
    <button type="button" id="clearSel" aria-label="Batal"><i class="bi bi-x-lg"></i></button>
</div>
<?php else: ?>
    <?php if($products->isEmpty()): ?>
        <div class="mp-card"><div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada produk yang cocok. <a href="<?php echo e(route('products.create')); ?>">Tambah produk</a>.</div></div>
    <?php else: ?>
        <div class="row g-3 mp-pgrid">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-4 col-xl-3" style="--n: <?php echo e($loop->index); ?>">
                    <a href="<?php echo e(route('products.edit', $p)); ?>" class="mp-pcard">
                        <div class="pimg">
                            <?php if($p->image_url): ?>
                                <img src="<?php echo e($p->image_url); ?>" alt="<?php echo e($p->name); ?>" loading="lazy">
                            <?php else: ?>
                                <span class="pph"><i class="bi bi-image"></i></span>
                            <?php endif; ?>
                            <div class="pbadges">
                                <?php if($p->stock_status === 'out'): ?><span class="pbadge out">Habis</span>
                                <?php elseif($p->stock_status === 'low'): ?><span class="pbadge low">Stok menipis</span><?php endif; ?>
                                <?php if($p->status === 'draft'): ?><span class="pbadge">Draft</span>
                                <?php elseif($p->status === 'archived'): ?><span class="pbadge out">Arsip</span><?php endif; ?>
                            </div>
                        </div>
                        <div class="pbody">
                            <div class="pcat"><?php echo e($p->category?->name ?? 'Tanpa kategori'); ?></div>
                            <h3><?php echo e($p->name); ?></h3>
                            <div class="pfoot"><b><?php echo e(rp($p->price)); ?></b><span class="pstock"><i class="bi bi-box2"></i> <?php echo e(number_format($p->stock, 0, ',', '.')); ?></span></div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($products->hasPages()): ?><div class="mt-3"><?php echo e($products->links()); ?></div><?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php if($view === 'list'): ?>
<?php $__env->startPush('scripts'); ?>
<script>
(() => {
    const checks = () => [...document.querySelectorAll('.row-check')];
    const bar = document.getElementById('bulkBar');
    const edits = <?php echo json_encode($products->mapWithKeys(fn ($p) => [$p->id => route('products.edit', $p)]), 512) ?>;
    function sync() {
        const sel = checks().filter(c => c.checked);
        document.getElementById('selCount').textContent = sel.length;
        bar.classList.toggle('show', sel.length > 0);
        document.getElementById('editOne').disabled = sel.length !== 1;
    }
    document.getElementById('checkAll').addEventListener('change', e => { checks().forEach(c => c.checked = e.target.checked); sync(); });
    checks().forEach(c => c.addEventListener('change', sync));
    document.getElementById('clearSel').addEventListener('click', () => { checks().forEach(c => c.checked = false); document.getElementById('checkAll').checked = false; sync(); });
    document.getElementById('editOne').addEventListener('click', () => { const s = checks().find(c => c.checked); if (s) location.href = edits[s.value]; });
    document.getElementById('bulkDelete').addEventListener('click', e => { if (!confirm('Hapus produk yang dipilih? Tindakan ini tidak bisa dibatalkan.')) e.preventDefault(); });
})();
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/products/index.blade.php ENDPATH**/ ?>