<?php $__env->startSection('title', 'All Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3"><h2 class="fw-bold fs-4 mb-1">Semua Produk</h2><div class="mp-sub">Pantau katalog dan stok seluruh Business Owner (hanya baca)</div></div>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = [
        ['bi-box-seam', 'indigo', number_format($summary['count'], 0, ',', '.'), 'Produk'],
        ['bi-stack', 'cyan', number_format($summary['units'], 0, ',', '.'), 'Total unit stok'],
        ['bi-safe', 'emerald', rp_short($summary['value']), 'Nilai stok'],
        ['bi-exclamation-triangle', 'orange', $summary['low'], 'Stok menipis'],
        ['bi-x-octagon', 'red', $summary['out'], 'Stok habis'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$ic, $c, $v, $l]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl"><div class="mp-kpi"><span class="ic <?php echo e($c); ?>"><i class="bi <?php echo e($ic); ?>"></i></span><div><b><?php echo e($v); ?></b><span><?php echo e($l); ?></span></div></div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<form method="GET" class="mp-filter">
    <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control form-control-sm" placeholder="Nama / SKU">
    <select name="owner" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua owner</option>
        <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($o->id); ?>" <?php if((int) request('owner') === $o->id): echo 'selected'; endif; ?>><?php echo e($o->business_name ?: $o->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="status" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua status</option>
        <?php $__currentLoopData = ['active' => 'Active', 'draft' => 'Draft', 'archived' => 'Archived']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($v); ?>" <?php if(request('status') === $v): echo 'selected'; endif; ?>><?php echo e($l); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="stock" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua stok</option>
        <option value="low" <?php if(request('stock') === 'low'): echo 'selected'; endif; ?>>Menipis</option>
        <option value="out" <?php if(request('stock') === 'out'): echo 'selected'; endif; ?>>Habis</option>
    </select>
    <select name="sort" class="form-select form-select-sm" data-autosubmit>
        <?php $__currentLoopData = ['' => 'Terbaru', 'name' => 'Nama A-Z', 'price' => 'Harga tertinggi', 'stock' => 'Stok tersedikit']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($v); ?>" <?php if((string) request('sort') === (string) $v): echo 'selected'; endif; ?>><?php echo e($l); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-primary btn-sm">Cari</button>
    <?php if(request()->hasAny(['q', 'owner', 'status', 'stock', 'sort'])): ?><a href="<?php echo e(route('admin.products')); ?>" class="btn btn-light border btn-sm">Reset</a><?php endif; ?>
</form>

<div class="mp-card p-0 overflow-hidden"><div class="mp-scroll">
<table class="mp-table">
    <thead><tr><th>Produk</th><th>Owner</th><th>Kategori</th><th class="text-end">Harga</th><th>Stok</th><th>Status</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $st = $p->stock <= 0 ? 'out' : ($p->stock <= \App\Models\Product::LOW_STOCK ? 'low' : 'ok'); ?>
        <tr>
            <td><div class="d-flex align-items-center gap-3">
                <span class="mp-thumb c<?php echo e($i % 5); ?>"><?php if($p->image): ?><img src="<?php echo e(asset('storage/'.$p->image)); ?>" alt=""><?php else: ?><i class="bi bi-box-seam"></i><?php endif; ?></span>
                <span><b><?php echo e($p->name); ?></b><br><span class="mp-sub"><?php echo e($p->sku ? '#'.$p->sku : '—'); ?></span></span></div></td>
            <td><a href="<?php echo e(route('admin.owners.show', $p->user_id)); ?>" class="text-reset"><?php echo e($p->user->business_name ?: $p->user->name); ?></a></td>
            <td><?php echo e($p->category?->name ?? '—'); ?></td>
            <td class="text-end num"><?php echo e(rp($p->price)); ?></td>
            <td><span class="mp-pill <?php echo e(['ok' => 'green', 'low' => 'orange', 'out' => 'red'][$st]); ?>"><?php echo e($p->stock); ?> unit</span></td>
            <td><span class="mp-pill <?php echo e(['active' => 'green', 'draft' => 'gray', 'archived' => 'blue'][$p->status] ?? 'gray'); ?>"><?php echo e(ucfirst($p->status)); ?></span></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-box-seam"></i>Tidak ada produk yang cocok.</div></td></tr>
    <?php endif; ?>
    </tbody>
</table></div>
<?php if($products->hasPages()): ?><div class="p-3"><?php echo e($products->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/admin/products.blade.php ENDPATH**/ ?>