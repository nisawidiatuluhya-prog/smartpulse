<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Customers</h2><div class="mp-sub">Data pelanggan dan total belanja mereka</div></div>
    <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Add customer</a>
</div>
<form method="GET" class="mb-3" style="max-width:380px"><input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari nama, email, telepon"></form>

<div class="mp-card p-0 overflow-hidden">
    <div class="mp-scroll">
    <table class="mp-table">
        <thead><tr><th>Pelanggan</th><th>Kontak</th><th>Transaksi</th><th>Total belanja</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><a href="<?php echo e(route('customers.show', $c)); ?>" class="d-flex align-items-center gap-3 text-reset"><span class="mp-thumb c<?php echo e($c->id % 5); ?>"><?php echo e(mb_substr($c->name, 0, 1)); ?></span><b><?php echo e($c->name); ?></b></a></td>
                <td><?php echo e($c->email ?: '—'); ?><br><span class="mp-sub"><?php echo e($c->phone ?: ''); ?></span></td>
                <td><?php echo e($c->sales_count); ?></td>
                <td class="num"><?php echo e(rp($c->sales_sum_total ?? 0)); ?></td>
                <td class="text-end">
                    <a href="<?php echo e(route('customers.show', $c)); ?>" class="btn btn-sm btn-light border">Riwayat</a>
                    <a href="<?php echo e(route('customers.edit', $c)); ?>" class="btn btn-sm btn-light border">Edit</a>
                    <form method="POST" action="<?php echo e(route('customers.destroy', $c)); ?>" class="d-inline" data-confirm="Hapus pelanggan ini?"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger">Hapus</button></form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5"><div class="mp-empty"><i class="bi bi-people"></i>Belum ada pelanggan.</div></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
    <?php if($customers->hasPages()): ?><div class="p-3"><?php echo e($customers->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/customers/index.blade.php ENDPATH**/ ?>