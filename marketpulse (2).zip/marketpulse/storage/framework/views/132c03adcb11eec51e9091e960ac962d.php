<?php $__env->startSection('title', 'Inventory'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Inventory</h2><div class="mp-sub">Pantau stok semua produk aktif dan isi ulang dengan cepat</div></div>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Produk baru</a>
</div>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = [
        ['bi-box-seam', 'indigo', $summary['products'], 'Produk aktif', 'all'],
        ['bi-check-circle', 'emerald', $summary['ok'], 'Stok aman', 'ok'],
        ['bi-exclamation-triangle', 'orange', $summary['low'], 'Stok menipis', 'low'],
        ['bi-x-octagon', 'red', $summary['out'], 'Stok habis', 'out'],
        ['bi-safe', 'cyan', rp_short($summary['value']), $summary['units'].' unit tersimpan', 'all'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$ic, $c, $v, $l, $st]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl"><a class="mp-tile-link" href="<?php echo e(route('inventory', ['state' => $st])); ?>"><div class="mp-kpi"><span class="ic <?php echo e($c); ?>"><i class="bi <?php echo e($ic); ?>"></i></span><div><b><?php echo e($v); ?></b><span><?php echo e($l); ?></span></div></div></a></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<form method="GET" class="mp-filter">
    <div class="mp-seg">
        <?php $__currentLoopData = ['all' => 'Semua', 'low' => 'Menipis', 'out' => 'Habis', 'ok' => 'Aman']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('inventory', ['state' => $k, 'q' => request('q')])); ?>" class="<?php echo e($state === $k ? 'on' : ''); ?>" style="text-decoration:none;display:inline-block"><?php echo e($l); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <input type="hidden" name="state" value="<?php echo e($state); ?>">
    <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control form-control-sm" placeholder="Cari produk / SKU" style="min-width:220px">
    <button class="btn btn-primary btn-sm">Cari</button>
</form>

<div class="mp-card p-0 overflow-hidden"><div class="mp-scroll">
<table class="mp-table">
    <thead><tr><th>Produk</th><th>Kategori</th><th style="min-width:160px">Stok</th><th>Laju jual</th><th>Perkiraan habis</th><th class="text-end">Tambah stok</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            $st = $p->stock <= 0 ? 'out' : ($p->stock <= \App\Models\Product::LOW_STOCK ? 'low' : 'ok');
            $perDay = ($velocity[$p->id] ?? 0) / 30;
            $days = $perDay > 0 ? (int) floor($p->stock / $perDay) : null;
            $pct = min(100, max(4, $p->stock / 60 * 100));
        ?>
        <tr>
            <td><div class="d-flex align-items-center gap-3">
                <span class="mp-thumb c<?php echo e($i % 5); ?>"><?php if($p->image): ?><img src="<?php echo e(asset('storage/'.$p->image)); ?>" alt=""><?php else: ?><i class="bi bi-box-seam"></i><?php endif; ?></span>
                <span><b><?php echo e($p->name); ?></b><br><span class="mp-sub"><?php echo e($p->sku ? '#'.$p->sku : '—'); ?></span></span></div></td>
            <td><?php echo e($p->category?->name ?? '—'); ?></td>
            <td><b><?php echo e($p->stock); ?></b> <span class="mp-pill <?php echo e(['ok' => 'green', 'low' => 'orange', 'out' => 'red'][$st]); ?>"><?php echo e(['ok' => 'Aman', 'low' => 'Menipis', 'out' => 'Habis'][$st]); ?></span>
                <div class="mp-stockbar mt-1"><i class="<?php echo e($st); ?>" style="width: <?php echo e($st === 'out' ? 100 : $pct); ?>%"></i></div></td>
            <td><?php echo e($perDay > 0 ? number_format($perDay, 1, ',', '.').' /hari' : '—'); ?></td>
            <td><?php if($days === null): ?><span class="mp-sub">Belum ada data</span><?php elseif($p->stock <= 0): ?><span class="mp-pill red">Sudah habis</span><?php else: ?><span class="mp-pill <?php echo e($days <= 7 ? 'red' : ($days <= 14 ? 'orange' : 'green')); ?>">± <?php echo e($days); ?> hari</span><?php endif; ?></td>
            <td class="text-end">
                <form method="POST" action="<?php echo e(route('inventory.restock', $p)); ?>" class="mp-restock"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <input type="number" name="quantity" min="1" max="100000" value="10" class="form-control form-control-sm" aria-label="Jumlah tambah stok <?php echo e($p->name); ?>">
                    <button class="btn btn-sm btn-primary" title="Tambah stok"><i class="bi bi-plus-lg"></i></button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-boxes"></i>Tidak ada produk pada filter ini.</div></td></tr>
    <?php endif; ?>
    </tbody>
</table></div>
<?php if($products->hasPages()): ?><div class="p-3"><?php echo e($products->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/inventory.blade.php ENDPATH**/ ?>