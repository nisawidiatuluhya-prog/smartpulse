<?php $__env->startSection('title', 'Analytics'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Analytics Overview</h2><div class="mp-sub">Detailed insights into your business performance</div></div>
    <form method="GET" class="d-flex flex-wrap gap-2 align-items-center">
        <select name="period" class="form-select form-select-sm w-auto" onchange="this.form.from.value='';this.form.to.value='';this.form.submit()">
            <option value="">Periode cepat</option>
            <?php $__currentLoopData = [7 => '7 hari', 30 => '30 hari', 90 => '90 hari', 365 => '12 bulan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($v); ?>" <?php if((int) request('period') === $v): echo 'selected'; endif; ?>><?php echo e($l); ?> terakhir</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="date" name="from" value="<?php echo e($from->toDateString()); ?>" class="form-control form-control-sm w-auto" aria-label="Dari">
        <input type="date" name="to" value="<?php echo e($to->toDateString()); ?>" class="form-control form-control-sm w-auto" aria-label="Sampai">
        <select name="group" class="form-select form-select-sm w-auto">
            <?php $__currentLoopData = ['day' => 'Daily', 'week' => 'Weekly', 'month' => 'Monthly']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($v); ?>" <?php if($group === $v): echo 'selected'; endif; ?>><?php echo e($l); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn btn-primary btn-sm">Terapkan</button>
        <a href="<?php echo e(route('reports', ['from' => $from->toDateString(), 'to' => $to->toDateString()])); ?>" class="btn btn-light border btn-sm"><i class="bi bi-download me-1"></i>Export</a>
    </form>
</div>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3">
            <div class="mp-card mp-big">
                <div class="ico"><i class="bi <?php echo e($c['icon']); ?>"></i></div>
                <div class="lbl"><?php echo e($c['label']); ?></div>
                <div class="row1"><span class="num js-count"><?php echo e($c['value']); ?></span><?php echo $__env->make('partials.delta', ['change' => $c['change']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-7">
        <div class="mp-card">
            <div class="mp-card-head"><h2 class="mp-card-title">Revenue Trend</h2><span class="mp-sub"><?php echo e($from->translatedFormat('d M Y')); ?> – <?php echo e($to->translatedFormat('d M Y')); ?></span></div>
            <div class="mp-chart" style="height:300px"><canvas id="trend"></canvas></div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="mp-card">
            <div class="mp-card-head"><h2 class="mp-card-title">Sales by Category</h2><span class="mp-sub">% unit terjual</span></div>
            <?php if($categories->isEmpty()): ?>
                <div class="mp-empty"><i class="bi bi-bar-chart"></i>Belum ada penjualan pada periode ini.</div>
            <?php else: ?>
                <div class="mp-hbar">
                    <?php $__currentLoopData = $categories->take(7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $share = round($cat->units / $catUnits * 100, 1); ?>
                        <div class="row2"><div class="fill" style="width: <?php echo e(max($share, 22)); ?>%"><span><?php echo e($cat->name); ?></span><small><?php echo e($share); ?>%</small></div></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mp-axis"><span>0%</span><span>20%</span><span>40%</span><span>60%</span><span>80%</span><span>100%</span></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="mp-card p-0 overflow-hidden">
            <div class="p-3 pb-0"><h2 class="mp-card-title">Produk terlaris</h2></div>
            <div class="mp-scroll">
            <table class="mp-table">
                <thead><tr><th>Produk</th><th class="text-end">Unit</th><th class="text-end">Pendapatan</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr><td><span class="d-flex align-items-center gap-2"><span class="mp-idx c<?php echo e($i % 6); ?>"><?php echo e($i + 1); ?></span><b><?php echo e($p->name); ?></b></span></td><td class="text-end"><?php echo e(number_format($p->units, 0, ',', '.')); ?></td><td class="text-end num"><?php echo e(rp($p->revenue)); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3"><div class="mp-empty">Belum ada data pada periode ini.</div></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="mp-card">
            <h2 class="mp-card-title mb-3">Ringkasan performa</h2>
            <?php $__currentLoopData = [
                ['Total pendapatan', rp($cur['revenue']), pct_change($cur['revenue'], $prev['revenue'])],
                ['Jumlah transaksi', number_format($cur['orders'], 0, ',', '.'), pct_change($cur['orders'], $prev['orders'])],
                ['Rata-rata per transaksi', rp($cur['avg']), pct_change($cur['avg'], $prev['avg'])],
                ['Pelanggan yang membeli', number_format($cur['buyers'], 0, ',', '.'), pct_change($cur['buyers'], $prev['buyers'])],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$l, $v, $chg]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                    <span class="mp-sub"><?php echo e($l); ?></span><span class="d-flex align-items-center gap-2"><b><?php echo e($v); ?></b><?php echo $__env->make('partials.delta', ['change' => $chg], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="mp-sub mt-3" style="font-size:.72rem">Persentase dibandingkan periode sebelumnya dengan panjang yang sama.</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(() => {
    const s = <?php echo json_encode($series, 15, 512) ?>;
    const ctx = document.getElementById('trend').getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 0, 300);
    grad.addColorStop(0, 'rgba(99,102,241,.38)'); grad.addColorStop(1, 'rgba(99,102,241,0)');
    new Chart(ctx, {
        type: 'line',
        data: { labels: s.labels, datasets: [{ label: 'Revenue', data: s.revenue, borderColor: '#6366f1', backgroundColor: grad, fill: true, tension: .35, borderWidth: 2.5, pointRadius: s.labels.length > 40 ? 0 : 3, pointBackgroundColor: '#fff', pointBorderColor: '#6366f1', pointBorderWidth: 2, pointHoverRadius: 7 }] },
        options: {
            responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => 'Revenue: ' + rp(c.parsed.y) } } },
            scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 8 } }, y: { beginAtZero: true, grid: { color: '#eef1f7' }, ticks: { callback: v => rpShort(v) } } },
        },
    });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/analytics.blade.php ENDPATH**/ ?>