<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> · <?php echo e($appName); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(filemtime(public_path('css/app.css'))); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/theme.css')); ?>?v=<?php echo e(filemtime(public_path('css/theme.css'))); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/extra.css')); ?>?v=<?php echo e(filemtime(public_path('css/extra.css'))); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>
<?php
    $user = auth()->user();
    if ($user->isAdmin()) {
        $menu = [
            ['admin.dashboard', 'bi-grid-1x2', 'Dashboard', 'admin.dashboard'],
            ['admin.analytics', 'bi-graph-up-arrow', 'Platform Analytics', 'admin.analytics'],
            ['admin.owners', 'bi-people', 'Business Owners', 'admin.owners*'],
            ['admin.products', 'bi-box-seam', 'All Products', 'admin.products'],
            ['admin.sales', 'bi-receipt', 'All Transactions', 'admin.sales*'],
            ['admin.categories.index', 'bi-tags', 'Categories', 'admin.categories.*'],
            ['admin.settings', 'bi-sliders', 'App Settings', 'admin.settings'],
        ];
        $homeRoute = 'admin.dashboard';
    } else {
        $menu = [
            ['dashboard', 'bi-grid-1x2', 'Dashboard', 'dashboard'],
            ['products.index', 'bi-box-seam', 'Products', 'products.*'],
            ['inventory', 'bi-boxes', 'Inventory', 'inventory*'],
            ['categories.index', 'bi-tags', 'Categories', 'categories.*'],
            ['sales.index', 'bi-receipt', 'Sales', 'sales.*'],
            ['customers.index', 'bi-people', 'Customers', 'customers.*'],
            ['analytics', 'bi-graph-up-arrow', 'Analytics', 'analytics'],
            ['insights', 'bi-stars', 'Smart Insights', 'insights'],
            ['reports', 'bi-file-earmark-bar-graph', 'Reports', 'reports*'],
        ];
        $homeRoute = 'dashboard';
    }
?>
<div class="mp-shell">
    <aside class="mp-sidebar" id="mpSidebar">
        <a href="<?php echo e(route($homeRoute)); ?>" class="mp-logo"><i class="bi bi-activity"></i><?php echo e($appName); ?></a>

        <ul class="mp-nav">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $icon, $label, $pattern]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route($route)); ?>" class="<?php echo e(request()->routeIs($pattern) ? 'active' : ''); ?>"><i class="bi <?php echo e($icon); ?>"></i><?php echo e($label); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <?php if (! ($user->isAdmin())): ?>
            <div class="mp-side-cta">
                <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary w-100 mb-3"><i class="bi bi-plus-square me-2"></i>New Sale</a>
                <a href="<?php echo e(route('products.create')); ?>" class="mp-upload">
                    <i class="bi bi-cloud-arrow-up"></i>
                    <b>Upload new product</b>
                    Tambahkan produk &amp; gambar
                </a>
            </div>
        <?php endif; ?>

        <ul class="mp-nav mp-side-bottom">
            <li><a href="<?php echo e(route('profile')); ?>" class="<?php echo e(request()->routeIs('profile*') ? 'active' : ''); ?>"><i class="bi bi-person"></i>Profile</a></li>
            <?php if (! ($user->isAdmin())): ?>
                <li><a href="<?php echo e(route('settings')); ?>" class="<?php echo e(request()->routeIs('settings*') ? 'active' : ''); ?>"><i class="bi bi-gear"></i>Settings</a></li>
            <?php endif; ?>
            <li>
                <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?>
                    <button type="submit" class="mp-nav-btn" style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:10px;color:#6c7589;font-weight:600;font-size:.84rem">
                        <i class="bi bi-box-arrow-right" style="font-size:1.05rem"></i>Logout
                    </button>
                </form>
            </li>
        </ul>
    </aside>

    <main class="mp-main">
        <header class="mp-topbar">
            <button class="mp-icon-btn mp-menu-toggle" data-sidebar-toggle aria-label="Menu"><i class="bi bi-list" style="font-size:1.5rem"></i></button>
            <h1 class="mp-title"><?php if (! empty(trim($__env->yieldContent('heading')))): ?><?php echo $__env->yieldContent('heading'); ?><?php else: ?> <?php echo $__env->yieldContent('title', 'Dashboard'); ?> <?php endif; ?></h1>

            <?php if (! ($user->isAdmin())): ?>
                <form class="mp-search" action="<?php echo e(route('products.index')); ?>" method="GET" role="search">
                    <input type="search" name="q" class="form-control" placeholder="Cari produk..." value="<?php echo e(request()->routeIs('products.*') ? request('q') : ''); ?>">
                    <i class="bi bi-search"></i>
                </form>
            <?php endif; ?>

            <div class="mp-top-actions">
                <?php if (! ($user->isAdmin())): ?>
                    <a href="<?php echo e(route('products.index', ['stock' => 'low'])); ?>" class="mp-icon-btn" title="Stok menipis">
                        <i class="bi bi-bell"></i>
                        <?php if($lowStockCount): ?><span class="dot"><?php echo e($lowStockCount); ?></span><?php endif; ?>
                    </a>
                <?php endif; ?>
                <div class="dropdown">
                    <button class="mp-avatar" data-bs-toggle="dropdown" aria-label="Akun"><?php echo e($user->initials); ?></button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                        <li class="px-3 py-2"><div class="fw-bold"><?php echo e($user->name); ?></div><div class="mp-sub"><?php echo e($user->isAdmin() ? 'Administrator' : ($user->business_name ?: 'Business Owner')); ?></div></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profile</a></li>
                        <?php if (! ($user->isAdmin())): ?><li><a class="dropdown-item" href="<?php echo e(route('settings')); ?>">Settings</a></li><?php endif; ?>
                        <li><form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="dropdown-item">Logout</button></form></li>
                    </ul>
                </div>
            </div>
        </header>

        <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script src="<?php echo e(asset('js/app.js')); ?>?v=<?php echo e(filemtime(public_path('js/app.js'))); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/layouts/app.blade.php ENDPATH**/ ?>