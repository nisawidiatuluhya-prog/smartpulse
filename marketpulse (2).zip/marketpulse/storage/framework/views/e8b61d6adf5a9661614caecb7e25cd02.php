<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('body'); ?>
<div class="mp-auth">
    <div class="mp-auth-side">
        <a href="<?php echo e(route('home')); ?>" class="mp-logo text-white p-0"><i class="bi bi-activity"></i><?php echo e($appName); ?></a>
        <div>
            <h2>Pantau penjualan, stok, dan pelanggan dari satu dashboard.</h2>
            <p class="mt-3">Semua angka dihitung langsung dari transaksi Anda, jadi keputusan bisnis berdasarkan data yang nyata.</p>
        </div>
        <small class="opacity-75"><?php echo e($appTagline); ?></small>
    </div>
    <div class="mp-auth-form">
        <div class="mp-auth-box">
            <h3 class="fw-bold mb-1">Masuk ke akun Anda</h3>
            <p class="mp-sub mb-4">Belum punya akun? <a href="<?php echo e(route('register')); ?>" class="fw-bold">Daftar sebagai Business Owner</a></p>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger border-0 rounded-3 py-2"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label" for="email">Email</label>
                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" required autofocus>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="password">Password</label>
                    <input id="password" type="password" name="password" class="form-control" required>
                </div>
                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember">
                    <label class="form-check-label" for="remember">Ingat saya</label>
                </div>
                <button class="btn btn-primary w-100 py-2">Masuk</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\marketpulse\marketpulse\resources\views/auth/login.blade.php ENDPATH**/ ?>