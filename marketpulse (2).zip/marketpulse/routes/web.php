<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\AnalyticsController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\InsightController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SaleController;
use App\Http\Controllers\SettingController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    if (auth()->check()) {
        return redirect()->route(auth()->user()->isAdmin() ? 'admin.dashboard' : 'dashboard');
    }
    return view('landing');
})->name('home');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

// Profil (Admin & Business Owner)
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profile/password', [ProfileController::class, 'password'])->name('profile.password');
});

// ---------- BUSINESS OWNER ----------
Route::middleware(['auth', 'role:owner'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::post('products/bulk-delete', [ProductController::class, 'bulkDelete'])->name('products.bulk-delete');
    Route::post('products/bulk-export', [ProductController::class, 'export'])->name('products.bulk-export');
    Route::get('products/export', [ProductController::class, 'export'])->name('products.export');
    Route::resource('products', ProductController::class)->except('show');

    Route::resource('categories', CategoryController::class)->except('show');

    Route::get('sales/{sale}/print', [SaleController::class, 'print'])->name('sales.print');
    Route::resource('sales', SaleController::class)->only(['index', 'create', 'store', 'show', 'destroy']);

    Route::resource('customers', CustomerController::class);

    Route::get('/inventory', [InventoryController::class, 'index'])->name('inventory');
    Route::patch('/inventory/{product}/restock', [InventoryController::class, 'restock'])->name('inventory.restock');
    Route::get('/analytics', [AnalyticsController::class, 'index'])->name('analytics');
    Route::get('/insights', [InsightController::class, 'index'])->name('insights');

    Route::get('/reports', [ReportController::class, 'index'])->name('reports');
    Route::get('/reports/export', [ReportController::class, 'export'])->name('reports.export');

    Route::get('/settings', [SettingController::class, 'edit'])->name('settings');
    Route::put('/settings', [SettingController::class, 'update'])->name('settings.update');
});

// ---------- ADMIN ----------
Route::prefix('admin')->name('admin.')->middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/', [Admin\DashboardController::class, 'index'])->name('dashboard');
    Route::get('/analytics', [Admin\AnalyticsController::class, 'index'])->name('analytics');
    Route::get('/sales', [Admin\SaleController::class, 'index'])->name('sales');
    Route::get('/sales/export', [Admin\SaleController::class, 'export'])->name('sales.export');
    Route::get('/products', [Admin\ProductController::class, 'index'])->name('products');
    Route::get('/owners', [Admin\OwnerController::class, 'index'])->name('owners');
    Route::get('/owners/export', [Admin\OwnerController::class, 'export'])->name('owners.export');
    Route::get('/owners/{user}', [Admin\OwnerController::class, 'show'])->name('owners.show');
    Route::patch('/owners/{user}/toggle', [Admin\OwnerController::class, 'toggle'])->name('owners.toggle');
    Route::delete('/owners/{user}', [Admin\OwnerController::class, 'destroy'])->name('owners.destroy');
    Route::resource('categories', Admin\CategoryController::class)->except('show');
    Route::get('/settings', [Admin\SettingController::class, 'edit'])->name('settings');
    Route::put('/settings', [Admin\SettingController::class, 'update'])->name('settings.update');
});
