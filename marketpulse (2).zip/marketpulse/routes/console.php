<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Artisan::command('demo:photos {--force : Timpa foto yang sudah ada}', function () {
    $n = 0;
    foreach (\App\Models\Product::cursor() as $product) {
        if (\App\Support\DemoPhotos::attach($product, (bool) $this->option('force'))) {
            $n++;
        }
    }
    $this->info("Foto contoh terpasang di {$n} produk.");
})->purpose('Pasang foto contoh ke produk demo');

Artisan::command('demo:photos-check', function () {
    $names = \App\Models\Product::query()->distinct()->orderBy('name')->pluck('name');
    $missing = $names->reject(fn ($n) => \App\Support\DemoPhotos::find($n));
    $this->info(($names->count() - $missing->count()).' dari '.$names->count().' produk sudah punya foto di database/seeders/photos.');
    foreach ($missing as $n) {
        $this->line('  belum ada: '.\Illuminate\Support\Str::slug($n).'.jpg   ('.$n.')');
    }
})->purpose('Cek produk demo mana yang belum punya foto asli');
