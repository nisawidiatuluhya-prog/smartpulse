<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') · {{ $appName }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="{{ asset('css/app.css') }}?v={{ filemtime(public_path('css/app.css')) }}" rel="stylesheet">
    <link href="{{ asset('css/theme.css') }}?v={{ filemtime(public_path('css/theme.css')) }}" rel="stylesheet">
    <link href="{{ asset('css/extra.css') }}?v={{ filemtime(public_path('css/extra.css')) }}" rel="stylesheet">
    @stack('head')
</head>
<body>
@php
    $user = auth()->user();
    if ($user->isAdmin()) {
        $menu = [
            ['admin.dashboard', 'bi-grid-1x2', 'Dashboard', 'admin.dashboard'],
            ['admin.analytics', 'bi-graph-up-arrow', 'Platform Analytics', 'admin.analytics'],
            ['admin.owners', 'bi-people', 'Business Owners', 'admin.owners*'],
            ['admin.products', 'bi-box-seam', 'All Products', 'admin.products'],
            ['admin.sales', 'bi-receipt', 'All Transactions', 'admin.sales*'],
            ['admin.categories.index', 'bi-tags', 'Categories', 'admin.categories.*'],
            ['admin.settings', 'bi-sliders', 'App Settings', 'admin.settings'],
        ];
        $homeRoute = 'admin.dashboard';
    } else {
        $menu = [
            ['dashboard', 'bi-grid-1x2', 'Dashboard', 'dashboard'],
            ['products.index', 'bi-box-seam', 'Products', 'products.*'],
            ['inventory', 'bi-boxes', 'Inventory', 'inventory*'],
            ['categories.index', 'bi-tags', 'Categories', 'categories.*'],
            ['sales.index', 'bi-receipt', 'Sales', 'sales.*'],
            ['customers.index', 'bi-people', 'Customers', 'customers.*'],
            ['analytics', 'bi-graph-up-arrow', 'Analytics', 'analytics'],
            ['insights', 'bi-stars', 'Smart Insights', 'insights'],
            ['reports', 'bi-file-earmark-bar-graph', 'Reports', 'reports*'],
        ];
        $homeRoute = 'dashboard';
    }
@endphp
<div class="mp-shell">
    <aside class="mp-sidebar" id="mpSidebar">
        <a href="{{ route($homeRoute) }}" class="mp-logo"><i class="bi bi-activity"></i>{{ $appName }}</a>

        <ul class="mp-nav">
            @foreach ($menu as [$route, $icon, $label, $pattern])
                <li><a href="{{ route($route) }}" class="{{ request()->routeIs($pattern) ? 'active' : '' }}"><i class="bi {{ $icon }}"></i>{{ $label }}</a></li>
            @endforeach
        </ul>

        @unless ($user->isAdmin())
            <div class="mp-side-cta">
                <a href="{{ route('sales.create') }}" class="btn btn-primary w-100 mb-3"><i class="bi bi-plus-square me-2"></i>New Sale</a>
                <a href="{{ route('products.create') }}" class="mp-upload">
                    <i class="bi bi-cloud-arrow-up"></i>
                    <b>Upload new product</b>
                    Tambahkan produk &amp; gambar
                </a>
            </div>
        @endunless

        <ul class="mp-nav mp-side-bottom">
            <li><a href="{{ route('profile') }}" class="{{ request()->routeIs('profile*') ? 'active' : '' }}"><i class="bi bi-person"></i>Profile</a></li>
            @unless ($user->isAdmin())
                <li><a href="{{ route('settings') }}" class="{{ request()->routeIs('settings*') ? 'active' : '' }}"><i class="bi bi-gear"></i>Settings</a></li>
            @endunless
            <li>
                <form method="POST" action="{{ route('logout') }}">@csrf
                    <button type="submit" class="mp-nav-btn" style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:10px;color:#6c7589;font-weight:600;font-size:.84rem">
                        <i class="bi bi-box-arrow-right" style="font-size:1.05rem"></i>Logout
                    </button>
                </form>
            </li>
        </ul>
    </aside>

    <main class="mp-main">
        <header class="mp-topbar">
            <button class="mp-icon-btn mp-menu-toggle" data-sidebar-toggle aria-label="Menu"><i class="bi bi-list" style="font-size:1.5rem"></i></button>
            <h1 class="mp-title">@hasSection('heading')@yield('heading')@else @yield('title', 'Dashboard') @endif</h1>

            @unless ($user->isAdmin())
                <form class="mp-search" action="{{ route('products.index') }}" method="GET" role="search">
                    <input type="search" name="q" class="form-control" placeholder="Cari produk..." value="{{ request()->routeIs('products.*') ? request('q') : '' }}">
                    <i class="bi bi-search"></i>
                </form>
            @endunless

            <div class="mp-top-actions">
                @unless ($user->isAdmin())
                    <a href="{{ route('products.index', ['stock' => 'low']) }}" class="mp-icon-btn" title="Stok menipis">
                        <i class="bi bi-bell"></i>
                        @if ($lowStockCount)<span class="dot">{{ $lowStockCount }}</span>@endif
                    </a>
                @endunless
                <div class="dropdown">
                    <button class="mp-avatar" data-bs-toggle="dropdown" aria-label="Akun">{{ $user->initials }}</button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                        <li class="px-3 py-2"><div class="fw-bold">{{ $user->name }}</div><div class="mp-sub">{{ $user->isAdmin() ? 'Administrator' : ($user->business_name ?: 'Business Owner') }}</div></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="{{ route('profile') }}">Profile</a></li>
                        @unless ($user->isAdmin())<li><a class="dropdown-item" href="{{ route('settings') }}">Settings</a></li>@endunless
                        <li><form method="POST" action="{{ route('logout') }}">@csrf<button class="dropdown-item">Logout</button></form></li>
                    </ul>
                </div>
            </div>
        </header>

        @include('partials.flash')
        @yield('content')
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script src="{{ asset('js/app.js') }}?v={{ filemtime(public_path('js/app.js')) }}"></script>
@stack('scripts')
</body>
</html>
