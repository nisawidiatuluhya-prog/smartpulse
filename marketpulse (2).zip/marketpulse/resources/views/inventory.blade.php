@extends('layouts.app')
@section('title', 'Inventory')

@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Inventory</h2><div class="mp-sub">Pantau stok semua produk aktif dan isi ulang dengan cepat</div></div>
    <a href="{{ route('products.create') }}" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Produk baru</a>
</div>

<div class="row g-3 mb-3">
    @foreach ([
        ['bi-box-seam', 'indigo', $summary['products'], 'Produk aktif', 'all'],
        ['bi-check-circle', 'emerald', $summary['ok'], 'Stok aman', 'ok'],
        ['bi-exclamation-triangle', 'orange', $summary['low'], 'Stok menipis', 'low'],
        ['bi-x-octagon', 'red', $summary['out'], 'Stok habis', 'out'],
        ['bi-safe', 'cyan', rp_short($summary['value']), $summary['units'].' unit tersimpan', 'all'],
    ] as [$ic, $c, $v, $l, $st])
        <div class="col-6 col-xl"><a class="mp-tile-link" href="{{ route('inventory', ['state' => $st]) }}"><div class="mp-kpi"><span class="ic {{ $c }}"><i class="bi {{ $ic }}"></i></span><div><b>{{ $v }}</b><span>{{ $l }}</span></div></div></a></div>
    @endforeach
</div>

<form method="GET" class="mp-filter">
    <div class="mp-seg">
        @foreach (['all' => 'Semua', 'low' => 'Menipis', 'out' => 'Habis', 'ok' => 'Aman'] as $k => $l)
            <a href="{{ route('inventory', ['state' => $k, 'q' => request('q')]) }}" class="{{ $state === $k ? 'on' : '' }}" style="text-decoration:none;display:inline-block">{{ $l }}</a>
        @endforeach
    </div>
    <input type="hidden" name="state" value="{{ $state }}">
    <input type="search" name="q" value="{{ request('q') }}" class="form-control form-control-sm" placeholder="Cari produk / SKU" style="min-width:220px">
    <button class="btn btn-primary btn-sm">Cari</button>
</form>

<div class="mp-card p-0 overflow-hidden"><div class="mp-scroll">
<table class="mp-table">
    <thead><tr><th>Produk</th><th>Kategori</th><th style="min-width:160px">Stok</th><th>Laju jual</th><th>Perkiraan habis</th><th class="text-end">Tambah stok</th></tr></thead>
    <tbody>
    @forelse ($products as $i => $p)
        @php
            $st = $p->stock <= 0 ? 'out' : ($p->stock <= \App\Models\Product::LOW_STOCK ? 'low' : 'ok');
            $perDay = ($velocity[$p->id] ?? 0) / 30;
            $days = $perDay > 0 ? (int) floor($p->stock / $perDay) : null;
            $pct = min(100, max(4, $p->stock / 60 * 100));
        @endphp
        <tr>
            <td><div class="d-flex align-items-center gap-3">
                <span class="mp-thumb c{{ $i % 5 }}">@if ($p->image)<img src="{{ asset('storage/'.$p->image) }}" alt="">@else<i class="bi bi-box-seam"></i>@endif</span>
                <span><b>{{ $p->name }}</b><br><span class="mp-sub">{{ $p->sku ? '#'.$p->sku : '—' }}</span></span></div></td>
            <td>{{ $p->category?->name ?? '—' }}</td>
            <td><b>{{ $p->stock }}</b> <span class="mp-pill {{ ['ok' => 'green', 'low' => 'orange', 'out' => 'red'][$st] }}">{{ ['ok' => 'Aman', 'low' => 'Menipis', 'out' => 'Habis'][$st] }}</span>
                <div class="mp-stockbar mt-1"><i class="{{ $st }}" style="width: {{ $st === 'out' ? 100 : $pct }}%"></i></div></td>
            <td>{{ $perDay > 0 ? number_format($perDay, 1, ',', '.').' /hari' : '—' }}</td>
            <td>@if ($days === null)<span class="mp-sub">Belum ada data</span>@elseif ($p->stock <= 0)<span class="mp-pill red">Sudah habis</span>@else<span class="mp-pill {{ $days <= 7 ? 'red' : ($days <= 14 ? 'orange' : 'green') }}">± {{ $days }} hari</span>@endif</td>
            <td class="text-end">
                <form method="POST" action="{{ route('inventory.restock', $p) }}" class="mp-restock">@csrf @method('PATCH')
                    <input type="number" name="quantity" min="1" max="100000" value="10" class="form-control form-control-sm" aria-label="Jumlah tambah stok {{ $p->name }}">
                    <button class="btn btn-sm btn-primary" title="Tambah stok"><i class="bi bi-plus-lg"></i></button>
                </form>
            </td>
        </tr>
    @empty
        <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-boxes"></i>Tidak ada produk pada filter ini.</div></td></tr>
    @endforelse
    </tbody>
</table></div>
@if ($products->hasPages())<div class="p-3">{{ $products->links() }}</div>@endif
</div>
@endsection
