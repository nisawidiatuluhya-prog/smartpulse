@extends('layouts.app')
@section('title', 'Sales')

@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Sales</h2><div class="mp-sub">Riwayat transaksi penjualan Anda</div></div>
    <a href="{{ route('sales.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Catat penjualan</a>
</div>

<form method="GET" class="row g-2 mb-3">
    <div class="col-md-4"><input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Cari invoice atau pelanggan"></div>
    <div class="col-6 col-md-2"><input type="date" name="from" value="{{ $hasFilter ? $from->toDateString() : '' }}" class="form-control" aria-label="Dari tanggal"></div>
    <div class="col-6 col-md-2"><input type="date" name="to" value="{{ $hasFilter ? $to->toDateString() : '' }}" class="form-control" aria-label="Sampai tanggal"></div>
    <div class="col-md-4 d-flex gap-2"><button class="btn btn-primary">Terapkan</button><a href="{{ route('sales.index') }}" class="btn btn-light border">Reset</a></div>
</form>

<div class="mp-card p-0 overflow-hidden">
    <div class="mp-scroll">
    <table class="mp-table">
        <thead><tr><th>No. Transaksi</th><th>Tanggal</th><th>Pelanggan</th><th>Item</th><th>Total</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        @forelse ($sales as $s)
            <tr>
                <td><a href="{{ route('sales.show', $s) }}" class="fw-bold text-reset">{{ $s->invoice_no }}</a></td>
                <td>{{ $s->sold_at->translatedFormat('d M Y') }}</td>
                <td>{{ $s->customer?->name ?? 'Umum' }}</td>
                <td>{{ $s->details_count }}</td>
                <td class="num">{{ rp($s->total) }}</td>
                <td class="text-end">
                    <a href="{{ route('sales.show', $s) }}" class="btn btn-sm btn-light border">Detail</a>
                    <form method="POST" action="{{ route('sales.destroy', $s) }}" class="d-inline" data-confirm="Hapus transaksi ini? Stok produk akan dikembalikan.">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Hapus</button></form>
                </td>
            </tr>
        @empty
            <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-receipt"></i>Belum ada transaksi. <a href="{{ route('sales.create') }}">Catat penjualan pertama</a>.</div></td></tr>
        @endforelse
        </tbody>
    </table>
    </div>
    @if ($sales->hasPages())<div class="p-3">{{ $sales->links() }}</div>@endif
</div>
@endsection
