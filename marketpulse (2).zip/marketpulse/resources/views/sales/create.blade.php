@extends('layouts.app')
@section('title', 'Catat Penjualan')

@section('content')
<form method="POST" action="{{ route('sales.store') }}" id="saleForm">
    @csrf
    <div class="row g-3">
        <div class="col-lg-8">
            <div class="mp-card">
                <h2 class="mp-card-title mb-3">Produk terjual</h2>
                @if ($products->isEmpty())
                    <div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada produk aktif dengan stok. <a href="{{ route('products.create') }}">Tambah produk</a> dulu.</div>
                @else
                    <div id="rows"></div>
                    <button type="button" class="btn btn-light border btn-sm mt-2" id="addRow"><i class="bi bi-plus-lg me-1"></i>Tambah produk</button>
                @endif
            </div>
        </div>
        <div class="col-lg-4">
            <div class="mp-card">
                <h2 class="mp-card-title mb-3">Detail transaksi</h2>
                <div class="mb-3"><label class="form-label">Nomor transaksi</label><input class="form-control" value="{{ $invoiceNo }}" disabled><div class="mp-sub mt-1">Nomor final dibuat otomatis saat disimpan.</div></div>
                <div class="mb-3">
                    <label class="form-label" for="sold_at">Tanggal transaksi</label>
                    <input id="sold_at" type="date" name="sold_at" max="{{ now()->toDateString() }}" value="{{ old('sold_at', now()->toDateString()) }}" class="form-control @error('sold_at') is-invalid @enderror" required>
                    @error('sold_at')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="mb-3">
                    <label class="form-label" for="customer_id">Pelanggan</label>
                    <select id="customer_id" name="customer_id" class="form-select">
                        <option value="">Umum (tanpa data pelanggan)</option>
                        @foreach ($customers as $c)<option value="{{ $c->id }}" @selected(old('customer_id') == $c->id)>{{ $c->name }}</option>@endforeach
                    </select>
                    <a href="{{ route('customers.create') }}" class="mp-sub">+ Pelanggan baru</a>
                </div>
                <div class="mb-3"><label class="form-label" for="notes">Catatan</label><input id="notes" name="notes" class="form-control" value="{{ old('notes') }}"></div>
                <div class="d-flex justify-content-between align-items-center border-top pt-3 mb-3"><span class="fw-bold">Total pembayaran</span><span class="fs-5 fw-bold" id="grand">Rp 0</span></div>
                <button class="btn btn-primary w-100" @disabled($products->isEmpty())>Simpan penjualan</button>
            </div>
        </div>
    </div>
</form>
@endsection

@push('scripts')
<script>
(() => {
    const products = @json($products);
    const old = @json(old('items', [['product_id' => '', 'quantity' => 1]]));
    const rows = document.getElementById('rows');
    if (!rows) return;
    let n = 0;

    function addRow(data = {}) {
        const i = n++;
        const el = document.createElement('div');
        el.className = 'row g-2 align-items-end mb-2 sale-row';
        el.innerHTML = `
            <div class="col-md-6"><label class="form-label">Produk</label>
                <select name="items[${i}][product_id]" class="form-select p-sel" required>
                    <option value="">Pilih produk</option>
                    ${products.map(p => `<option value="${p.id}" ${data.product_id == p.id ? 'selected' : ''}>${p.name} (stok ${p.stock})</option>`).join('')}
                </select></div>
            <div class="col-4 col-md-2"><label class="form-label">Jumlah</label><input type="number" min="1" name="items[${i}][quantity]" class="form-control q-in" value="${data.quantity || 1}" required></div>
            <div class="col-5 col-md-3"><label class="form-label">Subtotal</label><div class="form-control bg-light sub">Rp 0</div></div>
            <div class="col-3 col-md-1"><button type="button" class="btn btn-outline-danger w-100 rm" aria-label="Hapus baris"><i class="bi bi-x-lg"></i></button></div>`;
        rows.appendChild(el);
        el.querySelector('.p-sel').addEventListener('change', calc);
        el.querySelector('.q-in').addEventListener('input', calc);
        el.querySelector('.rm').addEventListener('click', () => { if (rows.children.length > 1) { el.remove(); calc(); } });
        calc();
    }

    function calc() {
        let total = 0;
        rows.querySelectorAll('.sale-row').forEach(r => {
            const p = products.find(x => x.id == r.querySelector('.p-sel').value);
            const q = parseInt(r.querySelector('.q-in').value) || 0;
            const s = p ? p.price * q : 0;
            r.querySelector('.sub').textContent = rp(s);
            total += s;
        });
        document.getElementById('grand').textContent = rp(total);
    }

    document.getElementById('addRow').addEventListener('click', () => addRow());
    old.forEach(addRow);
})();
</script>
@endpush
