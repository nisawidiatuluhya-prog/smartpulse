<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $sale->invoice_no }}</title>
    <style>
        * { box-sizing: border-box; } body { font-family: "Segoe UI", Arial, sans-serif; color: #1c2434; margin: 0; background: #f3f4fb; }
        .sheet { max-width: 760px; margin: 24px auto; background: #fff; padding: 40px; border-radius: 16px; box-shadow: 0 20px 50px -30px rgba(40,40,110,.5); }
        .top { display: flex; justify-content: space-between; gap: 20px; border-bottom: 3px solid #6366f1; padding-bottom: 18px; }
        h1 { margin: 0; font-size: 1.5rem; letter-spacing: -.02em; } .muted { color: #6c7589; font-size: .85rem; }
        .inv { text-align: right; } .inv b { font-size: 1.15rem; color: #4f46e5; }
        .meta { display: flex; justify-content: space-between; margin: 22px 0; gap: 20px; } .meta div b { display: block; margin-top: 2px; }
        table { width: 100%; border-collapse: collapse; } th { text-align: left; font-size: .72rem; text-transform: uppercase; letter-spacing: .05em; color: #6c7589; border-bottom: 1px solid #dfe3f0; padding: 10px 6px; }
        td { padding: 11px 6px; border-bottom: 1px solid #eef0f7; font-size: .92rem; } .r { text-align: right; }
        .total { display: flex; justify-content: flex-end; margin-top: 18px; } .total div { background: #eef0ff; border-radius: 12px; padding: 14px 22px; text-align: right; } .total b { display: block; font-size: 1.4rem; color: #4f46e5; }
        .foot { margin-top: 36px; text-align: center; color: #8a91a8; font-size: .82rem; }
        .actions { text-align: center; margin: 18px 0 40px; } .actions button, .actions a { font: inherit; font-weight: 700; border: 0; border-radius: 10px; padding: 10px 20px; margin: 0 4px; cursor: pointer; text-decoration: none; display: inline-block; }
        .actions button { background: linear-gradient(135deg,#6366f1,#8b5cf6); color: #fff; } .actions a { background: #fff; color: #1c2434; border: 1px solid #dfe3f0; }
        @media print { body { background: #fff; } .sheet { box-shadow: none; margin: 0; max-width: none; padding: 0; } .actions { display: none; } }
    </style>
</head>
<body>
<div class="sheet">
    <div class="top">
        <div><h1>{{ $seller->business_name ?: $seller->name }}</h1><div class="muted">{{ $seller->phone ?: $seller->email }}</div></div>
        <div class="inv"><div class="muted">INVOICE</div><b>{{ $sale->invoice_no }}</b></div>
    </div>
    <div class="meta">
        <div><span class="muted">Tanggal</span><b>{{ $sale->sold_at->translatedFormat('d F Y') }}</b></div>
        <div><span class="muted">Pelanggan</span><b>{{ $sale->customer?->name ?? 'Umum' }}</b>@if ($sale->customer?->phone)<span class="muted">{{ $sale->customer->phone }}</span>@endif</div>
    </div>
    <table>
        <thead><tr><th>#</th><th>Produk</th><th class="r">Harga</th><th class="r">Jumlah</th><th class="r">Subtotal</th></tr></thead>
        <tbody>
        @foreach ($sale->details as $i => $d)
            <tr><td>{{ $i + 1 }}</td><td>{{ $d->product_name }}</td><td class="r">{{ rp($d->price) }}</td><td class="r">{{ $d->quantity }}</td><td class="r">{{ rp($d->subtotal) }}</td></tr>
        @endforeach
        </tbody>
    </table>
    <div class="total"><div><span class="muted">Total pembayaran</span><b>{{ rp($sale->total) }}</b></div></div>
    @if ($sale->notes)<p class="muted">Catatan: {{ $sale->notes }}</p>@endif
    <div class="foot">Terima kasih telah berbelanja · dicetak lewat MarketPulse</div>
</div>
<div class="actions"><button onclick="window.print()">Cetak / Simpan PDF</button><a href="{{ route('sales.show', $sale) }}">Kembali</a></div>
</body>
</html>
