@extends('layouts.app')
@section('title', 'Detail Penjualan')

@section('content')
<div class="mp-card" style="max-width:860px">
    <div class="d-flex flex-wrap justify-content-between gap-3 mb-4">
        <div>
            <div class="mp-sub">No. Transaksi</div>
            <h2 class="fw-bold fs-4 mb-0">{{ $sale->invoice_no }}</h2>
        </div>
        <div class="text-md-end">
            <div class="mp-sub">Tanggal</div><div class="fw-bold">{{ $sale->sold_at->translatedFormat('d F Y') }}</div>
        </div>
        <div>
            <div class="mp-sub">Pelanggan</div>
            <div class="fw-bold">@if ($sale->customer)<a href="{{ route('customers.show', $sale->customer) }}" class="text-reset">{{ $sale->customer->name }}</a>@else Umum @endif</div>
        </div>
    </div>
    <div class="mp-scroll">
    <table class="mp-table">
        <thead><tr><th>Produk</th><th class="text-end">Harga satuan</th><th class="text-end">Jumlah</th><th class="text-end">Subtotal</th></tr></thead>
        <tbody>
        @foreach ($sale->details as $d)
            <tr><td><b>{{ $d->product_name }}</b></td><td class="text-end">{{ rp($d->price) }}</td><td class="text-end">{{ $d->quantity }}</td><td class="text-end num">{{ rp($d->subtotal) }}</td></tr>
        @endforeach
        </tbody>
        <tfoot><tr><td colspan="3" class="text-end fw-bold pt-3">Total pembayaran</td><td class="text-end fw-bold fs-5 pt-3">{{ rp($sale->total) }}</td></tr></tfoot>
    </table>
    </div>
    @if ($sale->notes)<div class="mp-sub mt-3">Catatan: {{ $sale->notes }}</div>@endif
    <div class="d-flex gap-2 mt-4">
        <a href="{{ route('sales.index') }}" class="btn btn-light border">Kembali</a>
        <a href="{{ route('sales.print', $sale) }}" target="_blank" class="btn btn-primary"><i class="bi bi-printer me-1"></i>Cetak invoice</a>
        <form method="POST" action="{{ route('sales.destroy', $sale) }}" data-confirm="Hapus transaksi ini? Stok produk akan dikembalikan.">@csrf @method('DELETE')<button class="btn btn-outline-danger">Hapus transaksi</button></form>
    </div>
</div>
@endsection
