@extends('layouts.guest')
@section('title', $appTagline)

@push('head')
    <meta name="theme-color" content="#12123a">
    <meta name="description" content="{{ $appName }}: {{ $appTagline }}. Kelola produk, catat penjualan, dan baca performa bisnis dari satu aplikasi.">
    <link href="{{ asset('css/landing.css') }}?v={{ filemtime(public_path('css/landing.css')) }}" rel="stylesheet">
    {{-- Splash hanya tampil sekali per sesi browser; dicek sebelum halaman digambar supaya tidak berkedip --}}
    <script>
        document.documentElement.classList.add('lp-js');
        try {
            if (!sessionStorage.getItem('mp_splash') && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
                document.documentElement.classList.add('lp-splash-on');
            }
        } catch (e) {}
    </script>
@endpush

@section('body')
{{-- ================= SPLASH: logo + nama aplikasi, lalu "masuk" ke aplikasi ================= --}}
<div class="lp-splash" id="lpSplash" role="presentation">
    <div class="lp-splash-glow"></div>
    <div class="lp-splash-inner">
        <div class="lp-splash-logo">@include('partials.logo-mark', ['id' => 'lmSplash', 'size' => 92])</div>
        <div class="lp-splash-name">{{ $appName }}</div>
        <div class="lp-splash-tag">{{ $appTagline }}</div>
        <div class="lp-splash-bar"><span></span></div>
    </div>
    <button type="button" class="lp-splash-skip" id="lpSkip">Lewati</button>
</div>

<div class="lp" id="lpApp">
    {{-- ================= NAVBAR ================= --}}
    <header class="lp-nav" id="lpNav">
        <div class="container d-flex align-items-center">
            <a href="{{ route('home') }}" class="lp-brand">@include('partials.logo-mark', ['id' => 'lmNav', 'size' => 34])<span>{{ $appName }}</span></a>
            <nav class="lp-links d-none d-lg-flex">
                <a href="#fitur">Fitur</a><a href="#cara-kerja">Cara kerja</a><a href="#tampilan">Tampilan</a><a href="#peran">Pengguna</a>
            </nav>
            <div class="ms-auto d-flex gap-2">
                <a href="{{ route('login') }}" class="btn btn-light lp-btn-sm">Masuk</a>
                <a href="{{ route('register') }}" class="btn btn-primary lp-btn-sm">Daftar gratis</a>
            </div>
        </div>
    </header>

    {{-- ================= HERO ================= --}}
    <section class="lp-hero">
        <div class="lp-blob b1"></div><div class="lp-blob b2"></div><div class="lp-blob b3"></div>
        <div class="container position-relative">
            <div class="row align-items-center g-5">
                <div class="col-lg-6">
                    <span class="lp-chip lp-reveal"><i class="bi bi-stars"></i> Business intelligence untuk UMKM</span>
                    <h1 class="lp-reveal" style="--d:.08s">Tahu persis produk mana yang <span class="lp-grad">membawa untung.</span></h1>
                    <p class="lp-lead lp-reveal" style="--d:.16s">{{ $appName }} membantu pemilik usaha mengelola produk dan stok, mencatat penjualan, dan membaca performa bisnis lewat grafik yang dihitung dari transaksi sendiri.</p>
                    <div class="d-flex flex-wrap gap-2 align-items-center lp-reveal" style="--d:.24s">
                        <a href="{{ route('register') }}" class="btn btn-primary btn-lg px-4">Mulai sekarang <i class="bi bi-arrow-right ms-1"></i></a>
                        <a href="{{ route('login') }}" class="btn btn-light btn-lg px-4">Saya sudah punya akun</a>
                    </div>
                    <ul class="lp-checks lp-reveal" style="--d:.32s">
                        <li><i class="bi bi-check-circle-fill"></i> Stok berkurang otomatis</li>
                        <li><i class="bi bi-check-circle-fill"></i> Ekspor PDF, Excel, CSV</li>
                        <li><i class="bi bi-check-circle-fill"></i> Data tiap usaha terpisah</li>
                    </ul>
                </div>

                <div class="col-lg-6">
                    {{-- Mock jendela aplikasi (ilustrasi tampilan) --}}
                    <div class="lp-device lp-reveal" style="--d:.2s" aria-hidden="true">
                        <div class="lp-device-bar"><i></i><i></i><i></i><span>{{ $appName }} · Dashboard</span></div>
                        <div class="lp-device-body">
                            <div class="lp-mini-stats">
                                <div class="g1"><small>Pendapatan</small><b data-count="48250000" data-fmt="rp">Rp 0</b><em>▲ 12,4%</em></div>
                                <div class="g2"><small>Penjualan</small><b data-count="326">0</b><em>▲ 8,1%</em></div>
                                <div class="g3"><small>Pelanggan</small><b data-count="84">0</b><em>▲ 5,3%</em></div>
                            </div>
                            <div class="lp-chart-box">
                                <div class="d-flex justify-content-between mb-1"><b>Sales Overview</b><small>12 bulan terakhir</small></div>
                                <svg viewBox="0 0 400 140" width="100%">
                                    <defs><linearGradient id="lpg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6366f1" stop-opacity=".32"/><stop offset="1" stop-color="#6366f1" stop-opacity="0"/></linearGradient></defs>
                                    <path d="M0 112 C40 104 60 66 100 74 S160 112 200 84 S280 28 320 46 S380 18 400 26 V140 H0Z" fill="url(#lpg)"/>
                                    <path class="draw" d="M0 112 C40 104 60 66 100 74 S160 112 200 84 S280 28 320 46 S380 18 400 26" fill="none" stroke="#6366f1" stroke-width="3" stroke-linecap="round"/>
                                    <path class="draw d2" d="M0 124 C50 114 90 94 130 104 S210 66 250 84 S330 94 400 56" fill="none" stroke="#ec4899" stroke-width="3" stroke-linecap="round"/>
                                </svg>
                            </div>
                            <div class="lp-rank">
                                <div><span>Produk terlaris</span></div>
                                <div class="r"><i style="--w:92%"></i></div><div class="r"><i style="--w:70%"></i></div><div class="r"><i style="--w:48%"></i></div>
                            </div>
                        </div>
                        <div class="lp-float f1"><i class="bi bi-bell-fill"></i> Stok menipis: 3 produk</div>
                        <div class="lp-float f2"><i class="bi bi-receipt"></i> INV baru tersimpan</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- ================= ANGKA RINGKAS (fakta dari fitur aplikasi) ================= --}}
    <section class="container lp-stats">
        <div class="row g-3">
            @foreach ([[5,'Jenis laporan','bi-file-earmark-bar-graph'],[3,'Format ekspor','bi-download'],[9,'Menu utama untuk Owner','bi-grid-1x2'],[100,'% data per usaha terisolasi','bi-shield-check']] as [$n,$l,$i])
                <div class="col-6 col-lg-3"><div class="lp-stat lp-reveal"><i class="bi {{ $i }}"></i><b data-count="{{ $n }}">0</b><span>{{ $l }}</span></div></div>
            @endforeach
        </div>
    </section>

    {{-- ================= FITUR ================= --}}
    <section class="container lp-section" id="fitur">
        <div class="lp-head lp-reveal"><span class="lp-eyebrow">Fitur</span><h2>Semua yang dibutuhkan untuk mengelola usaha</h2><p>Dari etalase produk sampai laporan siap cetak, tanpa perlu pindah aplikasi.</p></div>
        <div class="row g-3">
            @foreach ([
                ['bi-box-seam','Produk & stok','Kelola harga, foto, kategori, dan peringatan stok menipis. Tampilan kartu atau tabel.','c1'],
                ['bi-receipt','Pencatatan penjualan','Pilih produk, jumlah dan pelanggan. Total dihitung dan stok berkurang otomatis.','c2'],
                ['bi-people','Data pelanggan','Simpan kontak dan lihat riwayat belanja serta total belanja tiap pelanggan.','c3'],
                ['bi-graph-up-arrow','Analytics','Tren pendapatan, produk terlaris, kategori paling laku, dan pelanggan yang kembali.','c4'],
                ['bi-file-earmark-bar-graph','Laporan','Penjualan, pendapatan, produk, stok, dan pelanggan. Ekspor ke PDF, Excel, atau CSV.','c5'],
                ['bi-boxes','Inventory & restock','Pantau stok, lihat perkiraan habis, dan tambah stok langsung dari satu halaman.','c4'],
                ['bi-stars','Smart Insights','Skor kesehatan bisnis, hari terbaik, produk lambat laku, dan saran restock otomatis.','c1'],
                ['bi-printer','Cetak invoice','Setiap transaksi punya invoice rapi yang siap dicetak atau disimpan sebagai PDF.','c2'],
                ['bi-shield-lock','Panel Admin lengkap','Analytics platform, pemantauan semua produk dan transaksi, peringkat owner, dan kesehatan platform.','c6'],
            ] as $k => [$i,$t,$d,$c])
                <div class="col-md-6 col-lg-4"><div class="lp-feature {{ $c }} lp-reveal" style="--d:{{ $k * .06 }}s"><i class="bi {{ $i }}"></i><h5>{{ $t }}</h5><p>{{ $d }}</p></div></div>
            @endforeach
        </div>
    </section>

    {{-- ================= CARA KERJA ================= --}}
    <section class="lp-band" id="cara-kerja">
        <div class="container lp-section">
            <div class="lp-head lp-reveal"><span class="lp-eyebrow">Cara kerja</span><h2>Mulai dalam tiga langkah</h2></div>
            <div class="row g-4 lp-steps">
                @foreach ([['1','Daftar akun','Buat akun Business Owner dengan nama usaha Anda. Gratis dan langsung aktif.'],['2','Isi produk','Tambahkan produk, harga, stok, dan foto. Atur kategori agar laporan rapi.'],['3','Catat & pantau','Catat penjualan harian, lalu baca grafik dan unduh laporan kapan saja.']] as $k => [$n,$t,$d])
                    <div class="col-md-4"><div class="lp-step lp-reveal" style="--d:{{ $k * .1 }}s"><span>{{ $n }}</span><h5>{{ $t }}</h5><p>{{ $d }}</p></div></div>
                @endforeach
            </div>
        </div>
    </section>

    {{-- ================= TAMPILAN (tab) ================= --}}
    <section class="container lp-section" id="tampilan">
        <div class="lp-head lp-reveal"><span class="lp-eyebrow">Tampilan</span><h2>Rasanya seperti aplikasi sungguhan</h2><p>Klik tab untuk melihat gambaran halaman utama.</p></div>
        <div class="lp-tabs lp-reveal" role="tablist">
            <button class="on" data-tab="t1" role="tab"><i class="bi bi-grid-1x2"></i> Dashboard</button>
            <button data-tab="t2" role="tab"><i class="bi bi-box-seam"></i> Produk</button>
            <button data-tab="t3" role="tab"><i class="bi bi-file-earmark-bar-graph"></i> Laporan</button>
        </div>
        <div class="lp-showcase lp-reveal" aria-hidden="true">
            <div class="lp-pane on" id="t1">
                <div class="row g-3">
                    <div class="col-6 col-md-3"><div class="lp-tile g-indigo"><small>Total Revenue</small><b>Rp 48,2 jt</b></div></div>
                    <div class="col-6 col-md-3"><div class="lp-tile g-pink"><small>Products</small><b>42</b></div></div>
                    <div class="col-6 col-md-3"><div class="lp-tile g-cyan"><small>Sales</small><b>326</b></div></div>
                    <div class="col-6 col-md-3"><div class="lp-tile g-emerald"><small>Customers</small><b>84</b></div></div>
                </div>
                <div class="lp-bars mt-3">@foreach ([40,55,48,70,62,85,78,95,88,110,100,125] as $h)<i style="--h:{{ $h }}px"></i>@endforeach</div>
            </div>
            <div class="lp-pane" id="t2">
                <div class="row g-3">
                    @foreach ([['Kopi Gayo 250g','Rp 85.000','Aman','ok'],['Teh Hijau Premium','Rp 45.000','Menipis','low'],['French Press 600ml','Rp 185.000','Aman','ok'],['Grinder Manual','Rp 260.000','Habis','out']] as [$n,$p,$s,$c])
                        <div class="col-6 col-md-3"><div class="lp-prod"><div class="ph"><i class="bi bi-image"></i></div><b>{{ $n }}</b><span>{{ $p }}</span><em class="{{ $c }}">{{ $s }}</em></div></div>
                    @endforeach
                </div>
            </div>
            <div class="lp-pane" id="t3">
                <div class="lp-table">
                    <div class="h"><span>Invoice</span><span>Tanggal</span><span>Pelanggan</span><span>Total</span></div>
                    @foreach ([['INV-…-A12F4','Hari ini','Andi Wijaya','Rp 270.000'],['INV-…-B77C1','Kemarin','Siti Aminah','Rp 95.000'],['INV-…-C09D2','2 hari lalu','Umum','Rp 185.000']] as $r)
                        <div class="r">@foreach ($r as $c)<span>{{ $c }}</span>@endforeach</div>
                    @endforeach
                    <div class="d-flex gap-2 pt-3"><span class="lp-pill">PDF</span><span class="lp-pill">Excel</span><span class="lp-pill">CSV</span></div>
                </div>
            </div>
        </div>
    </section>

    {{-- ================= PERAN ================= --}}
    <section class="container lp-section pt-0" id="peran">
        <div class="row g-3">
            <div class="col-md-6"><div class="lp-role lp-reveal"><i class="bi bi-shop"></i><h5>Business Owner</h5><p>Pemilik usaha yang mengelola produk, penjualan, pelanggan, analitik, dan laporan miliknya sendiri.</p><a href="{{ route('register') }}">Daftar sebagai Owner <i class="bi bi-arrow-right"></i></a></div></div>
            <div class="col-md-6"><div class="lp-role admin lp-reveal" style="--d:.1s"><i class="bi bi-shield-check"></i><h5>Administrator</h5><p>Mengawasi seluruh Business Owner, mengelola kategori global, dan mengatur identitas aplikasi.</p><a href="{{ route('login') }}">Masuk sebagai Admin <i class="bi bi-arrow-right"></i></a></div></div>
        </div>
    </section>

    {{-- ================= CTA ================= --}}
    <section class="container pb-5">
        <div class="lp-cta lp-reveal">
            <h2>Siap membaca bisnis Anda dengan data?</h2>
            <p>Buat akun dalam satu menit dan catat penjualan pertama hari ini.</p>
            <a href="{{ route('register') }}" class="btn btn-light btn-lg px-4">Daftar gratis</a>
        </div>
    </section>

    <footer class="lp-footer">
        <div class="container d-flex flex-wrap justify-content-between align-items-center gap-2">
            <a href="{{ route('home') }}" class="lp-brand">@include('partials.logo-mark', ['id' => 'lmFoot', 'size' => 26])<span>{{ $appName }}</span></a>
            <small>&copy; {{ date('Y') }} {{ $appName }} · {{ $appTagline }}</small>
        </div>
    </footer>
</div>
@endsection

@push('scripts')
<script src="{{ asset('js/landing.js') }}?v={{ filemtime(public_path('js/landing.js')) }}"></script>
@endpush
