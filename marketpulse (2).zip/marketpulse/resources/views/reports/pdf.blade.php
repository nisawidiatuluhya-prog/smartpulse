<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
 body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #1c2434; }
 h1 { font-size: 16px; margin: 0 0 2px; } .muted { color: #6b7280; margin-bottom: 14px; }
 table { width: 100%; border-collapse: collapse; }
 th { background: #1b8bff; color: #fff; text-align: left; padding: 6px; font-size: 9px; }
 td { padding: 5px 6px; border-bottom: 1px solid #e5e7eb; }
 .r { text-align: right; } .sum { margin-top: 10px; font-weight: bold; }
</style></head>
<body>
 <h1>{{ $report['title'] }}</h1>
 <div class="muted">{{ $user->business_name ?: $user->name }} · {{ $from->format('d/m/Y') }} – {{ $to->format('d/m/Y') }} · dicetak {{ now()->format('d/m/Y H:i') }}</div>
 <table>
  <thead><tr>@foreach ($report['headers'] as $i => $h)<th class="{{ in_array($i, $report['money']) ? 'r' : '' }}">{{ $h }}</th>@endforeach</tr></thead>
  <tbody>
  @forelse ($report['rows'] as $row)
   <tr>@foreach ($row as $i => $cell)<td class="{{ in_array($i, $report['money']) ? 'r' : '' }}">{{ in_array($i, $report['money']) ? rp($cell) : $cell }}</td>@endforeach</tr>
  @empty
   <tr><td colspan="{{ count($report['headers']) }}">Tidak ada data.</td></tr>
  @endforelse
  </tbody>
 </table>
 @if ($report['summary'])<div class="sum">{{ $report['summary'] }}</div>@endif
</body></html>
