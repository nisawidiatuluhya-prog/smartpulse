<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"></head>
<body>
<table border="1">
 <thead><tr>@foreach ($report['headers'] as $h)<th style="background:#1b8bff;color:#fff">{{ $h }}</th>@endforeach</tr></thead>
 <tbody>
 @foreach ($report['rows'] as $row)
  <tr>@foreach ($row as $cell)<td>{{ $cell }}</td>@endforeach</tr>
 @endforeach
 </tbody>
</table>
</body></html>
