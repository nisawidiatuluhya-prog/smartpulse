@extends('layouts.app')
@section('title', 'Reports')

@section('content')
<div class="mb-3">
    <h2 class="fw-bold fs-4 mb-1">{{ $report['title'] }}</h2>
    <div class="mp-crumb">Dashboard <span>&gt;</span> Reports <span>&gt;</span> {{ $report['title'] }}</div>
</div>

<div class="row g-3">
    <div class="col-lg-4 col-xl-3">
        <div class="mp-card">
            <h3 class="fw-bold fs-5 mb-4">Options</h3>
            <form method="GET">
                <div class="mb-3"><label class="form-label" for="type">Jenis laporan</label>
                    <select id="type" name="type" class="form-select">@foreach ($types as $k => $l)<option value="{{ $k }}" @selected($type === $k)>{{ $l }}</option>@endforeach</select></div>
                <div class="mb-3"><label class="form-label" for="from">Between</label><input id="from" type="date" name="from" value="{{ $from->toDateString() }}" class="form-control"></div>
                <div class="mb-4"><label class="form-label" for="to">And</label><input id="to" type="date" name="to" value="{{ $to->toDateString() }}" class="form-control"></div>
                <div class="text-end"><button class="btn btn-primary">Generate Report</button></div>
            </form>
        </div>
    </div>

    <div class="col-lg-8 col-xl-9">
        <div class="d-flex flex-wrap justify-content-end align-items-center gap-2 mb-2 mp-export">
            <span class="mp-sub me-1">Export to</span>
            @php $q = ['type' => $type, 'from' => $from->toDateString(), 'to' => $to->toDateString()]; @endphp
            <a href="{{ route('reports.export', $q + ['format' => 'xls']) }}"><i class="bi bi-file-earmark-excel me-1"></i>XLS</a>
            <a href="{{ route('reports.export', $q + ['format' => 'csv']) }}"><i class="bi bi-filetype-csv me-1"></i>CSV</a>
            <a href="{{ route('reports.export', $q + ['format' => 'pdf']) }}"><i class="bi bi-file-earmark-pdf me-1"></i>PDF</a>
        </div>
        <div class="mp-card p-0 overflow-hidden">
            <div class="mp-scroll" style="max-height:560px">
            <table class="mp-table">
                <thead><tr>@foreach ($report['headers'] as $i => $h)<th class="{{ in_array($i, $report['money']) ? 'text-end' : '' }}">{{ $h }}</th>@endforeach</tr></thead>
                <tbody>
                @forelse ($report['rows'] as $row)
                    <tr>@foreach ($row as $i => $cell)
                        <td class="{{ in_array($i, $report['money']) ? 'text-end num' : '' }}">{{ in_array($i, $report['money']) ? rp($cell) : ($cell === null || $cell === '' ? '—' : $cell) }}</td>
                    @endforeach</tr>
                @empty
                    <tr><td colspan="{{ count($report['headers']) }}"><div class="mp-empty"><i class="bi bi-file-earmark-bar-graph"></i>Tidak ada data pada rentang tanggal ini.</div></td></tr>
                @endforelse
                </tbody>
            </table>
            </div>
        </div>
        @if ($report['summary'])<div class="mp-sub mt-2">{{ $report['summary'] }}</div>@endif
    </div>
</div>
@endsection
