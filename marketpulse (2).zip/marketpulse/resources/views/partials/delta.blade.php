@php $c = $change ?? null; @endphp
@if ($c === null)
    <span class="mp-delta flat">–</span>
@elseif ($c >= 0)
    <span class="mp-delta up"><i class="bi bi-arrow-up-right"></i>{{ number_format($c, 1, ',', '.') }}%</span>
@else
    <span class="mp-delta down"><i class="bi bi-arrow-down-right"></i>{{ number_format(abs($c), 1, ',', '.') }}%</span>
@endif
