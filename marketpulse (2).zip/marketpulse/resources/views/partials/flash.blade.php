@if (session('success'))
    <div class="alert alert-success border-0 rounded-3 d-flex align-items-center gap-2 py-2" role="alert"><i class="bi bi-check-circle-fill"></i>{{ session('success') }}</div>
@endif
@if ($errors->any() && ! request()->routeIs('login', 'register'))
    <div class="alert alert-danger border-0 rounded-3 py-2" role="alert">
        <div class="fw-bold mb-1">Periksa kembali isian Anda:</div>
        <ul class="mb-0 ps-3">@foreach ($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
    </div>
@endif
