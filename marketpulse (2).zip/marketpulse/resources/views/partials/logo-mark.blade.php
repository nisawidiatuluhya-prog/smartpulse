{{-- Logo MarketPulse: kotak gradien + garis denyut. Pakai: @include('partials.logo-mark', ['id' => 'x', 'size' => 40]) --}}
@php($id = $id ?? 'lm'.uniqid())
<svg class="mp-logo-mark" width="{{ $size ?? 36 }}" height="{{ $size ?? 36 }}" viewBox="0 0 64 64" aria-hidden="true">
    <defs><linearGradient id="{{ $id }}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6366f1"/><stop offset=".55" stop-color="#8b5cf6"/><stop offset="1" stop-color="#06b6d4"/></linearGradient></defs>
    <rect width="64" height="64" rx="18" fill="url(#{{ $id }})"/>
    <path class="pulse" d="M11 37h9l5-13 8 23 6-17 3 7h11" fill="none" stroke="#fff" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
