@extends('layouts.app')
@section('title', 'Settings')

@section('content')
<div class="mp-card" style="max-width:620px">
    <h2 class="mp-card-title mb-3">Pengaturan bisnis</h2>
    <form method="POST" action="{{ route('settings.update') }}">
        @csrf @method('PUT')
        <div class="mb-3"><label class="form-label" for="business_name">Nama bisnis</label><input id="business_name" name="business_name" value="{{ old('business_name', $user->business_name) }}" class="form-control @error('business_name') is-invalid @enderror" required>@error('business_name')<div class="invalid-feedback">{{ $message }}</div>@enderror</div>
        <div class="mb-4"><label class="form-label" for="phone">Telepon bisnis</label><input id="phone" name="phone" value="{{ old('phone', $user->phone) }}" class="form-control"></div>
        <button class="btn btn-primary">Simpan pengaturan</button>
    </form>
</div>
@endsection
