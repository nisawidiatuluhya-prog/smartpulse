@extends('layouts.app')
@section('title', 'Smart Insights')

@section('content')
@php
    $tone = $score >= 70 ? '#10b981' : ($score >= 45 ? '#f59e0b' : '#f43f5e');
    $label = $score >= 70 ? 'Sehat' : ($score >= 45 ? 'Cukup' : 'Perlu perhatian');
    $off = round(477.5 * (1 - $score / 100), 1);
    $maxDay = max(1, max($weekday['revenue']));
@endphp

<div class="mp-banner">
    <h2>Smart Insights</h2>
    <p>Ringkasan otomatis dari penjualan, stok, dan pelanggan Anda dalam 30 hari terakhir.</p>
    <div class="acts">
        <a href="{{ route('inventory', ['state' => 'low']) }}"><i class="bi bi-boxes me-1"></i>Cek stok menipis</a>
        <a href="{{ route('analytics') }}"><i class="bi bi-graph-up-arrow me-1"></i>Analytics detail</a>
        <a href="{{ route('reports') }}"><i class="bi bi-file-earmark-bar-graph me-1"></i>Laporan</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-4"><div class="mp-card h-100 text-center">
        <h2 class="mp-card-title mb-3">Skor kesehatan bisnis</h2>
        <div class="mp-score" style="--off: {{ $off }}">
            <svg width="190" height="190" viewBox="0 0 190 190"><circle cx="95" cy="95" r="76" fill="none" stroke="#eceefa" stroke-width="16"/><circle class="ring" cx="95" cy="95" r="76" fill="none" stroke="{{ $tone }}" stroke-width="16" stroke-linecap="round"/></svg>
            <div class="num"><div><b>{{ $score }}</b><span style="color: {{ $tone }}">{{ $label }}</span></div></div>
        </div>
        <div class="text-start mt-3">
            @foreach ($parts as [$l, $v, $c])
                <div class="d-flex justify-content-between mp-sub fw-bold mt-2"><span>{{ $l }}</span><span>{{ $v }}%</span></div>
                <div class="mp-meter"><i style="width: {{ $v }}%"></i></div>
            @endforeach
        </div>
    </div></div>

    <div class="col-lg-8">
        @if (empty($insights))
            <div class="mp-card h-100"><div class="mp-empty"><i class="bi bi-stars"></i>Insight muncul otomatis setelah ada penjualan. <a href="{{ route('sales.create') }}">Catat penjualan pertama</a>.</div></div>
        @else
            <div class="row g-3">
                @foreach ($insights as [$icon, $color, $title, $text])
                    <div class="col-md-6"><div class="mp-insight {{ $color }}"><i class="bi {{ $icon }}"></i><div><b>{{ $title }}</b><span>{{ $text }}</span></div></div></div>
                @endforeach
            </div>
        @endif
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-6"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Pola penjualan per hari</h2><span class="mp-sub">90 hari terakhir</span></div>
        <div class="d-flex align-items-end gap-2" style="height:170px">
            @foreach ($weekday['labels'] as $i => $d)
                <div class="flex-fill text-center" style="height:100%;display:flex;flex-direction:column;justify-content:flex-end">
                    <div class="mp-sub fw-bold mb-1" style="font-size:.66rem">{{ rp_short($weekday['revenue'][$i]) }}</div>
                    <div style="height: {{ max(4, round($weekday['revenue'][$i] / $maxDay * 120)) }}px; border-radius: 10px 10px 4px 4px; background: {{ $d === $bestDay ? 'linear-gradient(180deg,#10b981,#14b8a6)' : 'linear-gradient(180deg,#a5b4fc,#6366f1)' }}"></div>
                    <div class="mp-sub mt-1 fw-bold">{{ substr($d, 0, 3) }}</div>
                </div>
            @endforeach
        </div>
    </div></div>
    <div class="col-xl-6"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Pelanggan teratas</h2><span class="mp-sub">90 hari terakhir</span></div>
        @if ($topCustomers->isEmpty())
            <div class="mp-empty"><i class="bi bi-people"></i>Belum ada transaksi atas nama pelanggan.</div>
        @else
            <ul class="mp-rank">
                @foreach ($topCustomers as $i => $c)
                    <li><span class="no">{{ $i + 1 }}</span><div class="nm"><a href="{{ route('customers.show', $c->id) }}" class="text-reset">{{ $c->name }}</a><small>{{ $c->orders }} transaksi</small></div><div class="val">{{ rp_short($c->spent) }}</div></li>
                @endforeach
            </ul>
        @endif
    </div></div>
</div>

<div class="row g-3">
    <div class="col-xl-6"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Saran restock</h2><a href="{{ route('inventory', ['state' => 'low']) }}" class="btn btn-sm btn-light">Ke Inventory</a></div>
        @if ($restock->isEmpty())
            <div class="mp-empty"><i class="bi bi-check2-circle"></i>Tidak ada produk yang diperkirakan habis dalam 14 hari.</div>
        @else
            <ul class="mp-rank">
                @foreach ($restock as $r)
                    <li><span class="no"><i class="bi bi-box-seam"></i></span><div class="nm">{{ $r['product']->name }}<small>stok {{ $r['product']->stock }} · laku ±{{ number_format($r['per_day'], 1, ',', '.') }}/hari</small></div>
                        <div class="val"><span class="mp-pill {{ $r['days'] <= 7 ? 'red' : 'orange' }}">{{ $r['product']->stock <= 0 ? 'Habis' : '± '.$r['days'].' hari' }}</span></div></li>
                @endforeach
            </ul>
        @endif
    </div></div>
    <div class="col-xl-6"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Produk lambat laku</h2>@if ($slow->isNotEmpty())<span class="mp-sub">modal tertahan {{ rp_short($slowValue) }}</span>@endif</div>
        @if ($slow->isEmpty())
            <div class="mp-empty"><i class="bi bi-emoji-smile"></i>Semua produk bersetok terjual dalam 30 hari terakhir.</div>
        @else
            <ul class="mp-rank">
                @foreach ($slow as $p)
                    <li><span class="no"><i class="bi bi-hourglass-split"></i></span><div class="nm">{{ $p->name }}<small>stok {{ $p->stock }} · tidak laku 30 hari</small></div><div class="val">{{ rp_short($p->price * $p->stock) }}<small>nilai stok</small></div></li>
                @endforeach
            </ul>
        @endif
    </div></div>
</div>
@endsection
