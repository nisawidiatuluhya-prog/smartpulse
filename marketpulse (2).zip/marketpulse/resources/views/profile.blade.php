@extends('layouts.app')
@section('title', 'Profile')

@section('content')
<div class="row g-3">
    <div class="col-lg-6">
        <div class="mp-card">
            <h2 class="mp-card-title mb-3">Informasi akun</h2>
            <form method="POST" action="{{ route('profile.update') }}">
                @csrf @method('PUT')
                <div class="mb-3"><label class="form-label" for="name">Nama</label><input id="name" name="name" value="{{ old('name', $user->name) }}" class="form-control @error('name') is-invalid @enderror" required>@error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror</div>
                <div class="mb-4"><label class="form-label" for="email">Email</label><input id="email" type="email" name="email" value="{{ old('email', $user->email) }}" class="form-control @error('email') is-invalid @enderror" required>@error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror</div>
                <button class="btn btn-primary">Simpan profil</button>
            </form>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="mp-card">
            <h2 class="mp-card-title mb-3">Ganti password</h2>
            <form method="POST" action="{{ route('profile.password') }}">
                @csrf @method('PUT')
                <div class="mb-3"><label class="form-label" for="current_password">Password saat ini</label><input id="current_password" type="password" name="current_password" class="form-control" required></div>
                <div class="mb-3"><label class="form-label" for="password">Password baru</label><input id="password" type="password" name="password" class="form-control" required></div>
                <div class="mb-4"><label class="form-label" for="password_confirmation">Ulangi password baru</label><input id="password_confirmation" type="password" name="password_confirmation" class="form-control" required></div>
                <button class="btn btn-primary">Ganti password</button>
            </form>
        </div>
    </div>
</div>
@endsection
