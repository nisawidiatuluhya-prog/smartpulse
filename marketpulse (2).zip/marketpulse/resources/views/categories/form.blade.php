@extends('layouts.app')
@section('title', $category->exists ? 'Edit Category' : 'Add Category')

@section('content')
@php $isAdmin = $admin ?? false; @endphp
<div class="mp-card" style="max-width:560px">
    <form method="POST" action="{{ $category->exists ? route($isAdmin ? 'admin.categories.update' : 'categories.update', $category) : route($isAdmin ? 'admin.categories.store' : 'categories.store') }}">
        @csrf
        @if ($category->exists) @method('PUT') @endif
        <div class="mb-3">
            <label class="form-label" for="name">Nama kategori</label>
            <input id="name" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name', $category->name) }}" required autofocus>
            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="mb-4">
            <label class="form-label" for="description">Deskripsi</label>
            <input id="description" name="description" class="form-control" value="{{ old('description', $category->description) }}">
        </div>
        <button class="btn btn-primary">Simpan kategori</button>
        <a href="{{ route($isAdmin ? 'admin.categories.index' : 'categories.index') }}" class="btn btn-light border">Batal</a>
    </form>
</div>
@endsection
