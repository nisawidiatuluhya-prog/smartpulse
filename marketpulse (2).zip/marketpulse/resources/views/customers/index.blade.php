@extends('layouts.app')
@section('title', 'Customers')

@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Customers</h2><div class="mp-sub">Data pelanggan dan total belanja mereka</div></div>
    <a href="{{ route('customers.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Add customer</a>
</div>
<form method="GET" class="mb-3" style="max-width:380px"><input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Cari nama, email, telepon"></form>

<div class="mp-card p-0 overflow-hidden">
    <div class="mp-scroll">
    <table class="mp-table">
        <thead><tr><th>Pelanggan</th><th>Kontak</th><th>Transaksi</th><th>Total belanja</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        @forelse ($customers as $c)
            <tr>
                <td><a href="{{ route('customers.show', $c) }}" class="d-flex align-items-center gap-3 text-reset"><span class="mp-thumb c{{ $c->id % 5 }}">{{ mb_substr($c->name, 0, 1) }}</span><b>{{ $c->name }}</b></a></td>
                <td>{{ $c->email ?: '—' }}<br><span class="mp-sub">{{ $c->phone ?: '' }}</span></td>
                <td>{{ $c->sales_count }}</td>
                <td class="num">{{ rp($c->sales_sum_total ?? 0) }}</td>
                <td class="text-end">
                    <a href="{{ route('customers.show', $c) }}" class="btn btn-sm btn-light border">Riwayat</a>
                    <a href="{{ route('customers.edit', $c) }}" class="btn btn-sm btn-light border">Edit</a>
                    <form method="POST" action="{{ route('customers.destroy', $c) }}" class="d-inline" data-confirm="Hapus pelanggan ini?">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Hapus</button></form>
                </td>
            </tr>
        @empty
            <tr><td colspan="5"><div class="mp-empty"><i class="bi bi-people"></i>Belum ada pelanggan.</div></td></tr>
        @endforelse
        </tbody>
    </table>
    </div>
    @if ($customers->hasPages())<div class="p-3">{{ $customers->links() }}</div>@endif
</div>
@endsection
