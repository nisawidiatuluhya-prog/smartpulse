@extends('layouts.app')
@section('title', $customer->exists ? 'Edit Customer' : 'Add Customer')

@section('content')
<div class="mp-card" style="max-width:620px">
    <form method="POST" action="{{ $customer->exists ? route('customers.update', $customer) : route('customers.store') }}">
        @csrf
        @if ($customer->exists) @method('PUT') @endif
        @foreach ([['name','Nama pelanggan','text',true],['email','Email','email',false],['phone','Nomor telepon','text',false]] as [$f,$l,$t,$req])
            <div class="mb-3">
                <label class="form-label" for="{{ $f }}">{{ $l }}</label>
                <input id="{{ $f }}" type="{{ $t }}" name="{{ $f }}" value="{{ old($f, $customer->$f) }}" class="form-control @error($f) is-invalid @enderror" {{ $req ? 'required' : '' }}>
                @error($f)<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
        @endforeach
        <div class="mb-4"><label class="form-label" for="address">Alamat</label><textarea id="address" name="address" rows="3" class="form-control">{{ old('address', $customer->address) }}</textarea></div>
        <button class="btn btn-primary">Simpan pelanggan</button>
        <a href="{{ route('customers.index') }}" class="btn btn-light border">Batal</a>
    </form>
</div>
@endsection
