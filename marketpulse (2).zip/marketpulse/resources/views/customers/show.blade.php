@extends('layouts.app')
@section('title', $customer->name)

@section('content')
<div class="row g-3">
    <div class="col-lg-4">
        <div class="mp-card">
            <div class="d-flex align-items-center gap-3 mb-3"><span class="mp-thumb c{{ $customer->id % 5 }}" style="width:52px;height:52px;flex-basis:52px;font-size:1.3rem;font-weight:800">{{ mb_substr($customer->name, 0, 1) }}</span><div><h2 class="fw-bold fs-5 mb-0">{{ $customer->name }}</h2><span class="mp-sub">Sejak {{ $customer->created_at->translatedFormat('M Y') }}</span></div></div>
            <dl class="mb-3">
                <dt class="mp-sub fw-semibold">Email</dt><dd>{{ $customer->email ?: '—' }}</dd>
                <dt class="mp-sub fw-semibold">Telepon</dt><dd>{{ $customer->phone ?: '—' }}</dd>
                <dt class="mp-sub fw-semibold">Alamat</dt><dd>{{ $customer->address ?: '—' }}</dd>
            </dl>
            <div class="d-flex justify-content-between border-top pt-3"><span class="mp-sub">Total belanja</span><b>{{ rp($totalSpent) }}</b></div>
            <div class="d-flex gap-2 mt-3"><a href="{{ route('customers.edit', $customer) }}" class="btn btn-light border btn-sm">Edit</a><a href="{{ route('customers.index') }}" class="btn btn-light border btn-sm">Kembali</a></div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="mp-card p-0 overflow-hidden">
            <div class="p-3 pb-0"><h2 class="mp-card-title">Riwayat transaksi</h2></div>
            <div class="mp-scroll">
            <table class="mp-table">
                <thead><tr><th>No. Transaksi</th><th>Tanggal</th><th>Item</th><th class="text-end">Total</th></tr></thead>
                <tbody>
                @forelse ($sales as $s)
                    <tr><td><a href="{{ route('sales.show', $s) }}" class="fw-bold text-reset">{{ $s->invoice_no }}</a></td><td>{{ $s->sold_at->translatedFormat('d M Y') }}</td><td>{{ $s->details_count }}</td><td class="text-end num">{{ rp($s->total) }}</td></tr>
                @empty
                    <tr><td colspan="4"><div class="mp-empty"><i class="bi bi-receipt"></i>Belum ada transaksi.</div></td></tr>
                @endforelse
                </tbody>
            </table>
            </div>
            @if ($sales->hasPages())<div class="p-3">{{ $sales->links() }}</div>@endif
        </div>
    </div>
</div>
@endsection
