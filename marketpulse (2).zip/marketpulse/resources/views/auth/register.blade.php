@extends('layouts.guest')
@section('title', 'Daftar')
@section('body')
<div class="mp-auth">
    <div class="mp-auth-side">
        <a href="{{ route('home') }}" class="mp-logo text-white p-0"><i class="bi bi-activity"></i>{{ $appName }}</a>
        <div>
            <h2>Mulai kelola bisnis Anda dengan data, bukan perkiraan.</h2>
            <p class="mt-3">Daftar gratis, tambahkan produk, catat penjualan pertama, dan lihat grafik performa langsung terisi.</p>
        </div>
        <small class="opacity-75">{{ $appTagline }}</small>
    </div>
    <div class="mp-auth-form">
        <div class="mp-auth-box">
            <h3 class="fw-bold mb-1">Buat akun Business Owner</h3>
            <p class="mp-sub mb-4">Sudah punya akun? <a href="{{ route('login') }}" class="fw-bold">Masuk</a></p>

            <form method="POST" action="{{ route('register') }}" novalidate>
                @csrf
                @foreach ([['name','Nama lengkap','text'],['business_name','Nama bisnis','text'],['email','Email','email'],['phone','Nomor telepon (opsional)','text']] as [$f,$l,$t])
                    <div class="mb-3">
                        <label class="form-label" for="{{ $f }}">{{ $l }}</label>
                        <input id="{{ $f }}" type="{{ $t }}" name="{{ $f }}" value="{{ old($f) }}" class="form-control @error($f) is-invalid @enderror" {{ $f !== 'phone' ? 'required' : '' }}>
                        @error($f)<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                @endforeach
                <div class="row g-3 mb-4">
                    <div class="col-6">
                        <label class="form-label" for="password">Password</label>
                        <input id="password" type="password" name="password" class="form-control @error('password') is-invalid @enderror" required>
                        @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-6">
                        <label class="form-label" for="password_confirmation">Ulangi password</label>
                        <input id="password_confirmation" type="password" name="password_confirmation" class="form-control" required>
                    </div>
                </div>
                <button class="btn btn-primary w-100 py-2">Daftar &amp; masuk ke dashboard</button>
            </form>
        </div>
    </div>
</div>
@endsection
