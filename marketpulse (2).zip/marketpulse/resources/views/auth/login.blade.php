@extends('layouts.guest')
@section('title', 'Login')
@section('body')
<div class="mp-auth">
    <div class="mp-auth-side">
        <a href="{{ route('home') }}" class="mp-logo text-white p-0"><i class="bi bi-activity"></i>{{ $appName }}</a>
        <div>
            <h2>Pantau penjualan, stok, dan pelanggan dari satu dashboard.</h2>
            <p class="mt-3">Semua angka dihitung langsung dari transaksi Anda, jadi keputusan bisnis berdasarkan data yang nyata.</p>
        </div>
        <small class="opacity-75">{{ $appTagline }}</small>
    </div>
    <div class="mp-auth-form">
        <div class="mp-auth-box">
            <h3 class="fw-bold mb-1">Masuk ke akun Anda</h3>
            <p class="mp-sub mb-4">Belum punya akun? <a href="{{ route('register') }}" class="fw-bold">Daftar sebagai Business Owner</a></p>

            @if ($errors->any())
                <div class="alert alert-danger border-0 rounded-3 py-2">{{ $errors->first() }}</div>
            @endif

            <form method="POST" action="{{ route('login') }}">
                @csrf
                <div class="mb-3">
                    <label class="form-label" for="email">Email</label>
                    <input id="email" type="email" name="email" value="{{ old('email') }}" class="form-control" required autofocus>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="password">Password</label>
                    <input id="password" type="password" name="password" class="form-control" required>
                </div>
                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember">
                    <label class="form-check-label" for="remember">Ingat saya</label>
                </div>
                <button class="btn btn-primary w-100 py-2">Masuk</button>
            </form>
        </div>
    </div>
</div>
@endsection
