@extends('layouts.app')
@section('title', 'Business Overview')

@section('content')
@php
    $palette = ['#6366f1', '#ec4899', '#f59e0b', '#06b6d4', '#10b981', '#8b5cf6', '#f43f5e'];
    $bar = fn ($c) => $c === null ? 100 : max(8, min(100, abs($c)));
    $statCards = [
        ['Total Revenue', rp_short($cards['revenue']['value']), $cards['revenue']['change'], 'pink', 'Last 30 days', 'bi-cash-stack'],
        ['Total Products', number_format($cards['products']['value'], 0, ',', '.'), $cards['products']['change'], 'indigo', $lowStock.' stok menipis', 'bi-box-seam'],
        ['Total Sales', number_format($cards['sales']['value'], 0, ',', '.'), $cards['sales']['change'], 'cyan', 'Last 30 days', 'bi-receipt'],
        ['Total Customers', number_format($cards['customers']['value'], 0, ',', '.'), $cards['customers']['change'], 'emerald', 'New, last 30 days', 'bi-people'],
    ];
@endphp

<div class="row g-3 mb-3">
    @foreach ($statCards as [$label, $value, $chg, $grad, $meta, $icon])
        <div class="col-6 col-xl-3">
            <div class="mp-card mp-stat g-{{ $grad }}">
                <div class="label"><span><i class="bi {{ $icon }} me-1"></i>{{ $label }}</span><span class="value js-count">{{ $value }}</span></div>
                <div class="bar"><span style="width: {{ $bar($chg) }}%"></span></div>
                <div class="meta"><span>{{ $meta }}</span>@include('partials.delta', ['change' => $chg])</div>
            </div>
        </div>
    @endforeach
</div>

<div class="row g-3 mb-3">
    @foreach ([
        ['bi-sun', 'orange', rp_short($quick['today_revenue']), $quick['today_orders'].' transaksi hari ini', route('sales.index')],
        ['bi-x-octagon', 'red', $quick['out'], 'Produk stok habis', route('inventory', ['state' => 'out'])],
        ['bi-box-seam', 'indigo', $quick['restock'], 'Perlu restock ≤14 hari', route('insights')],
        ['bi-hourglass-split', 'cyan', $quick['slow'], 'Produk lambat laku', route('insights')],
    ] as [$ic, $c, $v, $l, $url])
        <div class="col-6 col-xl-3"><a class="mp-tile-link" href="{{ $url }}"><div class="mp-kpi"><span class="ic {{ $c }}"><i class="bi {{ $ic }}"></i></span><div><b>{{ $v }}</b><span>{{ $l }}</span></div></div></a></div>
    @endforeach
</div>

<div class="row g-3">
    <div class="col-xl-8">
        <div class="mp-card mb-3">
            <div class="mp-card-head">
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <div class="mp-seg" id="chartTabs">
                        <button type="button" class="on" data-mode="overview">Sales Overview</button>
                        <button type="button" data-mode="revenue">Monthly Revenue</button>
                    </div>
                </div>
                <form method="GET"><select name="range" class="form-select form-select-sm" style="width:130px" data-autosubmit>
                    <option value="12m" @selected($view === '12m')>Yearly</option>
                    <option value="30d" @selected($view === '30d')>Last 30 days</option>
                </select></form>
            </div>
            <div class="mp-chart"><canvas id="mainChart"></canvas></div>
        </div>

        <div class="mp-card">
            <div class="mp-card-head">
                <h2 class="mp-card-title">Recent Sales</h2>
                <a href="{{ route('sales.index') }}" class="btn btn-sm btn-light">Lihat semua</a>
            </div>
            @if ($recent->isEmpty())
                <div class="mp-empty"><i class="bi bi-receipt"></i>Belum ada transaksi. <a href="{{ route('sales.create') }}">Catat penjualan pertama</a>.</div>
            @else
                <div class="mp-scroll">
                <table class="mp-table">
                    <thead><tr><th>Invoice</th><th>Customer</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th></tr></thead>
                    <tbody>
                    @foreach ($recent as $i => $s)
                        <tr>
                            <td><a href="{{ route('sales.show', $s) }}" class="d-flex align-items-center gap-2 text-reset fw-bold"><span class="mp-idx c{{ $i % 6 }}">{{ sprintf('%02d', $i + 1) }}</span>{{ $s->invoice_no }}</a></td>
                            <td>{{ $s->customer?->name ?? 'Umum' }}</td>
                            <td>{{ $s->sold_at->translatedFormat('d M Y') }}</td>
                            <td>{{ $s->details_count }}</td>
                            <td class="num">{{ rp($s->total) }}</td>
                            <td><span class="mp-pill green">Selesai</span></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
                </div>
            @endif
        </div>
    </div>

    <div class="col-xl-4">
        <div class="mp-card mb-3">
            <div class="mp-card-head"><h2 class="mp-card-title">Sales by Category</h2></div>
            @if ($categories->isEmpty())
                <div class="mp-empty"><i class="bi bi-pie-chart"></i>Belum ada data penjualan.</div>
            @else
                <div class="mp-donut">
                    <canvas id="catChart"></canvas>
                    <div class="center"><div><b>{{ round($categories->first()->units / $catTotal * 100) }}%</b><span>{{ $categories->first()->name }}</span></div></div>
                </div>
                <div class="mp-legend">
                    @foreach ($categories->take(5) as $i => $c)
                        <div><i style="background: {{ $palette[$i % count($palette)] }}"></i>{{ $c->name }}<span class="v">{{ number_format($c->units, 0, ',', '.') }} unit</span></div>
                    @endforeach
                </div>
            @endif
        </div>

        <div class="mp-card">
            <div class="mp-card-head"><h2 class="mp-card-title">Best Selling Products</h2></div>
            @if ($topProducts->isEmpty())
                <div class="mp-empty"><i class="bi bi-box-seam"></i>Produk terlaris muncul setelah ada penjualan.</div>
            @else
                <ul class="mp-list">
                    @foreach ($topProducts as $i => $p)
                        <li>
                            <span class="mp-thumb c{{ $i % 5 }}">@if ($p->image)<img src="{{ asset('storage/'.$p->image) }}" alt="">@else<i class="bi bi-box-seam"></i>@endif</span>
                            <div><div class="nm">{{ $p->name }}</div><div class="sk">{{ $p->sku ? '#'.$p->sku : '—' }}</div></div>
                            <div class="end"><b>{{ number_format($p->units, 0, ',', '.') }} unit</b>{{ rp_short($p->revenue) }}</div>
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
(() => {
    const d = @json($chart);
    const ctx = document.getElementById('mainChart');
    let chart;
    const grid = { color: '#eef1f7' };

    function draw(mode) {
        if (chart) chart.destroy();
        const grad = mpGradient(ctx, '99,102,241', .32, 300);
        const config = mode === 'overview' ? {
            type: 'line',
            data: { labels: d.labels, datasets: [
                { label: 'Revenue', data: d.revenue, borderColor: '#6366f1', backgroundColor: grad, fill: true, tension: .4, pointRadius: 0, pointHoverRadius: 5, borderWidth: 2.5, yAxisID: 'y' },
                { label: 'Units sold', data: d.units, borderColor: '#ec4899', tension: .4, pointRadius: 0, pointHoverRadius: 5, borderWidth: 2.5, yAxisID: 'y1' },
            ]},
            options: opts({ y: { grid, ticks: { callback: v => rpShort(v) }, beginAtZero: true }, y1: { position: 'right', grid: { display: false }, beginAtZero: true } }, true),
        } : {
            type: 'bar',
            data: { labels: d.labels, datasets: [{ label: 'Revenue', data: d.revenue, backgroundColor: mpGradient(ctx, '99,102,241', .95, 300), borderRadius: 8, maxBarThickness: 34 }] },
            options: opts({ y: { grid, ticks: { callback: v => rpShort(v) }, beginAtZero: true } }, false),
        };
        chart = new Chart(ctx, config);
    }

    function opts(scales, legend) {
        return {
            responsive: true, maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: { legend: { display: legend, position: 'top', align: 'start', labels: { usePointStyle: true, boxWidth: 8 } },
                tooltip: { callbacks: { label: c => c.dataset.label + ': ' + (c.dataset.label === 'Units sold' ? c.parsed.y.toLocaleString('id-ID') : rp(c.parsed.y)) } } },
            scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 12 } }, ...scales },
        };
    }

    document.querySelectorAll('#chartTabs button').forEach(b => b.addEventListener('click', () => {
        document.querySelectorAll('#chartTabs button').forEach(x => x.classList.toggle('on', x === b));
        draw(b.dataset.mode);
    }));
    draw('overview');

    @if ($categories->isNotEmpty())
    new Chart(document.getElementById('catChart'), {
        type: 'doughnut',
        data: { labels: @json($categories->pluck('name')), datasets: [{ data: @json($categories->pluck('units')->map(fn ($v) => (int) $v)), backgroundColor: @json($palette), borderWidth: 3, borderColor: '#fff' }] },
        options: { cutout: '72%', maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => c.label + ': ' + c.parsed.toLocaleString('id-ID') + ' unit' } } } },
    });
    @endif
})();
</script>
@endpush
