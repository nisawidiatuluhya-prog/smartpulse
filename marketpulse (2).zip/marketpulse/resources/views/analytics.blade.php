@extends('layouts.app')
@section('title', 'Analytics')

@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Analytics Overview</h2><div class="mp-sub">Detailed insights into your business performance</div></div>
    <form method="GET" class="d-flex flex-wrap gap-2 align-items-center">
        <select name="period" class="form-select form-select-sm w-auto" onchange="this.form.from.value='';this.form.to.value='';this.form.submit()">
            <option value="">Periode cepat</option>
            @foreach ([7 => '7 hari', 30 => '30 hari', 90 => '90 hari', 365 => '12 bulan'] as $v => $l)<option value="{{ $v }}" @selected((int) request('period') === $v)>{{ $l }} terakhir</option>@endforeach
        </select>
        <input type="date" name="from" value="{{ $from->toDateString() }}" class="form-control form-control-sm w-auto" aria-label="Dari">
        <input type="date" name="to" value="{{ $to->toDateString() }}" class="form-control form-control-sm w-auto" aria-label="Sampai">
        <select name="group" class="form-select form-select-sm w-auto">
            @foreach (['day' => 'Daily', 'week' => 'Weekly', 'month' => 'Monthly'] as $v => $l)<option value="{{ $v }}" @selected($group === $v)>{{ $l }}</option>@endforeach
        </select>
        <button class="btn btn-primary btn-sm">Terapkan</button>
        <a href="{{ route('reports', ['from' => $from->toDateString(), 'to' => $to->toDateString()]) }}" class="btn btn-light border btn-sm"><i class="bi bi-download me-1"></i>Export</a>
    </form>
</div>

<div class="row g-3 mb-3">
    @foreach ($cards as $c)
        <div class="col-6 col-xl-3">
            <div class="mp-card mp-big">
                <div class="ico"><i class="bi {{ $c['icon'] }}"></i></div>
                <div class="lbl">{{ $c['label'] }}</div>
                <div class="row1"><span class="num js-count">{{ $c['value'] }}</span>@include('partials.delta', ['change' => $c['change']])</div>
            </div>
        </div>
    @endforeach
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-7">
        <div class="mp-card">
            <div class="mp-card-head"><h2 class="mp-card-title">Revenue Trend</h2><span class="mp-sub">{{ $from->translatedFormat('d M Y') }} – {{ $to->translatedFormat('d M Y') }}</span></div>
            <div class="mp-chart" style="height:300px"><canvas id="trend"></canvas></div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="mp-card">
            <div class="mp-card-head"><h2 class="mp-card-title">Sales by Category</h2><span class="mp-sub">% unit terjual</span></div>
            @if ($categories->isEmpty())
                <div class="mp-empty"><i class="bi bi-bar-chart"></i>Belum ada penjualan pada periode ini.</div>
            @else
                <div class="mp-hbar">
                    @foreach ($categories->take(7) as $cat)
                        @php $share = round($cat->units / $catUnits * 100, 1); @endphp
                        <div class="row2"><div class="fill" style="width: {{ max($share, 22) }}%"><span>{{ $cat->name }}</span><small>{{ $share }}%</small></div></div>
                    @endforeach
                </div>
                <div class="mp-axis"><span>0%</span><span>20%</span><span>40%</span><span>60%</span><span>80%</span><span>100%</span></div>
            @endif
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="mp-card p-0 overflow-hidden">
            <div class="p-3 pb-0"><h2 class="mp-card-title">Produk terlaris</h2></div>
            <div class="mp-scroll">
            <table class="mp-table">
                <thead><tr><th>Produk</th><th class="text-end">Unit</th><th class="text-end">Pendapatan</th></tr></thead>
                <tbody>
                @forelse ($topProducts as $i => $p)
                    <tr><td><span class="d-flex align-items-center gap-2"><span class="mp-idx c{{ $i % 6 }}">{{ $i + 1 }}</span><b>{{ $p->name }}</b></span></td><td class="text-end">{{ number_format($p->units, 0, ',', '.') }}</td><td class="text-end num">{{ rp($p->revenue) }}</td></tr>
                @empty
                    <tr><td colspan="3"><div class="mp-empty">Belum ada data pada periode ini.</div></td></tr>
                @endforelse
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="mp-card">
            <h2 class="mp-card-title mb-3">Ringkasan performa</h2>
            @foreach ([
                ['Total pendapatan', rp($cur['revenue']), pct_change($cur['revenue'], $prev['revenue'])],
                ['Jumlah transaksi', number_format($cur['orders'], 0, ',', '.'), pct_change($cur['orders'], $prev['orders'])],
                ['Rata-rata per transaksi', rp($cur['avg']), pct_change($cur['avg'], $prev['avg'])],
                ['Pelanggan yang membeli', number_format($cur['buyers'], 0, ',', '.'), pct_change($cur['buyers'], $prev['buyers'])],
            ] as [$l, $v, $chg])
                <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                    <span class="mp-sub">{{ $l }}</span><span class="d-flex align-items-center gap-2"><b>{{ $v }}</b>@include('partials.delta', ['change' => $chg])</span>
                </div>
            @endforeach
            <div class="mp-sub mt-3" style="font-size:.72rem">Persentase dibandingkan periode sebelumnya dengan panjang yang sama.</div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
(() => {
    const s = @json($series);
    const ctx = document.getElementById('trend').getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 0, 300);
    grad.addColorStop(0, 'rgba(99,102,241,.38)'); grad.addColorStop(1, 'rgba(99,102,241,0)');
    new Chart(ctx, {
        type: 'line',
        data: { labels: s.labels, datasets: [{ label: 'Revenue', data: s.revenue, borderColor: '#6366f1', backgroundColor: grad, fill: true, tension: .35, borderWidth: 2.5, pointRadius: s.labels.length > 40 ? 0 : 3, pointBackgroundColor: '#fff', pointBorderColor: '#6366f1', pointBorderWidth: 2, pointHoverRadius: 7 }] },
        options: {
            responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => 'Revenue: ' + rp(c.parsed.y) } } },
            scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 8 } }, y: { beginAtZero: true, grid: { color: '#eef1f7' }, ticks: { callback: v => rpShort(v) } } },
        },
    });
})();
</script>
@endpush
