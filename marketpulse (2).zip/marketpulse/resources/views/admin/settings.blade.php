@extends('layouts.app')
@section('title', 'App Settings')

@section('content')
<div class="mp-card" style="max-width:620px">
    <h2 class="mp-card-title mb-3">Pengaturan aplikasi</h2>
    <form method="POST" action="{{ route('admin.settings.update') }}">
        @csrf @method('PUT')
        <div class="mb-3"><label class="form-label" for="app_name">Nama aplikasi</label><input id="app_name" name="app_name" value="{{ old('app_name', $app_name) }}" class="form-control @error('app_name') is-invalid @enderror" required>@error('app_name')<div class="invalid-feedback">{{ $message }}</div>@enderror<div class="mp-sub mt-1">Tampil di sidebar, halaman login, dan landing page.</div></div>
        <div class="mb-3"><label class="form-label" for="tagline">Tagline</label><input id="tagline" name="tagline" value="{{ old('tagline', $tagline) }}" class="form-control"></div>
        <div class="mb-4"><label class="form-label" for="support_email">Email dukungan</label><input id="support_email" type="email" name="support_email" value="{{ old('support_email', $support_email) }}" class="form-control @error('support_email') is-invalid @enderror">@error('support_email')<div class="invalid-feedback">{{ $message }}</div>@enderror</div>
        <button class="btn btn-primary">Simpan pengaturan</button>
    </form>
</div>
@endsection
