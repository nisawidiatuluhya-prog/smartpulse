@extends('layouts.app')
@section('title', $owner->business_name ?: $owner->name)

@section('content')
@php
    $maxUnits = max(1, (float) ($topProducts->max('units') ?? 0));
    $catTotal = max(1, (float) $categories->sum('revenue'));
    $palette = ['#6366f1', '#ec4899', '#f59e0b', '#06b6d4', '#10b981', '#8b5cf6'];
@endphp

<div class="mp-banner">
    <div class="d-flex flex-wrap align-items-center gap-3" style="position:relative">
        <span class="mp-thumb c1" style="width:60px;height:60px;font-weight:800;font-size:1.2rem;border-radius:18px">{{ $owner->initials }}</span>
        <div>
            <h2 class="mb-1">{{ $owner->business_name ?: $owner->name }}</h2>
            <p>{{ $owner->name }} · {{ $owner->email }}@if ($owner->phone) · {{ $owner->phone }}@endif</p>
        </div>
        <div class="ms-auto">@if ($owner->is_active)<span class="mp-pill green">Aktif</span>@else<span class="mp-pill red">Nonaktif</span>@endif</div>
    </div>
    <div class="acts">
        <a href="{{ route('admin.owners') }}"><i class="bi bi-arrow-left me-1"></i>Kembali</a>
        <a href="{{ route('admin.products', ['owner' => $owner->id]) }}"><i class="bi bi-box-seam me-1"></i>Lihat produk</a>
        <a href="{{ route('admin.sales', ['owner' => $owner->id]) }}"><i class="bi bi-receipt me-1"></i>Lihat transaksi</a>
    </div>
</div>

<div class="row g-3 mb-3">
    @foreach ([
        ['bi-cash-stack', 'emerald', rp_short($owner->sales_sum_total ?? 0), 'Total pendapatan'],
        ['bi-receipt', 'indigo', $owner->sales_count, 'Transaksi'],
        ['bi-box-seam', 'cyan', $owner->products_count, 'Produk ('.$stock['active'].' aktif)'],
        ['bi-people', 'pink', $owner->customers_count, 'Pelanggan'],
        ['bi-safe', 'orange', rp_short($stock['value']), 'Nilai stok aktif'],
        ['bi-calendar-check', 'indigo', $lastSale ? \Carbon\Carbon::parse($lastSale)->translatedFormat('d M Y') : '—', 'Transaksi terakhir'],
    ] as [$ic, $c, $v, $l])
        <div class="col-6 col-lg-4 col-xl-2"><div class="mp-kpi"><span class="ic {{ $c }}"><i class="bi {{ $ic }}"></i></span><div><b>{{ $v }}</b><span>{{ $l }}</span></div></div></div>
    @endforeach
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-8"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Pendapatan 6 bulan terakhir</h2><span class="mp-sub">terdaftar {{ $owner->created_at->translatedFormat('d M Y') }}</span></div>
        <div class="mp-chart"><canvas id="ownerChart"></canvas></div>
    </div></div>
    <div class="col-xl-4"><div class="mp-card h-100">
        <h2 class="mp-card-title mb-2">Kondisi stok</h2>
        <ul class="mp-health">
            <li>Produk aktif<span class="n">{{ $stock['active'] }}</span></li>
            <li>Stok menipis<span class="n {{ $stock['low'] ? 'warn' : '' }}">{{ $stock['low'] }}</span></li>
            <li>Stok habis<span class="n {{ $stock['out'] ? 'bad' : '' }}">{{ $stock['out'] }}</span></li>
        </ul>
        <h2 class="mp-card-title mt-3 mb-2">Kategori terlaris</h2>
        @if ($categories->isEmpty())<div class="mp-sub">Belum ada penjualan.</div>
        @else
            <div class="mp-legend">
                @foreach ($categories->take(5) as $i => $c)
                    <div><i style="background: {{ $palette[$i % 6] }}"></i>{{ $c->name }}<span class="v">{{ round($c->revenue / $catTotal * 100) }}%</span></div>
                @endforeach
            </div>
        @endif
    </div></div>
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-5"><div class="mp-card h-100">
        <h2 class="mp-card-title mb-2">Produk terlaris</h2>
        @if ($topProducts->isEmpty())<div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada penjualan.</div>
        @else
            <ul class="mp-rank">
                @foreach ($topProducts as $i => $p)
                    <li><span class="no">{{ $i + 1 }}</span><div class="nm">{{ $p->name }}<div class="mp-meter"><i style="width: {{ round($p->units / $maxUnits * 100) }}%"></i></div></div><div class="val">{{ number_format($p->units, 0, ',', '.') }}<small>unit</small></div></li>
                @endforeach
            </ul>
        @endif
    </div></div>
    <div class="col-xl-7"><div class="mp-card p-0 overflow-hidden h-100">
        <div class="p-3 pb-0"><h2 class="mp-card-title">Transaksi terbaru</h2></div>
        <div class="mp-scroll"><table class="mp-table"><thead><tr><th>No.</th><th>Tanggal</th><th>Pelanggan</th><th class="text-end">Total</th></tr></thead><tbody>
        @forelse ($recent as $s)
            <tr><td><b>{{ $s->invoice_no }}</b></td><td>{{ $s->sold_at->translatedFormat('d M Y') }}</td><td>{{ $s->customer?->name ?? 'Umum' }}</td><td class="text-end num">{{ rp($s->total) }}</td></tr>
        @empty
            <tr><td colspan="4"><div class="mp-empty">Belum ada transaksi.</div></td></tr>
        @endforelse
        </tbody></table></div>
    </div></div>
</div>

<div class="mp-card d-flex flex-wrap align-items-center gap-3">
    <div><b>Tindakan akun</b><div class="mp-sub">Nonaktifkan untuk menutup akses login, atau hapus beserta seluruh datanya.</div></div>
    <div class="ms-auto d-flex gap-2">
        <form method="POST" action="{{ route('admin.owners.toggle', $owner) }}">@csrf @method('PATCH')<button class="btn btn-light border">{{ $owner->is_active ? 'Nonaktifkan akun' : 'Aktifkan akun' }}</button></form>
        <form method="POST" action="{{ route('admin.owners.destroy', $owner) }}" data-confirm="Hapus owner beserta SELURUH produk, pelanggan, dan transaksinya? Tidak bisa dibatalkan.">@csrf @method('DELETE')<button class="btn btn-outline-danger">Hapus owner</button></form>
    </div>
</div>
@endsection

@push('scripts')
<script>
(() => {
    const s = @json($series), c = document.getElementById('ownerChart');
    new Chart(c, {
        type: 'bar',
        data: { labels: s.labels, datasets: [
            { type: 'line', label: 'Pendapatan', data: s.revenue, borderColor: '#6366f1', backgroundColor: mpGradient(c, '99,102,241', .3, 320), fill: true, tension: .4, borderWidth: 3, pointRadius: 4, pointBackgroundColor: '#fff', pointBorderColor: '#6366f1', pointBorderWidth: 2, yAxisID: 'y' },
            { type: 'bar', label: 'Transaksi', data: s.orders, backgroundColor: 'rgba(236,72,153,.5)', borderRadius: 6, maxBarThickness: 22, yAxisID: 'y1' },
        ] },
        options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
            plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } }, tooltip: { callbacks: { label: x => x.dataset.yAxisID === 'y' ? ' ' + rp(x.parsed.y) : ' ' + x.parsed.y + ' transaksi' } } },
            scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#eef0fa' }, ticks: { callback: v => rpShort(v) } }, y1: { beginAtZero: true, position: 'right', grid: { display: false }, ticks: { precision: 0 } } } },
    });
})();
</script>
@endpush
