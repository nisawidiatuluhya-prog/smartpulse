@extends('layouts.app')
@section('title', 'Platform Analytics')

@section('content')
@php
    $periods = [7 => '7 hari', 30 => '30 hari', 90 => '90 hari', 365 => '365 hari'];
    $groups = ['day' => 'Harian', 'week' => 'Mingguan', 'month' => 'Bulanan'];
    $maxRank = max(1, (float) ($ranking->max('revenue') ?? 0));
    $maxProd = max(1, (float) ($topProducts->max('units') ?? 0));
    $catRev = max(1, (float) $categories->sum('revenue'));
    $bestIdx = array_sum($weekday['revenue']) > 0 ? array_search(max($weekday['revenue']), $weekday['revenue']) : null;
@endphp

<form method="GET" class="mp-filter">
    <select name="period" class="form-select form-select-sm" onchange="this.form.from.value='';this.form.to.value='';this.form.submit()">
        <option value="">Periode cepat</option>
        @foreach ($periods as $v => $l)<option value="{{ $v }}" @selected((int) request('period') === $v)>{{ $l }} terakhir</option>@endforeach
    </select>
    <input type="date" name="from" value="{{ $from->toDateString() }}" class="form-control form-control-sm" aria-label="Dari">
    <input type="date" name="to" value="{{ $to->toDateString() }}" class="form-control form-control-sm" aria-label="Sampai">
    <select name="group" class="form-select form-select-sm">
        @foreach ($groups as $v => $l)<option value="{{ $v }}" @selected($group === $v)>{{ $l }}</option>@endforeach
    </select>
    <button class="btn btn-primary btn-sm">Terapkan</button>
    <span class="mp-sub ms-auto">{{ $from->translatedFormat('d M Y') }} – {{ $to->translatedFormat('d M Y') }} ({{ $days }} hari)</span>
</form>

<div class="row g-3 mb-3">
    @foreach ([
        ['Revenue platform', rp_short($cur['revenue']), $changes['revenue'], 'indigo', 'bi-cash-stack'],
        ['Transaksi', number_format($cur['orders'], 0, ',', '.'), $changes['orders'], 'pink', 'bi-receipt'],
        ['Unit terjual', number_format($cur['units'], 0, ',', '.'), $changes['units'], 'cyan', 'bi-box-seam'],
        ['Owner bertransaksi', number_format($cur['sellers'], 0, ',', '.'), $changes['sellers'], 'emerald', 'bi-shop'],
    ] as [$l, $v, $chg, $g, $i])
        <div class="col-6 col-xl-3"><div class="mp-card mp-stat g-{{ $g }}">
            <div class="label"><span><i class="bi {{ $i }} me-1"></i>{{ $l }}</span><span class="value js-count">{{ $v }}</span></div>
            <div class="bar"><span style="width:{{ $chg === null ? 100 : max(8, min(100, abs($chg))) }}%"></span></div>
            <div class="meta"><span>vs periode sebelumnya</span>@include('partials.delta', ['change' => $chg])</div>
        </div></div>
    @endforeach
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-8"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Tren pendapatan &amp; transaksi</h2><span class="mp-sub">Rata-rata transaksi {{ rp($cur['avg']) }} · rata-rata per owner {{ rp_short($cur['per_seller']) }}</span></div>
        <div class="mp-chart"><canvas id="trend"></canvas></div>
    </div></div>
    <div class="col-xl-4"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Pendapatan per hari</h2>@if ($bestIdx !== null)<span class="mp-pill green">Terbaik: {{ $weekday['labels'][$bestIdx] }}</span>@endif</div>
        <div class="mp-chart"><canvas id="weekday"></canvas></div>
    </div></div>
</div>

<div class="row g-3">
    <div class="col-xl-4"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Kategori terlaris</h2></div>
        @if ($categories->isEmpty())<div class="mp-empty"><i class="bi bi-tags"></i>Belum ada data.</div>
        @else
            <div class="mp-hbar">
                @foreach ($categories->take(7) as $c)
                    @php $share = round($c->revenue / $catRev * 100, 1); @endphp
                    <div class="row2"><div class="fill" style="width: {{ max($share, 24) }}%"><span>{{ $c->name }}</span><small>{{ $share }}%</small></div></div>
                @endforeach
            </div>
        @endif
    </div></div>
    <div class="col-xl-4"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Produk terlaris</h2></div>
        @if ($topProducts->isEmpty())<div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada data.</div>
        @else
            <ul class="mp-rank">
                @foreach ($topProducts as $i => $p)
                    <li><span class="no">{{ $i + 1 }}</span><div class="nm">{{ $p->name }}<small>{{ $p->sellers }} toko</small><div class="mp-meter"><i style="width: {{ round($p->units / $maxProd * 100) }}%"></i></div></div><div class="val">{{ number_format($p->units, 0, ',', '.') }}<small>unit</small></div></li>
                @endforeach
            </ul>
        @endif
    </div></div>
    <div class="col-xl-4"><div class="mp-card h-100">
        <div class="mp-card-head"><h2 class="mp-card-title">Perbandingan owner</h2></div>
        @if ($ranking->isEmpty())<div class="mp-empty"><i class="bi bi-trophy"></i>Belum ada transaksi.</div>
        @else
            <ul class="mp-rank">
                @foreach ($ranking as $i => $r)
                    <li><span class="no">{{ $i + 1 }}</span><div class="nm"><a href="{{ route('admin.owners.show', $r->id) }}" class="text-reset">{{ $r->business_name ?: $r->name }}</a><small>{{ $r->orders }} transaksi</small><div class="mp-meter"><i style="width: {{ round($r->revenue / $maxRank * 100) }}%"></i></div></div><div class="val">{{ rp_short($r->revenue) }}</div></li>
                @endforeach
            </ul>
        @endif
    </div></div>
</div>
@endsection

@push('scripts')
<script>
(() => {
    const s = @json($series), w = @json($weekday);
    const t = document.getElementById('trend');
    new Chart(t, {
        type: 'bar',
        data: { labels: s.labels, datasets: [
            { type: 'line', label: 'Pendapatan', data: s.revenue, borderColor: '#6366f1', backgroundColor: mpGradient(t, '99,102,241', .3, 320), fill: true, tension: .4, borderWidth: 3, pointRadius: s.labels.length > 40 ? 0 : 3, yAxisID: 'y' },
            { type: 'bar', label: 'Transaksi', data: s.orders, backgroundColor: 'rgba(236,72,153,.55)', borderRadius: 5, maxBarThickness: 14, yAxisID: 'y1' },
        ] },
        options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
            plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } }, tooltip: { callbacks: { label: c => c.dataset.yAxisID === 'y' ? ' ' + rp(c.parsed.y) : ' ' + c.parsed.y + ' transaksi' } } },
            scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 12 } }, y: { beginAtZero: true, grid: { color: '#eef0fa' }, ticks: { callback: v => rpShort(v) } }, y1: { beginAtZero: true, position: 'right', grid: { display: false }, ticks: { precision: 0 } } } },
    });
    const d = document.getElementById('weekday');
    new Chart(d, {
        type: 'bar',
        data: { labels: w.labels.map(x => x.slice(0, 3)), datasets: [{ label: 'Pendapatan', data: w.revenue, backgroundColor: ['#6366f1', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#f43f5e'], borderRadius: 8, maxBarThickness: 30 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => ' ' + rp(c.parsed.y) } } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#eef0fa' }, ticks: { callback: v => rpShort(v) } } } },
    });
})();
</script>
@endpush
