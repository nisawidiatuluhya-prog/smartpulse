@extends('layouts.app')
@section('title', 'All Transactions')

@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Semua Transaksi</h2><div class="mp-sub">Pantau penjualan seluruh Business Owner (hanya baca)</div></div>
    <a href="{{ route('admin.sales.export', request()->query()) }}" class="btn btn-light border btn-sm"><i class="bi bi-download me-1"></i>Export CSV</a>
</div>

<div class="row g-3 mb-3">
    @foreach ([
        ['bi-receipt', 'indigo', number_format($summary['count'], 0, ',', '.'), 'Transaksi'],
        ['bi-cash-stack', 'emerald', rp_short($summary['revenue']), 'Total pendapatan'],
        ['bi-bag-check', 'pink', rp_short($summary['avg']), 'Rata-rata transaksi'],
        ['bi-shop', 'cyan', $summary['owners'], 'Owner terlibat'],
    ] as [$ic, $c, $v, $l])
        <div class="col-6 col-xl-3"><div class="mp-kpi"><span class="ic {{ $c }}"><i class="bi {{ $ic }}"></i></span><div><b>{{ $v }}</b><span>{{ $l }}</span></div></div></div>
    @endforeach
</div>

<form method="GET" class="mp-filter">
    <input type="search" name="q" value="{{ request('q') }}" class="form-control form-control-sm" placeholder="Invoice / pelanggan">
    <select name="owner" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua owner</option>
        @foreach ($owners as $o)<option value="{{ $o->id }}" @selected((int) request('owner') === $o->id)>{{ $o->business_name ?: $o->name }}</option>@endforeach
    </select>
    <input type="date" name="from" value="{{ request('from') }}" class="form-control form-control-sm" aria-label="Dari">
    <input type="date" name="to" value="{{ request('to') }}" class="form-control form-control-sm" aria-label="Sampai">
    <button class="btn btn-primary btn-sm">Terapkan</button>
    @if (request()->hasAny(['q', 'owner', 'from', 'to']))<a href="{{ route('admin.sales') }}" class="btn btn-light border btn-sm">Reset</a>@endif
</form>

<div class="mp-card p-0 overflow-hidden"><div class="mp-scroll">
<table class="mp-table">
    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Owner</th><th>Pelanggan</th><th>Item</th><th class="text-end">Total</th></tr></thead>
    <tbody>
    @forelse ($sales as $s)
        <tr>
            <td><b>{{ $s->invoice_no }}</b></td>
            <td>{{ $s->sold_at->translatedFormat('d M Y') }}</td>
            <td><a href="{{ route('admin.owners.show', $s->user_id) }}" class="text-reset">{{ $s->user->business_name ?: $s->user->name }}</a></td>
            <td>{{ $s->customer?->name ?? 'Umum' }}</td>
            <td>{{ $s->details_count }}</td>
            <td class="text-end num">{{ rp($s->total) }}</td>
        </tr>
    @empty
        <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-receipt"></i>Tidak ada transaksi yang cocok.</div></td></tr>
    @endforelse
    </tbody>
</table></div>
@if ($sales->hasPages())<div class="p-3">{{ $sales->links() }}</div>@endif
</div>
@endsection
