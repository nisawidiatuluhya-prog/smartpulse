@extends('layouts.app')
@section('title', 'Administration Overview')

@section('content')
@php
    $palette = ['#6366f1', '#ec4899', '#f59e0b', '#06b6d4', '#10b981', '#8b5cf6'];
    $maxRank = max(1, (float) ($ranking->max('revenue') ?? 0));
    $catTotal = max(1, (float) $categories->sum('revenue'));
    $bar = fn ($c) => $c === null ? 100 : max(8, min(100, abs($c)));
@endphp

<div class="mp-banner">
    <h2>Halo, {{ auth()->user()->name }} 👋</h2>
    <p>{{ now()->translatedFormat('l, d F Y') }} · {{ $stats['active'] }} dari {{ $stats['owners'] }} Business Owner aktif · {{ $stats['orders30'] }} transaksi dalam 30 hari terakhir</p>
    <div class="acts">
        <a href="{{ route('admin.analytics') }}"><i class="bi bi-graph-up-arrow me-1"></i>Platform Analytics</a>
        <a href="{{ route('admin.owners', ['status' => 'inactive']) }}"><i class="bi bi-person-x me-1"></i>Owner nonaktif ({{ $health['inactive_owners'] }})</a>
        <a href="{{ route('admin.products', ['stock' => 'out']) }}"><i class="bi bi-exclamation-triangle me-1"></i>Produk stok habis ({{ $health['out_of_stock'] }})</a>
        <a href="{{ route('admin.categories.create') }}"><i class="bi bi-plus-lg me-1"></i>Kategori global</a>
        <a href="{{ route('admin.settings') }}"><i class="bi bi-sliders me-1"></i>Pengaturan</a>
    </div>
</div>

<div class="row g-3 mb-3">
    @foreach ([
        ['Revenue 30 hari', rp_short($stats['rev30']), $stats['rev_change'], 'pink', 'Total: '.rp_short($stats['revenue']), 'bi-cash-stack'],
        ['Transaksi 30 hari', number_format($stats['orders30'], 0, ',', '.'), $stats['orders_change'], 'indigo', 'Total: '.number_format($stats['sales'], 0, ',', '.'), 'bi-receipt'],
        ['Owner baru 30 hari', number_format($stats['new_owners'], 0, ',', '.'), $stats['new_change'], 'cyan', $stats['owners'].' owner terdaftar', 'bi-person-plus'],
        ['Rata-rata transaksi', rp_short($stats['avg']), null, 'emerald', $stats['sellers'].' owner bertransaksi', 'bi-bag-check'],
    ] as [$l, $v, $chg, $g, $m, $i])
        <div class="col-6 col-xl-3"><div class="mp-card mp-stat g-{{ $g }}">
            <div class="label"><span><i class="bi {{ $i }} me-1"></i>{{ $l }}</span><span class="value js-count">{{ $v }}</span></div>
            <div class="bar"><span style="width:{{ $bar($chg) }}%"></span></div>
            <div class="meta"><span>{{ $m }}</span>@include('partials.delta', ['change' => $chg])</div>
        </div></div>
    @endforeach
</div>

<div class="row g-3 mb-3">
    @foreach ([
        ['bi-box-seam', 'indigo', number_format($stats['products'], 0, ',', '.'), 'Produk di platform'],
        ['bi-safe', 'emerald', rp_short($health['stock_value']), 'Nilai stok aktif'],
        ['bi-exclamation-triangle', 'orange', $health['low_stock'], 'Stok menipis'],
        ['bi-x-octagon', 'red', $health['out_of_stock'], 'Stok habis'],
        ['bi-person-dash', 'pink', $health['no_sales_owners'], 'Owner belum bertransaksi'],
        ['bi-cash-coin', 'cyan', rp_short($stats['per_seller']), 'Rata-rata revenue/owner'],
    ] as [$ic, $c, $v, $l])
        <div class="col-6 col-lg-4 col-xl-2"><div class="mp-kpi"><span class="ic {{ $c }}"><i class="bi {{ $ic }}"></i></span><div><b>{{ $v }}</b><span>{{ $l }}</span></div></div></div>
    @endforeach
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-8">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Pendapatan &amp; transaksi platform</h2><span class="mp-sub">12 bulan terakhir</span></div>
            <div class="mp-chart"><canvas id="revChart"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Kategori terlaris</h2><span class="mp-sub">90 hari</span></div>
            @if ($categories->isEmpty())
                <div class="mp-empty"><i class="bi bi-pie-chart"></i>Belum ada penjualan.</div>
            @else
                <div class="mp-donut"><canvas id="catChart"></canvas><div class="center"><div><b>{{ round($categories->first()->revenue / $catTotal * 100) }}%</b><span>{{ $categories->first()->name }}</span></div></div></div>
                <div class="mp-legend">
                    @foreach ($categories->take(5) as $i => $c)
                        <div><i style="background: {{ $palette[$i % 6] }}"></i>{{ $c->name }}<span class="v">{{ rp_short($c->revenue) }}</span></div>
                    @endforeach
                </div>
            @endif
        </div>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-xl-5">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Peringkat owner</h2><a href="{{ route('admin.owners', ['sort' => 'revenue']) }}" class="btn btn-sm btn-light">Semua</a></div>
            @if ($ranking->isEmpty())
                <div class="mp-empty"><i class="bi bi-trophy"></i>Belum ada transaksi 30 hari terakhir.</div>
            @else
                <ul class="mp-rank">
                    @foreach ($ranking as $i => $r)
                        <li>
                            <span class="no">{{ $i + 1 }}</span>
                            <div class="nm"><a href="{{ route('admin.owners.show', $r->id) }}" class="text-reset">{{ $r->business_name ?: $r->name }}</a><small>{{ $r->orders }} transaksi · 30 hari</small>
                                <div class="mp-meter"><i style="width: {{ round($r->revenue / $maxRank * 100) }}%"></i></div></div>
                            <div class="val">{{ rp_short($r->revenue) }}</div>
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
    <div class="col-xl-4">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Produk terlaris platform</h2><span class="mp-sub">90 hari</span></div>
            @if ($topProducts->isEmpty())
                <div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada data.</div>
            @else
                <ul class="mp-rank">
                    @foreach ($topProducts as $i => $p)
                        <li><span class="no">{{ $i + 1 }}</span><div class="nm">{{ $p->name }}<small>dijual {{ $p->sellers }} toko</small></div><div class="val">{{ number_format($p->units, 0, ',', '.') }} unit<small>{{ rp_short($p->revenue) }}</small></div></li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
    <div class="col-xl-3">
        <div class="mp-card h-100">
            <h2 class="mp-card-title mb-2">Kesehatan platform</h2>
            @php
                $hrows = [
                    ['Owner nonaktif', $health['inactive_owners'], 'warn', route('admin.owners', ['status' => 'inactive'])],
                    ['Owner tanpa transaksi', $health['no_sales_owners'], 'warn', route('admin.owners', ['sort' => 'sales'])],
                    ['Produk stok habis', $health['out_of_stock'], 'bad', route('admin.products', ['stock' => 'out'])],
                    ['Produk stok menipis', $health['low_stock'], 'warn', route('admin.products', ['stock' => 'low'])],
                    ['Produk draft', $health['draft_products'], 'warn', route('admin.products', ['status' => 'draft'])],
                    ['Produk diarsipkan', $health['archived_products'], 'warn', route('admin.products', ['status' => 'archived'])],
                    ['Tanpa kategori', $health['uncategorized'], 'warn', route('admin.products')],
                ];
            @endphp
            <ul class="mp-health">
                @foreach ($hrows as [$l, $n, $tone, $url])
                    <li><a href="{{ $url }}" class="text-reset text-decoration-none">{{ $l }}</a><span class="n {{ $n > 0 ? $tone : '' }}">{{ $n }}</span></li>
                @endforeach
            </ul>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-xl-7">
        <div class="mp-card h-100">
            <div class="mp-card-head"><h2 class="mp-card-title">Aktivitas terbaru</h2><a href="{{ route('admin.sales') }}" class="btn btn-sm btn-light">Semua transaksi</a></div>
            @if ($activity->isEmpty())
                <div class="mp-empty"><i class="bi bi-activity"></i>Belum ada aktivitas.</div>
            @else
                <ul class="mp-feed">
                    @foreach ($activity as $a)
                        <li>
                            <span class="dot" style="background: {{ $a['type'] === 'sale' ? 'linear-gradient(135deg,#10b981,#14b8a6)' : 'linear-gradient(135deg,#6366f1,#8b5cf6)' }}"><i class="bi {{ $a['type'] === 'sale' ? 'bi-receipt' : 'bi-person-plus' }}"></i></span>
                            <div><div class="t"><a href="{{ route('admin.owners.show', $a['owner_id']) }}" class="text-reset text-decoration-none">{{ $a['title'] }}</a></div><div class="m">{{ $a['meta'] }}</div></div>
                            <span class="when">{{ $a['at']->diffForHumans() }}</span>
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
    <div class="col-xl-5">
        <div class="mp-card mb-3">
            <div class="mp-card-head"><h2 class="mp-card-title">Pertumbuhan owner</h2><span class="mp-sub">pendaftar per bulan</span></div>
            <div class="mp-chart sm"><canvas id="regChart"></canvas></div>
        </div>
        <div class="mp-card">
            <h2 class="mp-card-title mb-3">Pendaftar terbaru</h2>
            <ul class="mp-list">
                @forelse ($latest as $i => $o)
                    <li><span class="mp-thumb c{{ $i % 5 }}" style="font-weight:800;font-size:.8rem">{{ $o->initials }}</span>
                        <div><div class="nm">{{ $o->name }}</div><div class="sk">{{ $o->business_name ?: $o->email }}</div></div>
                        <div class="end">@if ($o->is_active)<span class="mp-pill green">Aktif</span>@else<span class="mp-pill red">Nonaktif</span>@endif<div class="mt-1">{{ $o->created_at->diffForHumans(null, true, true) }}</div></div></li>
                @empty
                    <li class="mp-sub">Belum ada pendaftar.</li>
                @endforelse
            </ul>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
(() => {
    const m = @json($monthly);
    const rev = document.getElementById('revChart');
    new Chart(rev, {
        type: 'bar',
        data: {
            labels: m.labels,
            datasets: [
                { type: 'bar', label: 'Pendapatan', data: m.revenue, backgroundColor: mpGradient(rev, '99,102,241', .9, 320), borderRadius: 8, maxBarThickness: 34, yAxisID: 'y' },
                { type: 'line', label: 'Transaksi', data: m.orders, borderColor: '#ec4899', backgroundColor: '#ec4899', tension: .4, borderWidth: 3, pointRadius: 4, pointBackgroundColor: '#fff', pointBorderColor: '#ec4899', pointBorderWidth: 2, yAxisID: 'y1' },
            ],
        },
        options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
            plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } }, tooltip: { callbacks: { label: c => c.dataset.yAxisID === 'y' ? ' ' + rp(c.parsed.y) : ' ' + c.parsed.y + ' transaksi' } } },
            scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#eef0fa' }, ticks: { callback: v => rpShort(v) } }, y1: { beginAtZero: true, position: 'right', grid: { display: false }, ticks: { precision: 0 } } } },
    });
    const reg = document.getElementById('regChart');
    new Chart(reg, {
        type: 'bar',
        data: { labels: m.labels, datasets: [{ label: 'Owner baru', data: m.owners, backgroundColor: mpGradient(reg, '236,72,153', .95, 220), borderRadius: 8, maxBarThickness: 22 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { maxRotation: 0, autoSkip: true } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#eef0fa' } } } },
    });
    const cat = document.getElementById('catChart');
    if (cat) new Chart(cat, {
        type: 'doughnut',
        data: { labels: @json($categories->pluck('name')), datasets: [{ data: @json($categories->pluck('revenue')->map(fn ($v) => (float) $v)), backgroundColor: ['#6366f1', '#ec4899', '#f59e0b', '#06b6d4', '#10b981', '#8b5cf6'], borderWidth: 3, borderColor: '#fff', hoverOffset: 8 }] },
        options: { cutout: '72%', maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => ' ' + c.label + ': ' + rp(c.parsed) } } } },
    });
})();
</script>
@endpush
