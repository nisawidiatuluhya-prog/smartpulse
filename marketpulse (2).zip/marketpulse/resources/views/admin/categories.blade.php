@extends('layouts.app')
@section('title', 'Global Categories')

@section('content')
<div class="d-flex justify-content-between align-items-start mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Kategori global</h2><div class="mp-sub">Tersedia untuk semua Business Owner</div></div>
    <a href="{{ route('admin.categories.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Add category</a>
</div>
<div class="mp-card p-0 overflow-hidden"><table class="mp-table">
    <thead><tr><th>Nama</th><th>Deskripsi</th><th>Dipakai produk</th><th class="text-end">Aksi</th></tr></thead>
    <tbody>
    @forelse ($categories as $c)
        <tr><td><b>{{ $c->name }}</b></td><td class="mp-sub">{{ $c->description ?: '—' }}</td><td>{{ $c->products_count }}</td>
        <td class="text-end"><a href="{{ route('admin.categories.edit', $c) }}" class="btn btn-sm btn-light border">Edit</a>
        <form method="POST" action="{{ route('admin.categories.destroy', $c) }}" class="d-inline" data-confirm="Hapus kategori global ini?">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Hapus</button></form></td></tr>
    @empty
        <tr><td colspan="4"><div class="mp-empty"><i class="bi bi-tags"></i>Belum ada kategori global.</div></td></tr>
    @endforelse
    </tbody></table></div>
@endsection
