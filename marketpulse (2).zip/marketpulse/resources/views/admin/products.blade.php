@extends('layouts.app')
@section('title', 'All Products')

@section('content')
<div class="mb-3"><h2 class="fw-bold fs-4 mb-1">Semua Produk</h2><div class="mp-sub">Pantau katalog dan stok seluruh Business Owner (hanya baca)</div></div>

<div class="row g-3 mb-3">
    @foreach ([
        ['bi-box-seam', 'indigo', number_format($summary['count'], 0, ',', '.'), 'Produk'],
        ['bi-stack', 'cyan', number_format($summary['units'], 0, ',', '.'), 'Total unit stok'],
        ['bi-safe', 'emerald', rp_short($summary['value']), 'Nilai stok'],
        ['bi-exclamation-triangle', 'orange', $summary['low'], 'Stok menipis'],
        ['bi-x-octagon', 'red', $summary['out'], 'Stok habis'],
    ] as [$ic, $c, $v, $l])
        <div class="col-6 col-xl"><div class="mp-kpi"><span class="ic {{ $c }}"><i class="bi {{ $ic }}"></i></span><div><b>{{ $v }}</b><span>{{ $l }}</span></div></div></div>
    @endforeach
</div>

<form method="GET" class="mp-filter">
    <input type="search" name="q" value="{{ request('q') }}" class="form-control form-control-sm" placeholder="Nama / SKU">
    <select name="owner" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua owner</option>
        @foreach ($owners as $o)<option value="{{ $o->id }}" @selected((int) request('owner') === $o->id)>{{ $o->business_name ?: $o->name }}</option>@endforeach
    </select>
    <select name="status" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua status</option>
        @foreach (['active' => 'Active', 'draft' => 'Draft', 'archived' => 'Archived'] as $v => $l)<option value="{{ $v }}" @selected(request('status') === $v)>{{ $l }}</option>@endforeach
    </select>
    <select name="stock" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua stok</option>
        <option value="low" @selected(request('stock') === 'low')>Menipis</option>
        <option value="out" @selected(request('stock') === 'out')>Habis</option>
    </select>
    <select name="sort" class="form-select form-select-sm" data-autosubmit>
        @foreach (['' => 'Terbaru', 'name' => 'Nama A-Z', 'price' => 'Harga tertinggi', 'stock' => 'Stok tersedikit'] as $v => $l)<option value="{{ $v }}" @selected((string) request('sort') === (string) $v)>{{ $l }}</option>@endforeach
    </select>
    <button class="btn btn-primary btn-sm">Cari</button>
    @if (request()->hasAny(['q', 'owner', 'status', 'stock', 'sort']))<a href="{{ route('admin.products') }}" class="btn btn-light border btn-sm">Reset</a>@endif
</form>

<div class="mp-card p-0 overflow-hidden"><div class="mp-scroll">
<table class="mp-table">
    <thead><tr><th>Produk</th><th>Owner</th><th>Kategori</th><th class="text-end">Harga</th><th>Stok</th><th>Status</th></tr></thead>
    <tbody>
    @forelse ($products as $i => $p)
        @php $st = $p->stock <= 0 ? 'out' : ($p->stock <= \App\Models\Product::LOW_STOCK ? 'low' : 'ok'); @endphp
        <tr>
            <td><div class="d-flex align-items-center gap-3">
                <span class="mp-thumb c{{ $i % 5 }}">@if ($p->image)<img src="{{ asset('storage/'.$p->image) }}" alt="">@else<i class="bi bi-box-seam"></i>@endif</span>
                <span><b>{{ $p->name }}</b><br><span class="mp-sub">{{ $p->sku ? '#'.$p->sku : '—' }}</span></span></div></td>
            <td><a href="{{ route('admin.owners.show', $p->user_id) }}" class="text-reset">{{ $p->user->business_name ?: $p->user->name }}</a></td>
            <td>{{ $p->category?->name ?? '—' }}</td>
            <td class="text-end num">{{ rp($p->price) }}</td>
            <td><span class="mp-pill {{ ['ok' => 'green', 'low' => 'orange', 'out' => 'red'][$st] }}">{{ $p->stock }} unit</span></td>
            <td><span class="mp-pill {{ ['active' => 'green', 'draft' => 'gray', 'archived' => 'blue'][$p->status] ?? 'gray' }}">{{ ucfirst($p->status) }}</span></td>
        </tr>
    @empty
        <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-box-seam"></i>Tidak ada produk yang cocok.</div></td></tr>
    @endforelse
    </tbody>
</table></div>
@if ($products->hasPages())<div class="p-3">{{ $products->links() }}</div>@endif
</div>
@endsection
