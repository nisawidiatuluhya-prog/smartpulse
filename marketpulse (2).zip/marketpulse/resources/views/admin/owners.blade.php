@extends('layouts.app')
@section('title', 'Business Owners')

@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
    <div><h2 class="fw-bold fs-4 mb-1">Business Owners</h2><div class="mp-sub">Kelola akun pemilik usaha yang terdaftar</div></div>
    <a href="{{ route('admin.owners.export', request()->query()) }}" class="btn btn-light border btn-sm"><i class="bi bi-download me-1"></i>Export CSV</a>
</div>

<div class="row g-3 mb-3">
    @foreach ([['bi-shop', 'indigo', $summary['total'], 'Total owner'], ['bi-check-circle', 'emerald', $summary['active'], 'Akun aktif'], ['bi-person-x', 'red', $summary['inactive'], 'Akun nonaktif']] as [$ic, $c, $v, $l])
        <div class="col-6 col-md-4"><div class="mp-kpi"><span class="ic {{ $c }}"><i class="bi {{ $ic }}"></i></span><div><b>{{ $v }}</b><span>{{ $l }}</span></div></div></div>
    @endforeach
</div>

<form method="GET" class="mp-filter">
    <input type="search" name="q" value="{{ request('q') }}" class="form-control form-control-sm" placeholder="Cari nama, email, bisnis" style="min-width:220px">
    <select name="status" class="form-select form-select-sm" data-autosubmit>
        <option value="">Semua status</option>
        <option value="active" @selected(request('status') === 'active')>Aktif</option>
        <option value="inactive" @selected(request('status') === 'inactive')>Nonaktif</option>
    </select>
    <select name="sort" class="form-select form-select-sm" data-autosubmit>
        @foreach (['' => 'Terbaru', 'revenue' => 'Pendapatan tertinggi', 'sales' => 'Transaksi terbanyak', 'products' => 'Produk terbanyak', 'name' => 'Nama A-Z'] as $v => $l)<option value="{{ $v }}" @selected((string) request('sort') === (string) $v)>{{ $l }}</option>@endforeach
    </select>
    <button class="btn btn-primary btn-sm">Cari</button>
    @if (request()->hasAny(['q', 'status', 'sort']))<a href="{{ route('admin.owners') }}" class="btn btn-light border btn-sm">Reset</a>@endif
</form>

<div class="mp-card p-0 overflow-hidden"><div class="mp-scroll">
<table class="mp-table">
    <thead><tr><th>Owner</th><th>Bisnis</th><th>Produk</th><th>Transaksi</th><th style="min-width:170px">Pendapatan</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
    <tbody>
    @forelse ($owners as $i => $o)
        <tr>
            <td><a href="{{ route('admin.owners.show', $o) }}" class="d-flex align-items-center gap-3 text-reset">
                <span class="mp-thumb c{{ $i % 5 }}" style="font-weight:800;font-size:.8rem">{{ $o->initials }}</span>
                <span><b>{{ $o->name }}</b><br><span class="mp-sub">{{ $o->email }}</span></span></a></td>
            <td>{{ $o->business_name ?: '—' }}</td>
            <td>{{ $o->products_count }}</td>
            <td>{{ $o->sales_count }}</td>
            <td class="num">{{ rp($o->sales_sum_total ?? 0) }}<div class="mp-meter"><i style="width: {{ round(($o->sales_sum_total ?? 0) / $max * 100) }}%"></i></div></td>
            <td>@if ($o->is_active)<span class="mp-pill green">Aktif</span>@else<span class="mp-pill red">Nonaktif</span>@endif</td>
            <td class="text-end text-nowrap">
                <a href="{{ route('admin.owners.show', $o) }}" class="btn btn-sm btn-light border">Detail</a>
                <form method="POST" action="{{ route('admin.owners.toggle', $o) }}" class="d-inline">@csrf @method('PATCH')<button class="btn btn-sm btn-light border">{{ $o->is_active ? 'Nonaktifkan' : 'Aktifkan' }}</button></form>
                <form method="POST" action="{{ route('admin.owners.destroy', $o) }}" class="d-inline" data-confirm="Hapus owner beserta SELURUH produk, pelanggan, dan transaksinya? Tidak bisa dibatalkan.">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Hapus</button></form>
            </td>
        </tr>
    @empty
        <tr><td colspan="7"><div class="mp-empty"><i class="bi bi-people"></i>Tidak ada Business Owner yang cocok.</div></td></tr>
    @endforelse
    </tbody>
</table></div>
@if ($owners->hasPages())<div class="p-3">{{ $owners->links() }}</div>@endif
</div>
@endsection
