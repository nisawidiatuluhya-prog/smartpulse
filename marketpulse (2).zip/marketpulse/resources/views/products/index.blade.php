@extends('layouts.app')
@section('title', 'Products')
@section('heading', 'Products')

@section('content')
<div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-3">
    <div>
        <h2 class="fw-bold fs-4 mb-1">Products</h2>
        <div class="mp-sub">Kelola inventaris, harga, dan ketersediaan produk Anda</div>
    </div>
    <div class="d-flex gap-2">
        <a href="{{ route('products.export') }}" class="btn btn-light border"><i class="bi bi-download me-1"></i>Export</a>
        <a href="{{ route('products.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Add product</a>
    </div>
</div>

<div class="row g-3 mb-3">
    @foreach ([
        ['TOTAL PRODUCTS', 'bi-box-seam', number_format($stats['products'][0], 0, ',', '.'), $stats['products'][1]],
        ['TOTAL REVENUE', 'bi-currency-dollar', rp_short($stats['revenue'][0]), $stats['revenue'][1]],
        ['TOTAL ORDERS', 'bi-cart3', number_format($stats['orders'][0], 0, ',', '.'), $stats['orders'][1]],
        ['CUSTOMERS', 'bi-people', number_format($stats['customers'][0], 0, ',', '.'), $stats['customers'][1]],
    ] as [$label, $icon, $value, $chg])
        <div class="col-6 col-xl-3">
            <div class="mp-card" style="padding:14px 18px">
                <div class="mp-sub fw-bold" style="font-size:.7rem;letter-spacing:.02em"><i class="bi {{ $icon }} me-1"></i>{{ $label }}</div>
                <div class="fw-bold fs-4 my-1 js-count">{{ $value }}</div>
                <div class="d-flex justify-content-between align-items-center mp-sub" style="font-size:.72rem">
                    @include('partials.delta', ['change' => $chg])<span>Last 7 days</span>
                </div>
            </div>
        </div>
    @endforeach
</div>

<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
    <form method="GET" class="d-flex gap-2 flex-grow-1" style="max-width:520px">
        @if ($status)<input type="hidden" name="status" value="{{ $status }}">@endif
        <input type="hidden" name="view" value="{{ $view }}">
        <div class="position-relative flex-grow-1">
            <input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Search by product name or SKU">
        </div>
        <select name="stock" class="form-select w-auto" data-autosubmit>
            <option value="">Semua stok</option>
            <option value="low" @selected(request('stock') === 'low')>Stok menipis</option>
            <option value="out" @selected(request('stock') === 'out')>Stok habis</option>
        </select>
    </form>
    <div class="d-flex align-items-center gap-2">
    <div class="mp-viewtoggle">
        <a href="{{ route('products.index', array_filter(['status' => $status, 'q' => request('q'), 'stock' => request('stock'), 'view' => 'grid'])) }}" class="{{ $view === 'grid' ? 'on' : '' }}" title="Tampilan kartu"><i class="bi bi-grid-fill"></i></a>
        <a href="{{ route('products.index', array_filter(['status' => $status, 'q' => request('q'), 'stock' => request('stock'), 'view' => 'list'])) }}" class="{{ $view === 'list' ? 'on' : '' }}" title="Tampilan tabel"><i class="bi bi-list-ul"></i></a>
    </div>
    <div class="mp-tabs">
        @foreach (['all' => 'All', 'active' => 'Active', 'draft' => 'Drafts', 'archived' => 'Archived'] as $k => $l)
            <a href="{{ route('products.index', array_filter(['status' => $k === 'all' ? null : $k, 'q' => request('q'), 'stock' => request('stock'), 'view' => $view])) }}"
               class="{{ ($status ?? 'all') === $k || ($k === 'all' && ! $status) ? 'active' : '' }}">{{ $l }} <span class="mp-sub">{{ $tabs[$k] }}</span></a>
        @endforeach
    </div>
    </div>
</div>

@if ($view === 'list')
<div class="mp-card p-0 overflow-hidden">
    <form id="bulkForm" method="POST">
        @csrf
        <div class="mp-scroll">
        <table class="mp-table">
            <thead><tr>
                <th style="width:44px"><input type="checkbox" class="form-check-input" id="checkAll" aria-label="Pilih semua"></th>
                <th>Product Name</th><th>ID &amp; Create Date</th><th>Price</th><th>Stock</th><th>Status</th>
            </tr></thead>
            <tbody>
            @forelse ($products as $p)
                <tr>
                    <td><input type="checkbox" name="ids[]" value="{{ $p->id }}" class="form-check-input row-check"></td>
                    <td>
                        <a href="{{ route('products.edit', $p) }}" class="d-flex align-items-center gap-3 text-reset">
                            <span class="mp-thumb c{{ $p->id % 5 }}">@if ($p->image_url)<img src="{{ $p->image_url }}" alt="">@else<i class="bi bi-box-seam"></i>@endif</span>
                            <span><b>{{ $p->name }}</b><br><span class="mp-sub">{{ $p->category?->name ?? 'Tanpa kategori' }}</span></span>
                        </a>
                    </td>
                    <td><b>#{{ $p->sku ?: 'P'.str_pad($p->id, 5, '0', STR_PAD_LEFT) }}</b><br><span class="mp-sub">{{ $p->created_at->translatedFormat('M d, Y') }}</span></td>
                    <td><b>{{ rp($p->price) }}</b></td>
                    <td>{{ number_format($p->stock, 0, ',', '.') }}
                        @if ($p->stock_status === 'low')<span class="mp-pill orange ms-1">Menipis</span>@endif</td>
                    <td>
                        @if ($p->stock_status === 'out')<span class="mp-pill orange">Out of stock</span>
                        @elseif ($p->status === 'active')<span class="mp-pill green">Published</span>
                        @elseif ($p->status === 'draft')<span class="mp-pill gray">Draft</span>
                        @else<span class="mp-pill red">Inactive</span>@endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="6"><div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada produk yang cocok. <a href="{{ route('products.create') }}">Tambah produk</a>.</div></td></tr>
            @endforelse
            </tbody>
        </table>
        </div>
    </form>
    @if ($products->hasPages())<div class="p-3">{{ $products->links() }}</div>@endif
</div>

<div class="mp-bulkbar" id="bulkBar">
    <span class="sel"><span id="selCount">0</span> Selected</span>
    <button type="submit" form="bulkForm" formaction="{{ route('products.bulk-export') }}"><i class="bi bi-download me-1"></i>Export</button>
    <button type="button" id="editOne"><i class="bi bi-pencil me-1"></i>Edit Info</button>
    <button type="submit" form="bulkForm" formaction="{{ route('products.bulk-delete') }}" id="bulkDelete"><i class="bi bi-trash me-1"></i>Delete</button>
    <button type="button" id="clearSel" aria-label="Batal"><i class="bi bi-x-lg"></i></button>
</div>
@else
    @if ($products->isEmpty())
        <div class="mp-card"><div class="mp-empty"><i class="bi bi-box-seam"></i>Belum ada produk yang cocok. <a href="{{ route('products.create') }}">Tambah produk</a>.</div></div>
    @else
        <div class="row g-3 mp-pgrid">
            @foreach ($products as $p)
                <div class="col-6 col-md-4 col-xl-3" style="--n: {{ $loop->index }}">
                    <a href="{{ route('products.edit', $p) }}" class="mp-pcard">
                        <div class="pimg">
                            @if ($p->image_url)
                                <img src="{{ $p->image_url }}" alt="{{ $p->name }}" loading="lazy">
                            @else
                                <span class="pph"><i class="bi bi-image"></i></span>
                            @endif
                            <div class="pbadges">
                                @if ($p->stock_status === 'out')<span class="pbadge out">Habis</span>
                                @elseif ($p->stock_status === 'low')<span class="pbadge low">Stok menipis</span>@endif
                                @if ($p->status === 'draft')<span class="pbadge">Draft</span>
                                @elseif ($p->status === 'archived')<span class="pbadge out">Arsip</span>@endif
                            </div>
                        </div>
                        <div class="pbody">
                            <div class="pcat">{{ $p->category?->name ?? 'Tanpa kategori' }}</div>
                            <h3>{{ $p->name }}</h3>
                            <div class="pfoot"><b>{{ rp($p->price) }}</b><span class="pstock"><i class="bi bi-box2"></i> {{ number_format($p->stock, 0, ',', '.') }}</span></div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>
        @if ($products->hasPages())<div class="mt-3">{{ $products->links() }}</div>@endif
    @endif
@endif
@endsection

@if ($view === 'list')
@push('scripts')
<script>
(() => {
    const checks = () => [...document.querySelectorAll('.row-check')];
    const bar = document.getElementById('bulkBar');
    const edits = @json($products->mapWithKeys(fn ($p) => [$p->id => route('products.edit', $p)]));
    function sync() {
        const sel = checks().filter(c => c.checked);
        document.getElementById('selCount').textContent = sel.length;
        bar.classList.toggle('show', sel.length > 0);
        document.getElementById('editOne').disabled = sel.length !== 1;
    }
    document.getElementById('checkAll').addEventListener('change', e => { checks().forEach(c => c.checked = e.target.checked); sync(); });
    checks().forEach(c => c.addEventListener('change', sync));
    document.getElementById('clearSel').addEventListener('click', () => { checks().forEach(c => c.checked = false); document.getElementById('checkAll').checked = false; sync(); });
    document.getElementById('editOne').addEventListener('click', () => { const s = checks().find(c => c.checked); if (s) location.href = edits[s.value]; });
    document.getElementById('bulkDelete').addEventListener('click', e => { if (!confirm('Hapus produk yang dipilih? Tindakan ini tidak bisa dibatalkan.')) e.preventDefault(); });
})();
</script>
@endpush
@endif
