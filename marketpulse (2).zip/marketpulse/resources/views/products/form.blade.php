@extends('layouts.app')
@section('title', $product->exists ? 'Edit Product' : 'Add Product')

@section('content')
<form method="POST" enctype="multipart/form-data"
      action="{{ $product->exists ? route('products.update', $product) : route('products.store') }}">
    @csrf
    @if ($product->exists) @method('PUT') @endif

    <div class="row g-3">
        <div class="col-lg-8">
            <div class="mp-card">
                <h2 class="mp-card-title mb-3">Informasi produk</h2>
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label" for="name">Nama produk</label>
                        <input id="name" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name', $product->name) }}" required>
                        @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="sku">SKU</label>
                        <input id="sku" name="sku" class="form-control @error('sku') is-invalid @enderror" value="{{ old('sku', $product->sku) }}">
                        @error('sku')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="category_id">Kategori</label>
                        <select id="category_id" name="category_id" class="form-select @error('category_id') is-invalid @enderror">
                            <option value="">Tanpa kategori</option>
                            @foreach ($categories as $c)
                                <option value="{{ $c->id }}" @selected(old('category_id', $product->category_id) == $c->id)>{{ $c->name }}{{ $c->user_id ? '' : ' (global)' }}</option>
                            @endforeach
                        </select>
                        @error('category_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="status">Status</label>
                        <select id="status" name="status" class="form-select">
                            @foreach (['active' => 'Active (dijual)', 'draft' => 'Draft', 'archived' => 'Archived'] as $v => $l)
                                <option value="{{ $v }}" @selected(old('status', $product->status) === $v)>{{ $l }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="price">Harga (Rp)</label>
                        <input id="price" type="number" step="0.01" min="0" name="price" class="form-control @error('price') is-invalid @enderror" value="{{ old('price', $product->price) }}" required>
                        @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="stock">Stok</label>
                        <input id="stock" type="number" min="0" name="stock" class="form-control @error('stock') is-invalid @enderror" value="{{ old('stock', $product->stock) }}" required>
                        @error('stock')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="description">Deskripsi</label>
                        <textarea id="description" name="description" rows="4" class="form-control">{{ old('description', $product->description) }}</textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="mp-card">
                <h2 class="mp-card-title mb-3">Gambar produk</h2>
                @if ($product->image_url)
                    <img src="{{ $product->image_url }}" alt="" class="img-fluid rounded-3 mb-3" id="preview">
                    <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="remove_image" value="1" id="rm"><label class="form-check-label" for="rm">Hapus gambar saat ini</label></div>
                @else
                    <img src="" alt="" class="img-fluid rounded-3 mb-3 d-none" id="preview">
                @endif
                <input type="file" name="image" accept="image/png,image/jpeg,image/webp" class="form-control @error('image') is-invalid @enderror" id="imageInput">
                @error('image')<div class="invalid-feedback">{{ $message }}</div>@enderror
                <div class="mp-sub mt-2">JPG, PNG, atau WebP. Maksimal 2 MB.</div>
            </div>
            <div class="d-flex gap-2 mt-3">
                <button class="btn btn-primary flex-grow-1">Simpan produk</button>
                <a href="{{ route('products.index') }}" class="btn btn-light border">Batal</a>
            </div>
        </div>
    </div>
</form>

@if ($product->exists)
    <form method="POST" action="{{ route('products.destroy', $product) }}" data-confirm="Hapus produk ini?" class="mt-3">
        @csrf @method('DELETE')
        <button class="btn btn-outline-danger btn-sm"><i class="bi bi-trash me-1"></i>Hapus produk</button>
    </form>
@endif
@endsection

@push('scripts')
<script>
document.getElementById('imageInput').addEventListener('change', e => {
    const f = e.target.files[0], img = document.getElementById('preview');
    if (!f) return;
    img.src = URL.createObjectURL(f); img.classList.remove('d-none');
});
</script>
@endpush
