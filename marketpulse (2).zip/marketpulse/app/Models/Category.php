<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Category extends Model
{
    protected $fillable = ['user_id', 'name', 'description'];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function products(): HasMany { return $this->hasMany(Product::class); }

    /** Kategori milik owner + kategori global dari Admin */
    public function scopeVisibleTo($q, int $userId)
    {
        return $q->where(fn ($w) => $w->where('user_id', $userId)->orWhereNull('user_id'));
    }
}
