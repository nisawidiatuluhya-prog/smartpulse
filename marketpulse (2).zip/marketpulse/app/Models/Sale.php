<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Sale extends Model
{
    protected $fillable = ['user_id', 'customer_id', 'invoice_no', 'sold_at', 'total', 'notes'];

    protected function casts(): array
    {
        return ['sold_at' => 'date', 'total' => 'decimal:2'];
    }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
    public function details(): HasMany { return $this->hasMany(SaleDetail::class); }
}
