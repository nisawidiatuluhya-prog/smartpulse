<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    public const LOW_STOCK = 10;

    protected $fillable = ['user_id', 'category_id', 'name', 'sku', 'description', 'price', 'stock', 'image', 'status'];

    protected function casts(): array
    {
        return ['price' => 'decimal:2'];
    }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function category(): BelongsTo { return $this->belongsTo(Category::class); }
    public function saleDetails(): HasMany { return $this->hasMany(SaleDetail::class); }

    public function getImageUrlAttribute(): ?string
    {
        return $this->image ? asset('storage/'.$this->image) : null;
    }

    /** out | low | ok */
    public function getStockStatusAttribute(): string
    {
        if ($this->stock <= 0) return 'out';
        return $this->stock <= self::LOW_STOCK ? 'low' : 'ok';
    }
}
