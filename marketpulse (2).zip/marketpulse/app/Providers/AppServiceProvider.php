<?php

namespace App\Providers;

use App\Models\Product;
use App\Models\Setting;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Paginator::useBootstrapFive();

        View::composer(['layouts.*', 'landing', 'auth.*'], function ($view) {
            $view->with('appName', Setting::get('app_name', config('app.name')));
            $view->with('appTagline', Setting::get('tagline', 'Smart commerce business intelligence'));
        });

        View::composer('layouts.app', function ($view) {
            $u = auth()->user();
            $low = ($u && ! $u->isAdmin())
                ? Product::where('user_id', $u->id)->where('status', 'active')->where('stock', '<=', Product::LOW_STOCK)->count()
                : 0;
            $view->with('lowStockCount', $low);
        });
    }
}
