<?php

if (! function_exists('rp')) {
    /** Format angka ke Rupiah: Rp 1.250.000 */
    function rp($amount): string
    {
        return 'Rp '.number_format((float) $amount, 0, ',', '.');
    }
}

if (! function_exists('rp_short')) {
    /** Format singkat untuk kartu: 1,2 jt / 3,4 M */
    function rp_short($amount): string
    {
        $n = (float) $amount;
        if ($n >= 1_000_000_000) return 'Rp '.number_format($n / 1_000_000_000, 1, ',', '.').' M';
        if ($n >= 1_000_000) return 'Rp '.number_format($n / 1_000_000, 1, ',', '.').' jt';
        return rp($n);
    }
}

if (! function_exists('pct_change')) {
    /** Persentase perubahan current vs previous (null bila tidak ada pembanding) */
    function pct_change($current, $previous): ?float
    {
        if ((float) $previous == 0.0) {
            return (float) $current > 0 ? 100.0 : null;
        }
        return round((($current - $previous) / $previous) * 100, 1);
    }
}
