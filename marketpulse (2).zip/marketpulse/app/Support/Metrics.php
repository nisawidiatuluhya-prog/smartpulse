<?php

namespace App\Support;

use App\Models\Sale;
use App\Models\SaleDetail;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

/** Semua angka dashboard/analytics dihitung langsung dari database MySQL milik satu owner. */
class Metrics
{
    private static function dates(Carbon $from, Carbon $to): array
    {
        return [$from->toDateString(), $to->toDateString()];
    }

    /** Deret waktu pendapatan, transaksi, unit terjual. $group: day | week | month */
    public static function series(int $uid, Carbon $from, Carbon $to, string $group = 'day'): array
    {
        $fmt = ['day' => '%Y-%m-%d', 'week' => '%x-%v', 'month' => '%Y-%m'][$group];

        $sales = Sale::where('user_id', $uid)->whereBetween('sold_at', self::dates($from, $to))
            ->selectRaw("DATE_FORMAT(sold_at, '$fmt') as k, SUM(total) as revenue, COUNT(*) as orders")
            ->groupBy('k')->get()->keyBy('k');

        $units = SaleDetail::join('sales', 'sales.id', '=', 'sale_details.sale_id')
            ->where('sales.user_id', $uid)->whereBetween('sales.sold_at', self::dates($from, $to))
            ->selectRaw("DATE_FORMAT(sales.sold_at, '$fmt') as k, SUM(sale_details.quantity) as units")
            ->groupBy('k')->pluck('units', 'k');

        $labels = $revenue = $orders = $unitsOut = [];
        $cursor = $group === 'month' ? $from->copy()->startOfMonth() : ($group === 'week' ? $from->copy()->startOfWeek() : $from->copy());

        while ($cursor->lte($to)) {
            $key = ['day' => $cursor->format('Y-m-d'), 'week' => $cursor->format('o-W'), 'month' => $cursor->format('Y-m')][$group];
            $labels[] = $group === 'month' ? $cursor->translatedFormat('M Y') : $cursor->translatedFormat('d M');
            $revenue[] = (float) ($sales[$key]->revenue ?? 0);
            $orders[] = (int) ($sales[$key]->orders ?? 0);
            $unitsOut[] = (int) ($units[$key] ?? 0);
            $group === 'month' ? $cursor->addMonth() : ($group === 'week' ? $cursor->addWeek() : $cursor->addDay());
        }

        return ['labels' => $labels, 'revenue' => $revenue, 'orders' => $orders, 'units' => $unitsOut];
    }

    /** Penjualan per kategori */
    public static function categories(int $uid, ?Carbon $from = null, ?Carbon $to = null)
    {
        return SaleDetail::join('sales', 'sales.id', '=', 'sale_details.sale_id')
            ->leftJoin('products', 'products.id', '=', 'sale_details.product_id')
            ->leftJoin('categories', 'categories.id', '=', 'products.category_id')
            ->where('sales.user_id', $uid)
            ->when($from && $to, fn ($q) => $q->whereBetween('sales.sold_at', self::dates($from, $to)))
            ->selectRaw("COALESCE(categories.name, 'Tanpa kategori') as name, SUM(sale_details.quantity) as units, SUM(sale_details.subtotal) as revenue")
            ->groupByRaw("COALESCE(categories.name, 'Tanpa kategori')")->orderByDesc('units')->get();
    }

    /** Produk terlaris */
    public static function topProducts(int $uid, int $limit = 6, ?Carbon $from = null, ?Carbon $to = null)
    {
        return SaleDetail::join('sales', 'sales.id', '=', 'sale_details.sale_id')
            ->leftJoin('products', 'products.id', '=', 'sale_details.product_id')
            ->where('sales.user_id', $uid)
            ->when($from && $to, fn ($q) => $q->whereBetween('sales.sold_at', self::dates($from, $to)))
            ->selectRaw('sale_details.product_name as name, products.sku as sku, products.image as image, SUM(sale_details.quantity) as units, SUM(sale_details.subtotal) as revenue')
            ->groupBy('sale_details.product_name', 'products.sku', 'products.image')
            ->orderByDesc('units')->limit($limit)->get();
    }

    /** Ringkasan satu periode */
    public static function totals(int $uid, Carbon $from, Carbon $to): array
    {
        $d = self::dates($from, $to);
        $base = Sale::where('user_id', $uid)->whereBetween('sold_at', $d);

        $revenue = (float) (clone $base)->sum('total');
        $orders = (clone $base)->count();
        $units = (int) SaleDetail::join('sales', 'sales.id', '=', 'sale_details.sale_id')
            ->where('sales.user_id', $uid)->whereBetween('sales.sold_at', $d)->sum('sale_details.quantity');

        $perCustomer = (clone $base)->whereNotNull('customer_id')->groupBy('customer_id')
            ->selectRaw('COUNT(*) as c')->pluck('c');
        $buyers = $perCustomer->count();
        $repeat = $buyers ? round($perCustomer->filter(fn ($c) => $c >= 2)->count() / $buyers * 100, 1) : 0;

        return [
            'revenue' => $revenue,
            'orders' => $orders,
            'units' => $units,
            'avg' => $orders ? $revenue / $orders : 0,
            'buyers' => $buyers,
            'repeat' => $repeat,
        ];
    }

    /** Unit terjual per produk dalam N hari terakhir: [product_id => unit] */
    public static function velocity(int $uid, int $days = 30)
    {
        return SaleDetail::join('sales', 'sales.id', '=', 'sale_details.sale_id')
            ->where('sales.user_id', $uid)->whereNotNull('sale_details.product_id')
            ->where('sales.sold_at', '>=', now()->subDays($days - 1)->toDateString())
            ->groupBy('sale_details.product_id')
            ->selectRaw('sale_details.product_id as pid, SUM(sale_details.quantity) as units')
            ->pluck('units', 'pid');
    }

    /** Pendapatan per hari dalam seminggu (Senin..Minggu) milik satu owner */
    public static function weekday(int $uid, Carbon $from, Carbon $to): array
    {
        $rows = Sale::where('user_id', $uid)->whereBetween('sold_at', self::dates($from, $to))
            ->selectRaw('DAYOFWEEK(sold_at) as d, SUM(total) as revenue, COUNT(*) as orders')->groupBy('d')->get()->keyBy('d');
        $labels = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
        $revenue = $orders = [];
        foreach ([2, 3, 4, 5, 6, 7, 1] as $dow) {
            $revenue[] = (float) ($rows[$dow]->revenue ?? 0);
            $orders[] = (int) ($rows[$dow]->orders ?? 0);
        }

        return compact('labels', 'revenue', 'orders');
    }

    /** Pelanggan dengan total belanja terbesar pada suatu periode */
    public static function topCustomers(int $uid, Carbon $from, Carbon $to, int $limit = 5)
    {
        return Sale::join('customers', 'customers.id', '=', 'sales.customer_id')
            ->where('sales.user_id', $uid)->whereBetween('sales.sold_at', self::dates($from, $to))
            ->selectRaw('customers.id, customers.name, COUNT(*) as orders, SUM(sales.total) as spent')
            ->groupBy('customers.id', 'customers.name')->orderByDesc('spent')->limit($limit)->get();
    }

    /** Produk aktif yang diperkirakan habis dalam $horizon hari (berdasarkan laju jual 30 hari terakhir) */
    public static function restock(int $uid, int $horizon = 14, int $limit = 8)
    {
        $velocity = self::velocity($uid, 30);

        return \App\Models\Product::where('user_id', $uid)->where('status', 'active')->get()
            ->filter(fn ($p) => ($velocity[$p->id] ?? 0) > 0)
            ->map(function ($p) use ($velocity) {
                $perDay = $velocity[$p->id] / 30;

                return ['product' => $p, 'per_day' => $perDay, 'days' => $p->stock > 0 ? (int) floor($p->stock / $perDay) : 0];
            })
            ->filter(fn ($r) => $r['days'] <= $horizon)
            ->sortBy('days')->take($limit)->values();
    }

    /** Produk aktif bersetok yang tidak laku sama sekali dalam $days hari (dan sudah lebih lama dari itu di katalog) */
    public static function slowMovers(int $uid, int $days = 30, int $limit = 8)
    {
        $velocity = self::velocity($uid, $days);

        return \App\Models\Product::where('user_id', $uid)->where('status', 'active')->where('stock', '>', 0)
            ->where('created_at', '<', now()->subDays($days))->get()
            ->reject(fn ($p) => isset($velocity[$p->id]))
            ->sortByDesc(fn ($p) => $p->price * $p->stock)->take($limit)->values();
    }
}
