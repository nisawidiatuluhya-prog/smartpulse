<?php

namespace App\Support;

use App\Models\Product;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Memasang FOTO ASLI produk demo dari folder database/seeders/photos.
 * Nama file = slug nama produk, mis. "Kopi Gayo 250g" -> kopi-gayo-250g.jpg (boleh .jpg .jpeg .png .webp).
 * Produk yang fotonya belum ada dibiarkan tanpa foto (tampil ikon bawaan), bukan ilustrasi.
 */
class DemoPhotos
{
    public const EXT = ['jpg', 'jpeg', 'png', 'webp'];

    public static function dir(): string
    {
        return database_path('seeders/photos');
    }

    /** Path file foto untuk sebuah nama produk, atau null bila belum ada. */
    public static function find(string $productName): ?string
    {
        $slug = Str::slug($productName);
        foreach (self::EXT as $ext) {
            $file = self::dir().'/'.$slug.'.'.$ext;
            if (is_file($file)) {
                return $file;
            }
        }

        return null;
    }

    public static function attach(Product $p, bool $force = false): bool
    {
        if ($p->image && ! $force) {
            return false;
        }

        $file = self::find($p->name);
        if (! $file) {
            return false;
        }

        $path = 'products/demo-'.Str::slug($p->name).'.'.pathinfo($file, PATHINFO_EXTENSION);
        Storage::disk('public')->put($path, file_get_contents($file));
        $p->update(['image' => $path]);

        return true;
    }
}
