<?php

namespace App\Support;

use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Collection;

/** Angka untuk panel Admin: dihitung dari seluruh data platform (tanpa tabel baru). */
class PlatformMetrics
{
    private static function d(Carbon $from, Carbon $to): array
    {
        return [$from->toDateString(), $to->toDateString()];
    }

    public static function totals(Carbon $from, Carbon $to): array
    {
        $d = self::d($from, $to);
        $base = Sale::whereBetween('sold_at', $d);
        $revenue = (float) (clone $base)->sum('total');
        $orders = (clone $base)->count();
        $sellers = (clone $base)->distinct()->count('user_id');
        $units = (int) SaleDetail::join('sales', 'sales.id', '=', 'sale_details.sale_id')
            ->whereBetween('sales.sold_at', $d)->sum('sale_details.quantity');

        return [
            'revenue' => $revenue,
            'orders' => $orders,
            'units' => $units,
            'sellers' => $sellers,
            'avg' => $orders ? $revenue / $orders : 0,
            'per_seller' => $sellers ? $revenue / $sellers : 0,
        ];
    }

    /** Deret waktu seluruh platform. $group: day | week | month */
    public static function series(Carbon $from, Carbon $to, string $group = 'day'): array
    {
        $fmt = ['day' => '%Y-%m-%d', 'week' => '%x-%v', 'month' => '%Y-%m'][$group];
        $rows = Sale::whereBetween('sold_at', self::d($from, $to))
            ->selectRaw("DATE_FORMAT(sold_at, '$fmt') as k, SUM(total) as revenue, COUNT(*) as orders")
            ->groupBy('k')->get()->keyBy('k');

        $labels = $revenue = $orders = [];
        $cursor = $group === 'month' ? $from->copy()->startOfMonth() : ($group === 'week' ? $from->copy()->startOfWeek() : $from->copy());
        while ($cursor->lte($to)) {
            $key = ['day' => $cursor->format('Y-m-d'), 'week' => $cursor->format('o-W'), 'month' => $cursor->format('Y-m')][$group];
            $labels[] = $group === 'month' ? $cursor->translatedFormat('M Y') : $cursor->translatedFormat('d M');
            $revenue[] = (float) ($rows[$key]->revenue ?? 0);
            $orders[] = (int) ($rows[$key]->orders ?? 0);
            $group === 'month' ? $cursor->addMonth() : ($group === 'week' ? $cursor->addWeek() : $cursor->addDay());
        }

        return ['labels' => $labels, 'revenue' => $revenue, 'orders' => $orders];
    }

    /** Pendapatan, transaksi, dan owner baru per bulan */
    public static function monthly(int $months = 12): array
    {
        $from = now()->subMonths($months - 1)->startOfMonth();
        $series = self::series($from, now()->endOfDay(), 'month');
        $reg = User::where('role', 'owner')->where('created_at', '>=', $from)
            ->selectRaw("DATE_FORMAT(created_at, '%Y-%m') as k, COUNT(*) as c")->groupBy('k')->pluck('c', 'k');
        $owners = [];
        for ($i = $months - 1; $i >= 0; $i--) {
            $owners[] = (int) ($reg[now()->subMonths($i)->format('Y-m')] ?? 0);
        }
        $series['owners'] = $owners;

        return $series;
    }

    public static function categories(?Carbon $from = null, ?Carbon $to = null, int $limit = 8): Collection
    {
        return SaleDetail::join('sales', 'sales.id', '=', 'sale_details.sale_id')
            ->leftJoin('products', 'products.id', '=', 'sale_details.product_id')
            ->leftJoin('categories', 'categories.id', '=', 'products.category_id')
            ->when($from && $to, fn ($q) => $q->whereBetween('sales.sold_at', self::d($from, $to)))
            ->selectRaw("COALESCE(categories.name, 'Tanpa kategori') as name, SUM(sale_details.quantity) as units, SUM(sale_details.subtotal) as revenue")
            ->groupByRaw("COALESCE(categories.name, 'Tanpa kategori')")->orderByDesc('revenue')->limit($limit)->get();
    }

    public static function topProducts(int $limit = 8, ?Carbon $from = null, ?Carbon $to = null): Collection
    {
        return SaleDetail::join('sales', 'sales.id', '=', 'sale_details.sale_id')
            ->when($from && $to, fn ($q) => $q->whereBetween('sales.sold_at', self::d($from, $to)))
            ->selectRaw('sale_details.product_name as name, SUM(sale_details.quantity) as units, SUM(sale_details.subtotal) as revenue, COUNT(DISTINCT sales.user_id) as sellers')
            ->groupBy('sale_details.product_name')->orderByDesc('units')->limit($limit)->get();
    }

    /** Pendapatan per hari dalam seminggu (Senin..Minggu) */
    public static function weekday(Carbon $from, Carbon $to): array
    {
        $rows = Sale::whereBetween('sold_at', self::d($from, $to))
            ->selectRaw('DAYOFWEEK(sold_at) as d, SUM(total) as revenue, COUNT(*) as orders')->groupBy('d')->get()->keyBy('d');
        $labels = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
        $revenue = $orders = [];
        foreach ([2, 3, 4, 5, 6, 7, 1] as $dow) {
            $revenue[] = (float) ($rows[$dow]->revenue ?? 0);
            $orders[] = (int) ($rows[$dow]->orders ?? 0);
        }

        return compact('labels', 'revenue', 'orders');
    }

    /** Peringkat owner pada suatu periode */
    public static function ownerRanking(Carbon $from, Carbon $to, int $limit = 8): Collection
    {
        return Sale::join('users', 'users.id', '=', 'sales.user_id')
            ->whereBetween('sales.sold_at', self::d($from, $to))
            ->selectRaw('users.id, users.name, users.business_name, COUNT(*) as orders, SUM(sales.total) as revenue')
            ->groupBy('users.id', 'users.name', 'users.business_name')
            ->orderByDesc('revenue')->limit($limit)->get();
    }

    /** Kesehatan platform: hal-hal yang perlu perhatian Admin */
    public static function health(): array
    {
        $owners = User::where('role', 'owner');
        $withSales = Sale::distinct()->count('user_id');

        return [
            'inactive_owners' => (clone $owners)->where('is_active', false)->count(),
            'no_sales_owners' => max(0, (clone $owners)->count() - $withSales),
            'draft_products' => Product::where('status', 'draft')->count(),
            'archived_products' => Product::where('status', 'archived')->count(),
            'uncategorized' => Product::whereNull('category_id')->count(),
            'out_of_stock' => Product::where('status', 'active')->where('stock', 0)->count(),
            'low_stock' => Product::where('status', 'active')->where('stock', '>', 0)->where('stock', '<=', Product::LOW_STOCK)->count(),
            'stock_value' => (float) Product::where('status', 'active')->selectRaw('COALESCE(SUM(price * stock), 0) as v')->value('v'),
        ];
    }

    /** Aktivitas terbaru: transaksi dan pendaftaran owner digabung */
    public static function activity(int $limit = 8): Collection
    {
        $sales = Sale::with(['user:id,name,business_name', 'customer:id,name'])->latest('sold_at')->latest('id')->limit($limit)->get()
            ->map(fn ($s) => [
                'type' => 'sale', 'at' => $s->sold_at,
                'title' => ($s->user->business_name ?: $s->user->name).' mencatat penjualan',
                'meta' => $s->invoice_no.' · '.rp($s->total).' · '.($s->customer?->name ?? 'Umum'),
                'owner_id' => $s->user_id,
            ]);
        $owners = User::where('role', 'owner')->latest()->limit($limit)->get()
            ->map(fn ($o) => [
                'type' => 'owner', 'at' => $o->created_at,
                'title' => ($o->business_name ?: $o->name).' bergabung',
                'meta' => $o->email,
                'owner_id' => $o->id,
            ]);

        return $sales->concat($owners)->sortByDesc('at')->take($limit)->values();
    }
}
