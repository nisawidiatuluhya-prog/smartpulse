<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;

abstract class Controller
{
    /** Pastikan data milik owner yang sedang login */
    protected function own($model)
    {
        abort_unless($model->user_id === auth()->id(), 404);
        return $model;
    }

    /** Rentang tanggal dari ?period=7|30|90|365 atau ?from=&to= (default 30 hari) */
    protected function range(Request $r): array
    {
        $to = Carbon::now()->endOfDay();
        $from = Carbon::now()->subDays(29)->startOfDay();

        if ($r->filled('from') || $r->filled('to')) {
            try {
                if ($r->filled('from')) $from = Carbon::parse($r->from)->startOfDay();
                if ($r->filled('to')) $to = Carbon::parse($r->to)->endOfDay();
            } catch (\Throwable $e) {
            }
        } elseif (in_array((int) $r->period, [7, 30, 90, 365], true)) {
            $from = Carbon::now()->subDays((int) $r->period - 1)->startOfDay();
        }

        if ($from->gt($to)) {
            [$from, $to] = [$to->copy()->startOfDay(), $from->copy()->endOfDay()];
        }

        return [$from, $to];
    }
}
