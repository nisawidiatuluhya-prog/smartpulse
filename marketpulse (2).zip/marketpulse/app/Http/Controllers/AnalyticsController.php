<?php

namespace App\Http\Controllers;

use App\Support\Metrics;
use Illuminate\Http\Request;

class AnalyticsController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $uid = $user->id;
        [$from, $to] = $this->range($request);

        $days = (int) floor(abs($from->diffInDays($to))) + 1;
        $group = in_array($request->group, ['day', 'week', 'month']) ? $request->group : ($days > 120 ? 'month' : ($days > 45 ? 'week' : 'day'));

        // Periode pembanding dengan panjang sama tepat sebelum periode terpilih
        $pTo = $from->copy()->subDay()->endOfDay();
        $pFrom = $pTo->copy()->subDays($days - 1)->startOfDay();

        $cur = Metrics::totals($uid, $from, $to);
        $prev = Metrics::totals($uid, $pFrom, $pTo);
        $newCustomers = $user->customers()->whereBetween('created_at', [$from, $to])->count();
        $prevNewCustomers = $user->customers()->whereBetween('created_at', [$pFrom, $pTo])->count();

        $cards = [
            ['key' => 'customers', 'label' => 'Total Customers', 'icon' => 'bi-people', 'value' => number_format($user->customers()->count(), 0, ',', '.'), 'change' => pct_change($newCustomers, $prevNewCustomers)],
            ['key' => 'units', 'label' => 'Products Sold', 'icon' => 'bi-bag', 'value' => number_format($cur['units'], 0, ',', '.'), 'change' => pct_change($cur['units'], $prev['units'])],
            ['key' => 'avg', 'label' => 'Avg. Transaction', 'icon' => 'bi-cash-coin', 'value' => rp_short($cur['avg']), 'change' => pct_change($cur['avg'], $prev['avg'])],
            ['key' => 'repeat', 'label' => 'Repeat Customers', 'icon' => 'bi-arrow-repeat', 'value' => number_format($cur['repeat'], 1, ',', '.').'%', 'change' => pct_change($cur['repeat'], $prev['repeat'])],
        ];

        $series = Metrics::series($uid, $from, $to, $group);
        $categories = Metrics::categories($uid, $from, $to);
        $catUnits = max(1, $categories->sum('units'));
        $topProducts = Metrics::topProducts($uid, 8, $from, $to);

        return view('analytics', compact('from', 'to', 'group', 'cards', 'series', 'categories', 'catUnits', 'topProducts', 'cur', 'prev'));
    }
}
