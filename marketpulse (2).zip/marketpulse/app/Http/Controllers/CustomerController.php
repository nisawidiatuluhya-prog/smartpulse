<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index(Request $request)
    {
        $customers = auth()->user()->customers()
            ->withCount('sales')->withSum('sales', 'total')
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w
                ->where('name', 'like', "%$s%")->orWhere('email', 'like', "%$s%")->orWhere('phone', 'like', "%$s%")))
            ->latest()->paginate(12)->withQueryString();

        return view('customers.index', compact('customers'));
    }

    public function create()
    {
        return view('customers.form', ['customer' => new Customer]);
    }

    public function store(Request $request)
    {
        auth()->user()->customers()->create($this->validated($request));

        return redirect()->route('customers.index')->with('success', 'Pelanggan ditambahkan.');
    }

    public function show(Customer $customer)
    {
        $this->own($customer);
        $sales = $customer->sales()->withCount('details')->latest('sold_at')->latest('id')->paginate(10);
        $totalSpent = $customer->sales()->sum('total');

        return view('customers.show', compact('customer', 'sales', 'totalSpent'));
    }

    public function edit(Customer $customer)
    {
        return view('customers.form', ['customer' => $this->own($customer)]);
    }

    public function update(Request $request, Customer $customer)
    {
        $this->own($customer)->update($this->validated($request));

        return redirect()->route('customers.show', $customer)->with('success', 'Data pelanggan diperbarui.');
    }

    public function destroy(Customer $customer)
    {
        $this->own($customer)->delete();

        return redirect()->route('customers.index')->with('success', 'Pelanggan dihapus. Riwayat transaksinya tetap tersimpan.');
    }

    private function validated(Request $r): array
    {
        return $r->validate([
            'name' => ['required', 'string', 'max:120'],
            'email' => ['nullable', 'email', 'max:190'],
            'phone' => ['nullable', 'string', 'max:30'],
            'address' => ['nullable', 'string', 'max:500'],
        ]);
    }
}
