<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $uid = auth()->id();
        $categories = Category::visibleTo($uid)
            ->withCount(['products' => fn ($q) => $q->where('user_id', $uid)])
            ->orderBy('name')->get();

        return view('categories.index', compact('categories'));
    }

    public function create()
    {
        return view('categories.form', ['category' => new Category]);
    }

    public function store(Request $request)
    {
        auth()->user()->categories()->create($this->validated($request));

        return redirect()->route('categories.index')->with('success', 'Kategori ditambahkan.');
    }

    public function edit(Category $category)
    {
        return view('categories.form', ['category' => $this->own($category)]);
    }

    public function update(Request $request, Category $category)
    {
        $this->own($category)->update($this->validated($request));

        return redirect()->route('categories.index')->with('success', 'Kategori diperbarui.');
    }

    public function destroy(Category $category)
    {
        $this->own($category)->delete();

        return redirect()->route('categories.index')->with('success', 'Kategori dihapus. Produk di dalamnya menjadi tanpa kategori.');
    }

    private function validated(Request $r): array
    {
        return $r->validate([
            'name' => ['required', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:255'],
        ]);
    }
}
