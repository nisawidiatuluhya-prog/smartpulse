<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use App\Support\PlatformMetrics;

class DashboardController extends Controller
{
    public function index()
    {
        $to = now()->endOfDay();
        $cur = PlatformMetrics::totals(now()->subDays(29)->startOfDay(), $to);
        $prev = PlatformMetrics::totals(now()->subDays(59)->startOfDay(), now()->subDays(30)->endOfDay());
        $newOwners = fn ($a, $b) => User::where('role', 'owner')->whereBetween('created_at', [$a, $b])->count();
        $newCur = $newOwners(now()->subDays(29)->startOfDay(), $to);
        $newPrev = $newOwners(now()->subDays(59)->startOfDay(), now()->subDays(30)->endOfDay());

        $health = PlatformMetrics::health();
        $owners = User::where('role', 'owner')->count();

        $stats = [
            'owners' => $owners,
            'active' => User::where('role', 'owner')->where('is_active', true)->count(),
            'products' => Product::count(),
            'sales' => Sale::count(),
            'revenue' => (float) Sale::sum('total'),
            'rev30' => $cur['revenue'],
            'rev_change' => pct_change($cur['revenue'], $prev['revenue']),
            'orders30' => $cur['orders'],
            'orders_change' => pct_change($cur['orders'], $prev['orders']),
            'new_owners' => $newCur,
            'new_change' => pct_change($newCur, $newPrev),
            'avg' => $cur['avg'],
            'per_seller' => $cur['per_seller'],
            'sellers' => $cur['sellers'],
        ];

        $monthly = PlatformMetrics::monthly(12);
        $categories = PlatformMetrics::categories(now()->subDays(89)->startOfDay(), $to, 6);
        $topProducts = PlatformMetrics::topProducts(6, now()->subDays(89)->startOfDay(), $to);
        $ranking = PlatformMetrics::ownerRanking(now()->subDays(29)->startOfDay(), $to, 6);
        $activity = PlatformMetrics::activity(8);
        $latest = User::where('role', 'owner')->latest()->limit(5)->get();

        return view('admin.dashboard', compact('stats', 'health', 'monthly', 'categories', 'topProducts', 'ranking', 'activity', 'latest'));
    }
}
