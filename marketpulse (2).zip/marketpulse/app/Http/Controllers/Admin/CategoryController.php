<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;

/** Kategori global (user_id NULL): tersedia untuk semua Business Owner */
class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::whereNull('user_id')->withCount('products')->orderBy('name')->get();

        return view('admin.categories', compact('categories'));
    }

    public function create()
    {
        return view('categories.form', ['category' => new Category, 'admin' => true]);
    }

    public function store(Request $request)
    {
        Category::create($this->validated($request) + ['user_id' => null]);

        return redirect()->route('admin.categories.index')->with('success', 'Kategori global ditambahkan.');
    }

    public function edit(Category $category)
    {
        abort_unless($category->user_id === null, 404);

        return view('categories.form', ['category' => $category, 'admin' => true]);
    }

    public function update(Request $request, Category $category)
    {
        abort_unless($category->user_id === null, 404);
        $category->update($this->validated($request));

        return redirect()->route('admin.categories.index')->with('success', 'Kategori diperbarui.');
    }

    public function destroy(Category $category)
    {
        abort_unless($category->user_id === null, 404);
        $category->delete();

        return redirect()->route('admin.categories.index')->with('success', 'Kategori dihapus.');
    }

    private function validated(Request $r): array
    {
        return $r->validate([
            'name' => ['required', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:255'],
        ]);
    }
}
