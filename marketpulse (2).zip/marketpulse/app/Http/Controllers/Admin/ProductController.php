<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;

/** Pemantauan produk seluruh Business Owner (hanya baca). */
class ProductController extends Controller
{
    public function index(Request $request)
    {
        $q = Product::with(['user:id,name,business_name', 'category:id,name'])
            ->when($request->filled('owner'), fn ($x) => $x->where('user_id', (int) $request->owner))
            ->when(in_array($request->status, ['active', 'draft', 'archived'], true), fn ($x) => $x->where('status', $request->status))
            ->when($request->stock === 'low', fn ($x) => $x->where('stock', '>', 0)->where('stock', '<=', Product::LOW_STOCK))
            ->when($request->stock === 'out', fn ($x) => $x->where('stock', 0))
            ->when($request->filled('q'), fn ($x) => $x->where(fn ($w) => $w
                ->where('name', 'like', '%'.$request->q.'%')->orWhere('sku', 'like', '%'.$request->q.'%')));

        $summary = [
            'count' => (clone $q)->count(),
            'units' => (int) (clone $q)->sum('stock'),
            'value' => (float) (clone $q)->selectRaw('COALESCE(SUM(price * stock), 0) as v')->value('v'),
            'low' => (clone $q)->where('stock', '>', 0)->where('stock', '<=', Product::LOW_STOCK)->count(),
            'out' => (clone $q)->where('stock', 0)->count(),
        ];

        $sort = $request->sort;
        $q = match ($sort) {
            'price' => $q->orderByDesc('price'),
            'stock' => $q->orderBy('stock'),
            'name' => $q->orderBy('name'),
            default => $q->latest(),
        };

        $products = $q->paginate(18)->withQueryString();
        $owners = User::where('role', 'owner')->orderBy('business_name')->orderBy('name')->get(['id', 'name', 'business_name']);

        return view('admin.products', compact('products', 'summary', 'owners'));
    }
}
