<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function edit()
    {
        return view('admin.settings', [
            'app_name' => Setting::get('app_name', config('app.name')),
            'tagline' => Setting::get('tagline', 'Smart commerce business intelligence'),
            'support_email' => Setting::get('support_email', ''),
        ]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'app_name' => ['required', 'string', 'max:40'],
            'tagline' => ['nullable', 'string', 'max:120'],
            'support_email' => ['nullable', 'email', 'max:120'],
        ]);

        foreach ($data as $k => $v) {
            Setting::put($k, $v);
        }

        return back()->with('success', 'Pengaturan aplikasi disimpan.');
    }
}
