<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Support\PlatformMetrics;
use Illuminate\Http\Request;

class AnalyticsController extends Controller
{
    public function index(Request $request)
    {
        [$from, $to] = $this->range($request);
        $days = max(1, (int) $from->copy()->startOfDay()->diffInDays($to->copy()->startOfDay(), true) + 1);
        $group = in_array($request->group, ['day', 'week', 'month'], true) ? $request->group : ($days > 120 ? 'month' : ($days > 45 ? 'week' : 'day'));

        // Periode pembanding dengan panjang yang sama tepat sebelum periode ini
        $prevTo = $from->copy()->subDay()->endOfDay();
        $prevFrom = $prevTo->copy()->subDays($days - 1)->startOfDay();

        $cur = PlatformMetrics::totals($from, $to);
        $prev = PlatformMetrics::totals($prevFrom, $prevTo);

        return view('admin.analytics', [
            'from' => $from, 'to' => $to, 'group' => $group, 'days' => $days,
            'cur' => $cur,
            'changes' => [
                'revenue' => pct_change($cur['revenue'], $prev['revenue']),
                'orders' => pct_change($cur['orders'], $prev['orders']),
                'units' => pct_change($cur['units'], $prev['units']),
                'sellers' => pct_change($cur['sellers'], $prev['sellers']),
            ],
            'series' => PlatformMetrics::series($from, $to, $group),
            'weekday' => PlatformMetrics::weekday($from, $to),
            'categories' => PlatformMetrics::categories($from, $to, 8),
            'topProducts' => PlatformMetrics::topProducts(8, $from, $to),
            'ranking' => PlatformMetrics::ownerRanking($from, $to, 8),
        ]);
    }
}
