<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Http\Request;

/** Pemantauan transaksi seluruh Business Owner (hanya baca). */
class SaleController extends Controller
{
    private function query(Request $r, bool $detail = true)
    {
        return Sale::query()
            ->when($detail, fn ($q) => $q->with(['user:id,name,business_name', 'customer:id,name'])->withCount('details'))
            ->when($r->filled('owner'), fn ($q) => $q->where('user_id', (int) $r->owner))
            ->when($r->filled('from'), fn ($q) => $q->whereDate('sold_at', '>=', $r->from))
            ->when($r->filled('to'), fn ($q) => $q->whereDate('sold_at', '<=', $r->to))
            ->when($r->filled('q'), fn ($q) => $q->where(fn ($w) => $w
                ->where('invoice_no', 'like', '%'.$r->q.'%')
                ->orWhereHas('customer', fn ($c) => $c->where('name', 'like', '%'.$r->q.'%'))))
            ->latest('sold_at')->latest('id');
    }

    public function index(Request $request)
    {
        $base = $this->query($request);
        $sum = $this->query($request, false)->reorder();
        $summary = [
            'count' => (clone $sum)->count(),
            'revenue' => (float) (clone $sum)->sum('total'),
            'owners' => (clone $sum)->distinct()->count('user_id'),
        ];
        $summary['avg'] = $summary['count'] ? $summary['revenue'] / $summary['count'] : 0;

        $sales = $base->paginate(15)->withQueryString();
        $owners = User::where('role', 'owner')->orderBy('business_name')->orderBy('name')->get(['id', 'name', 'business_name']);

        return view('admin.sales', compact('sales', 'summary', 'owners'));
    }

    public function export(Request $request)
    {
        $rows = $this->query($request)->limit(5000)->get();

        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['Invoice', 'Tanggal', 'Owner', 'Bisnis', 'Pelanggan', 'Jumlah item', 'Total']);
            foreach ($rows as $s) {
                fputcsv($out, [$s->invoice_no, $s->sold_at->toDateString(), $s->user->name, $s->user->business_name, $s->customer?->name ?? 'Umum', $s->details_count, (float) $s->total]);
            }
            fclose($out);
        }, 'transaksi-platform-'.now()->format('Ymd').'.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
}
