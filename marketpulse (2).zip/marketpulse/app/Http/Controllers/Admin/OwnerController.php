<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Support\Metrics;
use Illuminate\Http\Request;

class OwnerController extends Controller
{
    private function query(Request $request)
    {
        return User::where('role', 'owner')
            ->withCount(['products', 'customers', 'sales'])->withSum('sales', 'total')
            ->when($request->status === 'active', fn ($q) => $q->where('is_active', true))
            ->when($request->status === 'inactive', fn ($q) => $q->where('is_active', false))
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w
                ->where('name', 'like', "%$s%")->orWhere('email', 'like', "%$s%")->orWhere('business_name', 'like', "%$s%")));
    }

    public function index(Request $request)
    {
        $q = $this->query($request);
        $q = match ($request->sort) {
            'revenue' => $q->orderByDesc('sales_sum_total'),
            'sales' => $q->orderByDesc('sales_count'),
            'products' => $q->orderByDesc('products_count'),
            'name' => $q->orderBy('business_name')->orderBy('name'),
            default => $q->latest(),
        };
        $owners = $q->paginate(12)->withQueryString();
        $max = max(1, (float) User::where('role', 'owner')->withSum('sales', 'total')->get()->max('sales_sum_total'));
        $summary = [
            'total' => User::where('role', 'owner')->count(),
            'active' => User::where('role', 'owner')->where('is_active', true)->count(),
        ];
        $summary['inactive'] = $summary['total'] - $summary['active'];

        return view('admin.owners', compact('owners', 'max', 'summary'));
    }

    public function export(Request $request)
    {
        $rows = $this->query($request)->latest()->get();

        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['Nama', 'Email', 'Bisnis', 'Telepon', 'Status', 'Produk', 'Pelanggan', 'Transaksi', 'Pendapatan', 'Terdaftar']);
            foreach ($rows as $o) {
                fputcsv($out, [$o->name, $o->email, $o->business_name, $o->phone, $o->is_active ? 'Aktif' : 'Nonaktif', $o->products_count, $o->customers_count, $o->sales_count, (float) ($o->sales_sum_total ?? 0), $o->created_at->toDateString()]);
            }
            fclose($out);
        }, 'business-owner-'.now()->format('Ymd').'.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function show(User $user)
    {
        abort_unless($user->role === 'owner', 404);
        $user->loadCount(['products', 'customers', 'sales'])->loadSum('sales', 'total');
        $recent = $user->sales()->with('customer')->latest('sold_at')->latest('id')->limit(8)->get();

        $from = now()->subMonths(5)->startOfMonth();
        $to = now()->endOfDay();
        $series = Metrics::series($user->id, $from, $to, 'month');
        $topProducts = Metrics::topProducts($user->id, 5);
        $categories = Metrics::categories($user->id);
        $stock = [
            'active' => $user->products()->where('status', 'active')->count(),
            'low' => $user->products()->where('status', 'active')->where('stock', '>', 0)->where('stock', '<=', \App\Models\Product::LOW_STOCK)->count(),
            'out' => $user->products()->where('status', 'active')->where('stock', 0)->count(),
            'value' => (float) $user->products()->where('status', 'active')->selectRaw('COALESCE(SUM(price * stock), 0) as v')->value('v'),
        ];
        $last = $user->sales()->max('sold_at');

        return view('admin.owner-show', ['owner' => $user, 'recent' => $recent, 'series' => $series, 'topProducts' => $topProducts, 'categories' => $categories, 'stock' => $stock, 'lastSale' => $last]);
    }

    public function toggle(User $user)
    {
        abort_unless($user->role === 'owner', 404);
        $user->update(['is_active' => ! $user->is_active]);

        return back()->with('success', $user->is_active ? 'Akun diaktifkan.' : 'Akun dinonaktifkan.');
    }

    public function destroy(User $user)
    {
        abort_unless($user->role === 'owner', 404);
        // Hapus gambar produk milik owner ini
        foreach ($user->products()->whereNotNull('image')->pluck('image') as $img) {
            \Storage::disk('public')->delete($img);
        }
        $user->delete();

        return redirect()->route('admin.owners')->with('success', 'Business Owner dan seluruh datanya dihapus.');
    }
}
