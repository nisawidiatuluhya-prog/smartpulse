<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Sale;
use App\Support\Metrics;

/** Insight otomatis: ringkasan kalimat, skor kesehatan bisnis, saran restock, dan produk lambat. */
class InsightController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $uid = $user->id;
        $to = now()->endOfDay();
        $from30 = now()->subDays(29)->startOfDay();
        $from90 = now()->subDays(89)->startOfDay();

        $cur = Metrics::totals($uid, $from30, $to);
        $prev = Metrics::totals($uid, now()->subDays(59)->startOfDay(), now()->subDays(30)->endOfDay());
        $change = pct_change($cur['revenue'], $prev['revenue']);

        $weekday = Metrics::weekday($uid, $from90, $to);
        $maxDay = max($weekday['revenue']);
        $bestDay = $maxDay > 0 ? $weekday['labels'][array_search($maxDay, $weekday['revenue'])] : null;

        $categories = Metrics::categories($uid, $from30, $to);
        $topProducts = Metrics::topProducts($uid, 5, $from30, $to);
        $topCustomers = Metrics::topCustomers($uid, $from90, $to, 5);
        $restock = Metrics::restock($uid, 14, 8);
        $slow = Metrics::slowMovers($uid, 30, 6);
        $slowValue = $slow->sum(fn ($p) => $p->price * $p->stock);

        // ---- Skor kesehatan bisnis (0-100) ----
        $active = Product::where('user_id', $uid)->where('status', 'active')->count();
        $bad = Product::where('user_id', $uid)->where('status', 'active')->where('stock', '<=', Product::LOW_STOCK)->count();
        $stockScore = $active ? ($active - $bad) / $active : 0;
        $activeDays = Sale::where('user_id', $uid)->whereBetween('sold_at', [$from30->toDateString(), $to->toDateString()])->distinct()->count('sold_at');
        $activityScore = min(1, $activeDays / 30);
        $growthScore = $change === null ? 0.5 : max(0, min(1, 0.5 + $change / 100));
        $repeatScore = min(1, $cur['repeat'] / 50);
        $score = (int) round(($growthScore * 0.3 + $stockScore * 0.25 + $activityScore * 0.25 + $repeatScore * 0.2) * 100);
        $parts = [
            ['Pertumbuhan', round($growthScore * 100), 'indigo'],
            ['Kesehatan stok', round($stockScore * 100), 'emerald'],
            ['Keaktifan jualan', round($activityScore * 100), 'cyan'],
            ['Pelanggan kembali', round($repeatScore * 100), 'pink'],
        ];

        // ---- Kalimat insight ----
        $insights = [];
        if ($change !== null) {
            $insights[] = [$change >= 0 ? 'bi-graph-up-arrow' : 'bi-graph-down-arrow', $change >= 0 ? 'green' : 'red',
                'Pendapatan '.($change >= 0 ? 'naik ' : 'turun ').number_format(abs($change), 1, ',', '.').'%',
                '30 hari terakhir '.rp($cur['revenue']).' dibanding '.rp($prev['revenue']).' pada 30 hari sebelumnya.'];
        }
        if ($bestDay) {
            $insights[] = ['bi-calendar-check', 'blue', 'Hari terbaik: '.$bestDay, 'Dalam 90 hari terakhir, hari '.$bestDay.' paling banyak menghasilkan pendapatan. Siapkan stok dan promosi sebelum hari itu.'];
        }
        if ($topProducts->isNotEmpty()) {
            $insights[] = ['bi-trophy', 'orange', 'Produk andalan: '.$topProducts->first()->name, number_format($topProducts->first()->units, 0, ',', '.').' unit terjual dalam 30 hari terakhir.'];
        }
        if ($categories->isNotEmpty()) {
            $insights[] = ['bi-tags', 'blue', 'Kategori terlaris: '.$categories->first()->name, 'Menyumbang '.number_format($categories->first()->units, 0, ',', '.').' unit penjualan dalam 30 hari terakhir.'];
        }
        if ($cur['buyers'] > 0) {
            $insights[] = ['bi-arrow-repeat', $cur['repeat'] >= 30 ? 'green' : 'orange', 'Pelanggan kembali '.number_format($cur['repeat'], 1, ',', '.').'%', $cur['repeat'] >= 30 ? 'Bagus, banyak pelanggan yang berbelanja lebih dari sekali.' : 'Coba beri diskon atau pesan terima kasih agar pelanggan kembali berbelanja.'];
        }
        if ($restock->isNotEmpty()) {
            $insights[] = ['bi-box-seam', 'red', $restock->count().' produk perlu restock segera', 'Diperkirakan habis dalam 14 hari ke depan: '.$restock->take(3)->map(fn ($r) => $r['product']->name)->implode(', ').'.'];
        }
        if ($slow->isNotEmpty()) {
            $insights[] = ['bi-hourglass-split', 'orange', $slow->count().' produk tidak laku 30 hari', 'Modal tertahan sekitar '.rp($slowValue).'. Pertimbangkan promo atau bundling.'];
        }

        return view('insights', compact('score', 'parts', 'insights', 'weekday', 'bestDay', 'restock', 'slow', 'slowValue', 'topCustomers', 'cur', 'change'));
    }
}
