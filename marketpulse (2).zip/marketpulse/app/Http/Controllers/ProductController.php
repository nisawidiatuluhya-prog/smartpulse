<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Sale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $status = in_array($request->status, ['active', 'draft', 'archived']) ? $request->status : null;
        $view = $request->view === 'list' ? 'list' : 'grid';

        $products = $user->products()->with('category')
            ->when($status, fn ($q) => $q->where('status', $status))
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w
                ->where('name', 'like', "%$s%")->orWhere('sku', 'like', "%$s%")))
            ->when($request->stock === 'low', fn ($q) => $q->whereBetween('stock', [1, Product::LOW_STOCK]))
            ->when($request->stock === 'out', fn ($q) => $q->where('stock', '<=', 0))
            ->latest()->paginate($view === 'grid' ? 12 : 15)->withQueryString();

        // Statistik 7 hari terakhir vs 7 hari sebelumnya
        $now = now();
        $w1 = [$now->copy()->subDays(6)->startOfDay(), $now->copy()->endOfDay()];
        $w0 = [$now->copy()->subDays(13)->startOfDay(), $now->copy()->subDays(7)->endOfDay()];
        $count = fn ($rel, $w) => $user->$rel()->whereBetween('created_at', $w)->count();
        $rev = fn ($w) => $user->sales()->whereBetween('sold_at', [$w[0]->toDateString(), $w[1]->toDateString()])->sum('total');

        $stats = [
            'products' => [$user->products()->count(), pct_change($count('products', $w1), $count('products', $w0))],
            'revenue' => [$user->sales()->sum('total'), pct_change($rev($w1), $rev($w0))],
            'orders' => [$user->sales()->count(), pct_change($count('sales', $w1), $count('sales', $w0))],
            'customers' => [$user->customers()->count(), pct_change($count('customers', $w1), $count('customers', $w0))],
        ];

        $tabs = [
            'all' => $user->products()->count(),
            'active' => $user->products()->where('status', 'active')->count(),
            'draft' => $user->products()->where('status', 'draft')->count(),
            'archived' => $user->products()->where('status', 'archived')->count(),
        ];

        return view('products.index', compact('products', 'stats', 'tabs', 'status', 'view'));
    }

    public function create()
    {
        return view('products.form', ['product' => new Product(['status' => 'active', 'stock' => 0]), 'categories' => $this->categories()]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('products', 'public');
        }
        auth()->user()->products()->create($data);

        return redirect()->route('products.index')->with('success', 'Produk ditambahkan.');
    }

    public function edit(Product $product)
    {
        return view('products.form', ['product' => $this->own($product), 'categories' => $this->categories()]);
    }

    public function update(Request $request, Product $product)
    {
        $this->own($product);
        $data = $this->validated($request);

        if ($request->hasFile('image')) {
            $this->deleteImage($product);
            $data['image'] = $request->file('image')->store('products', 'public');
        } elseif ($request->boolean('remove_image')) {
            $this->deleteImage($product);
            $data['image'] = null;
        }
        $product->update($data);

        return redirect()->route('products.index')->with('success', 'Produk diperbarui.');
    }

    public function destroy(Product $product)
    {
        $this->own($product);
        $this->deleteImage($product);
        $product->delete();

        return redirect()->route('products.index')->with('success', 'Produk dihapus.');
    }

    public function bulkDelete(Request $request)
    {
        $ids = $request->validate(['ids' => ['required', 'array'], 'ids.*' => ['integer']])['ids'];
        $products = auth()->user()->products()->whereIn('id', $ids)->get();
        foreach ($products as $p) {
            $this->deleteImage($p);
            $p->delete();
        }

        return redirect()->route('products.index')->with('success', $products->count().' produk dihapus.');
    }

    /** Export CSV semua produk, atau hanya yang dipilih (ids[]) */
    public function export(Request $request)
    {
        $rows = auth()->user()->products()->with('category')
            ->when($request->ids, fn ($q, $ids) => $q->whereIn('id', (array) $ids))
            ->orderBy('name')->get();

        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['SKU', 'Nama Produk', 'Kategori', 'Harga', 'Stok', 'Status']);
            foreach ($rows as $p) {
                fputcsv($out, [$p->sku, $p->name, $p->category?->name, $p->price, $p->stock, $p->status]);
            }
            fclose($out);
        }, 'produk-'.now()->format('Ymd').'.csv', ['Content-Type' => 'text/csv']);
    }

    private function categories()
    {
        return Category::visibleTo(auth()->id())->orderBy('name')->get();
    }

    private function validated(Request $r): array
    {
        $uid = auth()->id();

        return $r->validate([
            'name' => ['required', 'string', 'max:150'],
            'sku' => ['nullable', 'string', 'max:60'],
            'category_id' => ['nullable', Rule::exists('categories', 'id')->where(fn ($q) => $q->where('user_id', $uid)->orWhereNull('user_id'))],
            'price' => ['required', 'numeric', 'min:0', 'max:999999999999'],
            'stock' => ['required', 'integer', 'min:0', 'max:10000000'],
            'status' => ['required', Rule::in(['active', 'draft', 'archived'])],
            'description' => ['nullable', 'string', 'max:2000'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ]);
    }

    private function deleteImage(Product $p): void
    {
        if ($p->image) {
            Storage::disk('public')->delete($p->image);
        }
    }
}
