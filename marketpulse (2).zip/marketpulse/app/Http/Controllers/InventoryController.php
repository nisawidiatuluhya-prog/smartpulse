<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Support\Metrics;
use Illuminate\Http\Request;

/** Ringkasan dan pengisian ulang stok milik owner. */
class InventoryController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $base = $user->products()->with('category:id,name');

        $active = (clone $base)->where('status', 'active');
        $summary = [
            'products' => (clone $active)->count(),
            'units' => (int) (clone $active)->sum('stock'),
            'value' => (float) $user->products()->where('status', 'active')->selectRaw('COALESCE(SUM(price * stock), 0) as v')->value('v'),
            'low' => (clone $active)->where('stock', '>', 0)->where('stock', '<=', Product::LOW_STOCK)->count(),
            'out' => (clone $active)->where('stock', 0)->count(),
        ];
        $summary['ok'] = max(0, $summary['products'] - $summary['low'] - $summary['out']);

        $state = in_array($request->state, ['low', 'out', 'ok'], true) ? $request->state : 'all';
        $products = (clone $base)->where('status', 'active')
            ->when($state === 'low', fn ($q) => $q->where('stock', '>', 0)->where('stock', '<=', Product::LOW_STOCK))
            ->when($state === 'out', fn ($q) => $q->where('stock', 0))
            ->when($state === 'ok', fn ($q) => $q->where('stock', '>', Product::LOW_STOCK))
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w->where('name', 'like', "%$s%")->orWhere('sku', 'like', "%$s%")))
            ->orderBy('stock')->orderBy('name')->paginate(15)->withQueryString();

        $velocity = Metrics::velocity($user->id, 30);

        return view('inventory', compact('summary', 'products', 'state', 'velocity'));
    }

    public function restock(Request $request, Product $product)
    {
        $this->own($product);
        $data = $request->validate(['quantity' => ['required', 'integer', 'min:1', 'max:100000']], [
            'quantity.required' => 'Isi jumlah stok yang ditambahkan.',
            'quantity.min' => 'Jumlah minimal 1.',
        ]);
        $product->increment('stock', $data['quantity']);

        return back()->with('success', 'Stok '.$product->name.' bertambah '.$data['quantity'].' (sekarang '.$product->fresh()->stock.').');
    }
}
