<?php

namespace App\Http\Controllers;

use App\Support\Metrics;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $uid = $user->id;

        $view = $request->range === '30d' ? '30d' : '12m';
        $to = now()->endOfDay();
        $from = $view === '30d' ? now()->subDays(29)->startOfDay() : now()->subMonths(11)->startOfMonth();
        $chart = Metrics::series($uid, $from, $to, $view === '30d' ? 'day' : 'month');

        // Perubahan 30 hari terakhir vs 30 hari sebelumnya
        $cur = Metrics::totals($uid, now()->subDays(29)->startOfDay(), $to);
        $prev = Metrics::totals($uid, now()->subDays(59)->startOfDay(), now()->subDays(30)->endOfDay());
        $newCust = fn ($a, $b) => $user->customers()->whereBetween('created_at', [$a, $b])->count();

        $cards = [
            'revenue' => ['value' => $user->sales()->sum('total'), 'change' => pct_change($cur['revenue'], $prev['revenue'])],
            'products' => ['value' => $user->products()->count(), 'change' => null],
            'sales' => ['value' => $user->sales()->count(), 'change' => pct_change($cur['orders'], $prev['orders'])],
            'customers' => ['value' => $user->customers()->count(),
                'change' => pct_change($newCust(now()->subDays(29)->startOfDay(), $to), $newCust(now()->subDays(59)->startOfDay(), now()->subDays(30)->endOfDay()))],
        ];

        $categories = Metrics::categories($uid);
        $catTotal = max(1, $categories->sum('units'));
        $topProducts = Metrics::topProducts($uid, 6);
        $recent = $user->sales()->with('customer')->withCount('details')->latest('sold_at')->latest('id')->limit(6)->get();
        $lowStock = $user->products()->where('status', 'active')->where('stock', '<=', \App\Models\Product::LOW_STOCK)->count();

        $today = Metrics::totals($uid, now()->startOfDay(), $to);
        $quick = [
            'today_revenue' => $today['revenue'],
            'today_orders' => $today['orders'],
            'out' => $user->products()->where('status', 'active')->where('stock', 0)->count(),
            'restock' => Metrics::restock($uid, 14, 50)->count(),
            'slow' => Metrics::slowMovers($uid, 30, 50)->count(),
        ];

        return view('dashboard', compact('view', 'chart', 'cards', 'categories', 'catTotal', 'topProducts', 'recent', 'lowStock', 'quick'));
    }
}
