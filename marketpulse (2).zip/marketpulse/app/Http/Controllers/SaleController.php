<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Sale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class SaleController extends Controller
{
    public function index(Request $request)
    {
        [$from, $to] = $this->range($request);
        $hasFilter = $request->filled('from') || $request->filled('to');

        $sales = auth()->user()->sales()->with('customer')->withCount('details')
            ->when($hasFilter, fn ($q) => $q->whereBetween('sold_at', [$from->toDateString(), $to->toDateString()]))
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w->where('invoice_no', 'like', "%$s%")
                ->orWhereHas('customer', fn ($c) => $c->where('name', 'like', "%$s%"))))
            ->latest('sold_at')->latest('id')->paginate(12)->withQueryString();

        return view('sales.index', compact('sales', 'from', 'to', 'hasFilter'));
    }

    public function create()
    {
        $user = auth()->user();

        return view('sales.create', [
            'customers' => $user->customers()->orderBy('name')->get(['id', 'name']),
            'products' => $user->products()->where('status', 'active')->where('stock', '>', 0)->orderBy('name')->get(['id', 'name', 'price', 'stock']),
            'invoiceNo' => $this->nextInvoiceNo(),
        ]);
    }

    public function store(Request $request)
    {
        $uid = auth()->id();

        $data = $request->validate([
            'customer_id' => ['nullable', Rule::exists('customers', 'id')->where('user_id', $uid)],
            'sold_at' => ['required', 'date', 'before_or_equal:today'],
            'notes' => ['nullable', 'string', 'max:255'],
            'items' => ['required', 'array', 'min:1', 'max:50'],
            'items.*.product_id' => ['required', Rule::exists('products', 'id')->where('user_id', $uid)],
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:100000'],
        ], [
            'items.required' => 'Tambahkan minimal satu produk.',
            'items.*.product_id.required' => 'Pilih produk pada setiap baris.',
            'items.*.quantity.min' => 'Jumlah minimal 1.',
        ]);

        // Gabungkan baris dengan produk yang sama
        $lines = collect($data['items'])->groupBy('product_id')->map(fn ($g) => $g->sum('quantity'));

        $sale = DB::transaction(function () use ($data, $lines, $uid) {
            // Kunci baris produk agar stok tidak balapan antar transaksi
            $products = Product::where('user_id', $uid)->whereIn('id', $lines->keys())->lockForUpdate()->get()->keyBy('id');
            $errors = [];
            $total = 0;
            $rows = [];

            foreach ($lines as $pid => $qty) {
                $p = $products[$pid];
                if ($p->stock < $qty) {
                    $errors['items'] = "Stok {$p->name} tidak cukup (tersisa {$p->stock}).";
                    break;
                }
                $subtotal = $p->price * $qty;
                $total += $subtotal;
                $rows[] = ['product_id' => $p->id, 'product_name' => $p->name, 'quantity' => $qty, 'price' => $p->price, 'subtotal' => $subtotal];
            }

            if ($errors) {
                throw ValidationException::withMessages($errors);
            }

            $sale = Sale::create([
                'user_id' => $uid,
                'customer_id' => $data['customer_id'] ?? null,
                'invoice_no' => $this->nextInvoiceNo(),
                'sold_at' => $data['sold_at'],
                'notes' => $data['notes'] ?? null,
                'total' => $total,
            ]);
            $sale->details()->createMany($rows);

            foreach ($rows as $r) {
                $products[$r['product_id']]->decrement('stock', $r['quantity']);
            }

            return $sale;
        });

        return redirect()->route('sales.show', $sale)->with('success', 'Penjualan '.$sale->invoice_no.' tersimpan dan stok diperbarui.');
    }

    public function show(Sale $sale)
    {
        $this->own($sale)->load('customer', 'details');

        return view('sales.show', compact('sale'));
    }

    /** Halaman invoice siap cetak */
    public function print(Sale $sale)
    {
        $this->own($sale)->load('customer', 'details');

        return view('sales.print', ['sale' => $sale, 'seller' => auth()->user()]);
    }

    /** Hapus transaksi dan kembalikan stok produk */
    public function destroy(Sale $sale)
    {
        $this->own($sale);

        DB::transaction(function () use ($sale) {
            foreach ($sale->details as $d) {
                if ($d->product_id) {
                    Product::where('id', $d->product_id)->where('user_id', $sale->user_id)->increment('stock', $d->quantity);
                }
            }
            $sale->delete();
        });

        return redirect()->route('sales.index')->with('success', 'Transaksi dihapus dan stok dikembalikan.');
    }

    private function nextInvoiceNo(): string
    {
        do {
            $no = 'INV-'.now()->format('Ymd').'-'.strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        } while (Sale::where('invoice_no', $no)->exists());

        return $no;
    }
}
