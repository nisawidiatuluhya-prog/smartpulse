<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public const TYPES = [
        'sales' => 'Laporan Penjualan',
        'revenue' => 'Laporan Pendapatan',
        'products' => 'Laporan Produk',
        'stock' => 'Laporan Stok',
        'customers' => 'Laporan Pelanggan',
    ];

    public function index(Request $request)
    {
        [$from, $to] = $this->range($request);
        $type = $this->type($request);
        $report = $this->build($type, $from, $to, auth()->id());

        return view('reports.index', ['types' => self::TYPES, 'type' => $type, 'from' => $from, 'to' => $to, 'report' => $report]);
    }

    public function export(Request $request)
    {
        [$from, $to] = $this->range($request);
        $type = $this->type($request);
        $report = $this->build($type, $from, $to, auth()->id());
        $file = 'laporan-'.$type.'-'.now()->format('Ymd');

        switch ($request->format) {
            case 'pdf':
                return Pdf::loadView('reports.pdf', ['report' => $report, 'from' => $from, 'to' => $to, 'user' => auth()->user()])
                    ->setPaper('a4', count($report['headers']) > 5 ? 'landscape' : 'portrait')
                    ->download($file.'.pdf');

            case 'xls':
                $html = view('reports.xls', ['report' => $report])->render();

                return response($html, 200, [
                    'Content-Type' => 'application/vnd.ms-excel; charset=UTF-8',
                    'Content-Disposition' => 'attachment; filename="'.$file.'.xls"',
                ]);

            default:
                return response()->streamDownload(function () use ($report) {
                    $out = fopen('php://output', 'w');
                    fwrite($out, "\xEF\xBB\xBF");
                    fputcsv($out, $report['headers']);
                    foreach ($report['rows'] as $row) {
                        fputcsv($out, $row);
                    }
                    fclose($out);
                }, $file.'.csv', ['Content-Type' => 'text/csv']);
        }
    }

    private function type(Request $r): string
    {
        return array_key_exists($r->type, self::TYPES) ? $r->type : 'sales';
    }

    /** Mengembalikan judul, header, baris mentah, dan indeks kolom rupiah. Semua dibatasi user_id. */
    private function build(string $type, $from, $to, int $uid): array
    {
        $d = [$from->toDateString(), $to->toDateString()];
        $money = [];
        $summary = null;

        switch ($type) {
            case 'sales':
                $headers = ['Invoice', 'Tanggal', 'Pelanggan', 'Jumlah Item', 'Total'];
                $q = DB::table('sales')->leftJoin('customers', 'customers.id', '=', 'sales.customer_id')
                    ->leftJoin('sale_details', 'sale_details.sale_id', '=', 'sales.id')
                    ->where('sales.user_id', $uid)->whereBetween('sales.sold_at', $d)
                    ->groupBy('sales.id', 'sales.invoice_no', 'sales.sold_at', 'customers.name', 'sales.total')
                    ->orderByDesc('sales.sold_at')->orderByDesc('sales.id')
                    ->selectRaw("sales.invoice_no, sales.sold_at, COALESCE(customers.name, 'Umum') as cust, COALESCE(SUM(sale_details.quantity),0) as qty, sales.total")
                    ->get();
                $rows = $q->map(fn ($r) => [$r->invoice_no, $r->sold_at, $r->cust, (int) $r->qty, (float) $r->total])->all();
                $money = [4];
                $summary = 'Total: '.rp($q->sum('total')).' dari '.$q->count().' transaksi';
                break;

            case 'revenue':
                $headers = ['Tanggal', 'Transaksi', 'Unit Terjual', 'Pendapatan'];
                $q = DB::table('sales')->leftJoin('sale_details', 'sale_details.sale_id', '=', 'sales.id')
                    ->where('sales.user_id', $uid)->whereBetween('sales.sold_at', $d)
                    ->groupBy('sales.sold_at')->orderBy('sales.sold_at')
                    ->selectRaw('sales.sold_at as day, COUNT(DISTINCT sales.id) as trx, COALESCE(SUM(sale_details.quantity),0) as qty, COALESCE(SUM(sale_details.subtotal),0) as rev')
                    ->get();
                $rows = $q->map(fn ($r) => [$r->day, (int) $r->trx, (int) $r->qty, (float) $r->rev])->all();
                $money = [3];
                $summary = 'Total pendapatan: '.rp($q->sum('rev'));
                break;

            case 'products':
                $headers = ['Produk', 'Kategori', 'Unit Terjual', 'Pendapatan'];
                $q = DB::table('sale_details')->join('sales', 'sales.id', '=', 'sale_details.sale_id')
                    ->leftJoin('products', 'products.id', '=', 'sale_details.product_id')
                    ->leftJoin('categories', 'categories.id', '=', 'products.category_id')
                    ->where('sales.user_id', $uid)->whereBetween('sales.sold_at', $d)
                    ->groupBy('sale_details.product_name', 'categories.name')->orderByDesc('qty')
                    ->selectRaw("sale_details.product_name as pname, COALESCE(categories.name,'Tanpa kategori') as cat, SUM(sale_details.quantity) as qty, SUM(sale_details.subtotal) as rev")
                    ->get();
                $rows = $q->map(fn ($r) => [$r->pname, $r->cat, (int) $r->qty, (float) $r->rev])->all();
                $money = [3];
                break;

            case 'stock':
                $headers = ['Produk', 'SKU', 'Kategori', 'Harga', 'Stok', 'Status Stok'];
                $q = DB::table('products')->leftJoin('categories', 'categories.id', '=', 'products.category_id')
                    ->where('products.user_id', $uid)->orderBy('products.stock')
                    ->select('products.name', 'products.sku', 'categories.name as cat', 'products.price', 'products.stock')->get();
                $rows = $q->map(fn ($r) => [$r->name, $r->sku, $r->cat ?? 'Tanpa kategori', (float) $r->price, (int) $r->stock,
                    $r->stock <= 0 ? 'Habis' : ($r->stock <= Product::LOW_STOCK ? 'Menipis' : 'Aman')])->all();
                $money = [3];
                $summary = 'Laporan stok adalah kondisi saat ini, tidak terpengaruh filter tanggal.';
                break;

            default: // customers
                $headers = ['Pelanggan', 'Email', 'Telepon', 'Transaksi', 'Total Belanja'];
                $q = DB::table('customers')
                    ->leftJoin('sales', function ($j) use ($d) {
                        $j->on('sales.customer_id', '=', 'customers.id')->whereBetween('sales.sold_at', $d);
                    })
                    ->where('customers.user_id', $uid)
                    ->groupBy('customers.id', 'customers.name', 'customers.email', 'customers.phone')
                    ->orderByDesc('spent')
                    ->selectRaw('customers.name, customers.email, customers.phone, COUNT(sales.id) as trx, COALESCE(SUM(sales.total),0) as spent')
                    ->get();
                $rows = $q->map(fn ($r) => [$r->name, $r->email, $r->phone, (int) $r->trx, (float) $r->spent])->all();
                $money = [4];
        }

        return ['type' => $type, 'title' => self::TYPES[$type], 'headers' => $headers, 'rows' => $rows, 'money' => $money, 'summary' => $summary];
    }
}
